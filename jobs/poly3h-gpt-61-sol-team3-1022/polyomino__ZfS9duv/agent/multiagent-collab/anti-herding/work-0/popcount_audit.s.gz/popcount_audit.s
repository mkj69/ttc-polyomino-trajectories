	.file	"solution.cpp"
	.text
#APP
	.globl _ZSt21ios_base_library_initv
#NO_APP
	.p2align 4
	.type	_ZSt13__adjust_heapISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEElS4_NS1_5__ops15_Iter_less_iterEEvT_T0_SE_T1_T2_.isra.0, @function
_ZSt13__adjust_heapISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEElS4_NS1_5__ops15_Iter_less_iterEEvT_T0_SE_T1_T2_.isra.0:
.LFB14554:
	.cfi_startproc
	leaq	-1(%rdx), %rax
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	movq	%rsi, %r11
	movq	%rax, %r10
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	movq	%rdx, %r12
	shrq	$63, %r10
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	andl	$1, %r12d
	movl	%ecx, %ebp
	addq	%rax, %r10
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	movq	%rdx, %rbx
	movq	(%rdi), %r8
	sarq	%r10
	cmpq	%r10, %rsi
	jge	.L2
	movq	%rsi, %rcx
	jmp	.L7
	.p2align 4,,10
	.p2align 3
.L29:
	movl	-8(%r9), %esi
.L6:
	movapd	%xmm2, %xmm1
	movq	%r9, %rdi
	movq	%r13, %rax
.L5:
	salq	$4, %rcx
	movq	%r8, %rdx
	subq	%rcx, %rdx
	movl	%esi, -8(%rdx)
	movsd	%xmm1, -16(%rdx)
	cmpq	%r10, %rax
	jge	.L28
	movq	%rax, %rcx
.L7:
	leaq	1(%rcx), %rdx
	movq	%r8, %r9
	movq	%r8, %rdi
	leaq	(%rdx,%rdx), %rax
	salq	$5, %rdx
	leaq	-1(%rax), %r13
	subq	%rdx, %rdi
	movq	%r13, %rsi
	movsd	-16(%rdi), %xmm1
	salq	$4, %rsi
	subq	%rsi, %r9
	movsd	-16(%r9), %xmm2
	comisd	%xmm1, %xmm2
	ja	.L29
	comisd	%xmm2, %xmm1
	movl	-8(%rdi), %esi
	ja	.L5
	movl	-8(%r9), %edx
	cmpl	%esi, %edx
	jle	.L5
	movl	%edx, %esi
	jmp	.L6
	.p2align 4,,10
	.p2align 3
.L28:
	testq	%r12, %r12
	je	.L16
.L8:
	leaq	-1(%rax), %rcx
	movq	%rcx, %rdx
	shrq	$63, %rdx
	addq	%rcx, %rdx
	sarq	%rdx
	cmpq	%r11, %rax
	jle	.L10
.L9:
	movq	%rdx, %rcx
	movq	%r8, %rdi
	salq	$4, %rcx
	subq	%rcx, %rdi
	movsd	-16(%rdi), %xmm1
	comisd	%xmm1, %xmm0
	ja	.L11
	comisd	%xmm0, %xmm1
	ja	.L26
	movl	-8(%rdi), %esi
	cmpl	%esi, %ebp
	jle	.L26
.L14:
	salq	$4, %rax
	movq	%r8, %rcx
	subq	%rax, %rcx
	movl	%esi, -8(%rcx)
	movsd	%xmm1, -16(%rcx)
	leaq	-1(%rdx), %rcx
	movq	%rcx, %rax
	shrq	$63, %rax
	addq	%rcx, %rax
	sarq	%rax
	movq	%rax, %rcx
	movq	%rdx, %rax
	cmpq	%rdx, %r11
	jge	.L10
	movq	%rcx, %rdx
	jmp	.L9
	.p2align 4,,10
	.p2align 3
.L2:
	movq	%rsi, %rax
	movq	%r8, %rdi
	salq	$4, %rax
	subq	%rax, %rdi
	movq	%rsi, %rax
	testq	%r12, %r12
	jne	.L10
	.p2align 4,,10
	.p2align 3
.L16:
	subq	$2, %rbx
	movq	%rbx, %rdx
	shrq	$63, %rdx
	addq	%rbx, %rdx
	sarq	%rdx
	cmpq	%rax, %rdx
	jne	.L8
	leaq	1(%rax,%rax), %rax
	movq	%r8, %rdx
	movq	%rax, %rcx
	salq	$4, %rcx
	subq	%rcx, %rdx
	movsd	-16(%rdx), %xmm1
	movl	-8(%rdx), %ecx
	movsd	%xmm1, -16(%rdi)
	movl	%ecx, -8(%rdi)
	movq	%rdx, %rdi
	jmp	.L8
	.p2align 4,,10
	.p2align 3
.L26:
	salq	$4, %rax
	movq	%r8, %rdi
	subq	%rax, %rdi
.L10:
	movl	%ebp, -8(%rdi)
	movsd	%xmm0, -16(%rdi)
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L11:
	.cfi_restore_state
	movl	-8(%rdi), %esi
	jmp	.L14
	.cfi_endproc
.LFE14554:
	.size	_ZSt13__adjust_heapISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEElS4_NS1_5__ops15_Iter_less_iterEEvT_T0_SE_T1_T2_.isra.0, .-_ZSt13__adjust_heapISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEElS4_NS1_5__ops15_Iter_less_iterEEvT_T0_SE_T1_T2_.isra.0
	.section	.text._ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEElcNS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_T0_SJ_T1_T2_.isra.0,"axG",@progbits,_ZN9CatalogueC5ERKSt6vectorI5PieceSaIS1_EE,comdat
	.p2align 4
	.type	_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEElcNS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_T0_SJ_T1_T2_.isra.0, @function
_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEElcNS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_T0_SJ_T1_T2_.isra.0:
.LFB14556:
	.cfi_startproc
	leaq	-1(%rdx), %rax
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	movq	%rdx, %r13
	movq	%rsi, %r8
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	movl	%ecx, %r9d
	movq	%rdx, %r12
	andl	$1, %r13d
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	movq	%rax, %rbp
	shrq	$63, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	addq	%rax, %rbp
	sarq	%rbp
	cmpq	%rbp, %rsi
	jl	.L33
	jmp	.L31
	.p2align 4,,10
	.p2align 3
.L38:
	movq	%rax, %rsi
.L33:
	leaq	2(%rsi,%rsi), %rax
	leaq	-1(%rax), %r10
	leaq	(%rdi,%rax), %rdx
	leaq	(%rdi,%r10), %r11
	movzbl	(%rdx), %ecx
	movzbl	(%r11), %ebx
	cmpb	%bl, %cl
	jnb	.L32
	movl	%ebx, %ecx
	movq	%r11, %rdx
	movq	%r10, %rax
.L32:
	movb	%cl, (%rdi,%rsi)
	cmpq	%rbp, %rax
	jl	.L38
	testq	%r13, %r13
	je	.L37
.L34:
	leaq	-1(%rax), %rsi
	movq	%rsi, %rcx
	shrq	$63, %rcx
	addq	%rsi, %rcx
	sarq	%rcx
	cmpq	%r8, %rax
	jle	.L35
	movl	%r9d, %r11d
	jmp	.L36
	.p2align 4,,10
	.p2align 3
.L44:
	movb	%sil, (%rdx)
	leaq	-1(%rcx), %rdx
	movq	%rdx, %rax
	shrq	$63, %rax
	addq	%rdx, %rax
	sarq	%rax
	movq	%rax, %rdx
	movq	%rcx, %rax
	cmpq	%rcx, %r8
	jge	.L43
	movq	%rdx, %rcx
.L36:
	leaq	(%rdi,%rcx), %r10
	leaq	(%rdi,%rax), %rdx
	movzbl	(%r10), %esi
	cmpb	%r11b, %sil
	jb	.L44
.L35:
	movb	%r9b, (%rdx)
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L31:
	.cfi_restore_state
	leaq	(%rdi,%rsi), %rdx
	testq	%r13, %r13
	jne	.L35
	movq	%r8, %rax
	.p2align 4,,10
	.p2align 3
.L37:
	subq	$2, %r12
	movq	%r12, %rcx
	shrq	$63, %rcx
	addq	%r12, %rcx
	sarq	%rcx
	cmpq	%rax, %rcx
	jne	.L34
	leaq	1(%rax,%rax), %rax
	leaq	(%rdi,%rax), %rcx
	movzbl	(%rcx), %esi
	movb	%sil, (%rdx)
	movq	%rcx, %rdx
	jmp	.L34
	.p2align 4,,10
	.p2align 3
.L43:
	movq	%r10, %rdx
	movb	%r9b, (%rdx)
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE14556:
	.size	_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEElcNS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_T0_SJ_T1_T2_.isra.0, .-_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEElcNS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_T0_SJ_T1_T2_.isra.0
	.text
	.p2align 4
	.type	_ZSt16__insertion_sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEENS1_5__ops15_Iter_less_iterEEvT_SD_T0_.isra.0, @function
_ZSt16__insertion_sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEENS1_5__ops15_Iter_less_iterEEvT_SD_T0_.isra.0:
.LFB14558:
	.cfi_startproc
	movq	(%rdi), %r8
	cmpq	%rsi, %r8
	je	.L45
	leaq	-16(%r8), %r9
	cmpq	%rsi, %r9
	je	.L45
	leaq	-32(%r8), %rdi
	jmp	.L59
	.p2align 4,,10
	.p2align 3
.L67:
	comisd	%xmm0, %xmm1
	ja	.L66
	cmpl	%r10d, -8(%r8)
	jg	.L48
.L66:
	movq	%r9, %rax
.L51:
	movsd	(%rax), %xmm0
	comisd	%xmm1, %xmm0
	ja	.L53
	comisd	%xmm0, %xmm1
	ja	.L54
	movl	8(%rax), %edx
	cmpl	%r10d, %edx
	jg	.L55
.L54:
	movl	%r10d, -8(%rax)
	subq	$16, %rdi
	subq	$16, %r9
	movsd	%xmm1, -16(%rax)
	cmpq	%r11, %rsi
	je	.L45
.L59:
	movsd	(%rdi), %xmm1
	movsd	-16(%r8), %xmm0
	movq	%rdi, %r11
	movl	8(%rdi), %r10d
	comisd	%xmm1, %xmm0
	jbe	.L67
.L48:
	movq	%r8, %rcx
	movq	%rdi, %rax
	subq	%r9, %rcx
	movq	%rcx, %rdx
	sarq	$4, %rdx
	testq	%rcx, %rcx
	jle	.L58
	.p2align 4,,10
	.p2align 3
.L57:
	movsd	16(%rax), %xmm0
	movl	24(%rax), %ecx
	addq	$16, %rax
	movsd	%xmm0, -16(%rax)
	movl	%ecx, -8(%rax)
	subq	$1, %rdx
	jne	.L57
.L58:
	movl	%r10d, -8(%r8)
	subq	$16, %rdi
	subq	$16, %r9
	movsd	%xmm1, -16(%r8)
	cmpq	%r11, %rsi
	jne	.L59
.L45:
	ret
	.p2align 4,,10
	.p2align 3
.L53:
	movl	8(%rax), %edx
.L55:
	movl	%edx, -8(%rax)
	addq	$16, %rax
	movsd	%xmm0, -32(%rax)
	jmp	.L51
	.cfi_endproc
.LFE14558:
	.size	_ZSt16__insertion_sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEENS1_5__ops15_Iter_less_iterEEvT_SD_T0_.isra.0, .-_ZSt16__insertion_sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEENS1_5__ops15_Iter_less_iterEEvT_SD_T0_.isra.0
	.section	.text._ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEENS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_SI_T0_.isra.0,"axG",@progbits,_ZN9CatalogueC5ERKSt6vectorI5PieceSaIS1_EE,comdat
	.p2align 4
	.type	_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEENS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_SI_T0_.isra.0, @function
_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEENS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_SI_T0_.isra.0:
.LFB14564:
	.cfi_startproc
	cmpq	%rsi, %rdi
	je	.L81
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	movq	%rsi, %r14
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	movq	%rdi, %r13
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	leaq	1(%rdi), %rbx
	cmpq	%rbx, %rsi
	je	.L68
	movl	$1, %r12d
	jmp	.L77
	.p2align 4,,10
	.p2align 3
.L84:
	movq	%rbx, %rdx
	subq	%r13, %rdx
	cmpq	$1, %rdx
	jle	.L72
	movq	%r12, %rdi
	movq	%r13, %rsi
	subq	%rdx, %rdi
	addq	%rbx, %rdi
	call	memmove@PLT
.L73:
	addq	$1, %rbx
	movb	%bpl, 0(%r13)
	cmpq	%r14, %rbx
	je	.L68
.L77:
	movzbl	0(%r13), %eax
	movzbl	(%rbx), %ebp
	movq	%rbx, %rcx
	cmpb	%al, %bpl
	jb	.L84
	movzbl	-1(%rbx), %edx
	leaq	-1(%rbx), %rax
	cmpb	%dl, %bpl
	jnb	.L75
	.p2align 4,,10
	.p2align 3
.L76:
	movb	%dl, 1(%rax)
	movq	%rax, %rcx
	movzbl	-1(%rax), %edx
	subq	$1, %rax
	cmpb	%dl, %bpl
	jb	.L76
.L75:
	addq	$1, %rbx
	movb	%bpl, (%rcx)
	cmpq	%r14, %rbx
	jne	.L77
.L68:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L72:
	.cfi_restore_state
	jne	.L73
	movb	%al, (%rbx)
	jmp	.L73
.L81:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	ret
	.cfi_endproc
.LFE14564:
	.size	_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEENS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_SI_T0_.isra.0, .-_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEENS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_SI_T0_.isra.0
	.text
	.align 2
	.p2align 4
	.type	_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareERKS4_.isra.0, @function
_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareERKS4_.isra.0:
.LFB14566:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rcx, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rsi, %rbx
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	cmpq	%rcx, %rbx
	cmovbe	%rbx, %rdx
	testq	%rdx, %rdx
	je	.L86
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L85
.L86:
	subq	%rbp, %rbx
	movl	$2147483647, %eax
	cmpq	$2147483647, %rbx
	jg	.L85
	cmpq	$-2147483648, %rbx
	movl	$-2147483648, %eax
	cmovge	%ebx, %eax
.L85:
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE14566:
	.size	_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareERKS4_.isra.0, .-_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareERKS4_.isra.0
	.section	.text._ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.isra.0,"axG",@progbits,_ZN9CatalogueC5ERKSt6vectorI5PieceSaIS1_EE,comdat
	.align 2
	.p2align 4
	.type	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.isra.0, @function
_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.isra.0:
.LFB14568:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	subq	%rsi, %rdx
	movq	%rsi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdx, %rbx
	subq	$16, %rsp
	.cfi_def_cfa_offset 48
	movq	%fs:40, %rax
	movq	%rax, 8(%rsp)
	xorl	%eax, %eax
	movq	%rdx, (%rsp)
	cmpq	$15, %rdx
	ja	.L104
	movq	(%rdi), %rdi
	cmpq	$1, %rdx
	jne	.L97
	movzbl	(%rsi), %eax
	movb	%al, (%rdi)
	movq	(%rsp), %rbx
	movq	0(%rbp), %rdi
.L98:
	movq	%rbx, 8(%rbp)
	movb	$0, (%rdi,%rbx)
	movq	8(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L105
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L97:
	.cfi_restore_state
	testq	%rdx, %rdx
	je	.L98
	jmp	.L96
	.p2align 4,,10
	.p2align 3
.L104:
	movq	%rsp, %rsi
	xorl	%edx, %edx
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@PLT
	movq	%rax, 0(%rbp)
	movq	%rax, %rdi
	movq	(%rsp), %rax
	movq	%rax, 16(%rbp)
.L96:
	movq	%rbx, %rdx
	movq	%r12, %rsi
	call	memcpy@PLT
	movq	(%rsp), %rbx
	movq	0(%rbp), %rdi
	jmp	.L98
.L105:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14568:
	.size	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.isra.0, .-_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.isra.0
	.globl	__popcountdi2
	.text
	.align 2
	.p2align 4
	.type	_ZNK6Packer5holesERK7VariantRKSt5arrayIjLm12EEi.isra.0, @function
_ZNK6Packer5holesERK7VariantRKSt5arrayIjLm12EEi.isra.0:
.LFB14570:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rdx, %rsi
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	xorl	%edx, %edx
	pxor	%xmm0, %xmm0
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$120, %rsp
	.cfi_def_cfa_offset 160
	movq	%fs:40, %rax
	movq	%rax, 104(%rsp)
	xorl	%eax, %eax
	testl	%ecx, %ecx
	movaps	%xmm0, 16(%rsp)
	movq	%rsp, %rbx
	setg	%dl
	addl	$19, %ecx
	movaps	%xmm0, (%rsp)
	leaq	48(%rsp), %rbp
	movl	%edx, %eax
	movups	%xmm0, 28(%rsp)
	orl	$262144, %eax
	cmpl	%r8d, %ecx
	movl	%edx, %ecx
	movq	$0, 80(%rsp)
	cmovl	%eax, %ecx
	movaps	%xmm0, 48(%rsp)
	xorl	%edx, %edx
	movaps	%xmm0, 64(%rsp)
	jmp	.L108
	.p2align 4,,10
	.p2align 3
.L120:
	movl	48(%rdi,%rdx,4), %eax
	orl	4(%rsi,%rdx,4), %eax
	notl	%eax
	andl	$524287, %eax
	movl	%eax, (%rbx,%rdx,4)
	andl	%ecx, %eax
	movl	%eax, 0(%rbp,%rdx,4)
	addq	$1, %rdx
.L108:
	cmpq	$10, %rdx
	jne	.L120
	movl	44(%rsi), %eax
	leaq	84(%rsp), %r10
	movl	$1, %r9d
	notl	%eax
	andl	$524287, %eax
	movl	%eax, 40(%rsp)
	movl	%eax, 88(%rsp)
.L109:
	movq	%r10, %rcx
	movl	$10, %edx
	xorl	%edi, %edi
	.p2align 4,,10
	.p2align 3
.L113:
	movl	4(%rcx), %esi
	movl	%esi, %r8d
	leal	(%rsi,%rsi), %eax
	shrl	%r8d
	orl	%r8d, %eax
	orl	%esi, %eax
	testl	%edx, %edx
	je	.L110
	orl	(%rcx), %eax
	cmpl	$10, %edx
	je	.L111
.L110:
	orl	8(%rcx), %eax
.L111:
	andl	(%rbx,%rdx,4), %eax
	cmpl	%eax, %esi
	movl	%eax, 4(%rcx)
	cmovne	%r9d, %edi
	subq	$1, %rdx
	subq	$4, %rcx
	cmpq	$-1, %rdx
	jne	.L113
	testb	%dil, %dil
	jne	.L109
	xorl	%r12d, %r12d
	xorl	%r13d, %r13d
	.p2align 4,,10
	.p2align 3
.L114:
	movl	0(%rbp,%r12), %edi
	notl	%edi
	andl	(%rbx,%r12), %edi
	addq	$4, %r12
	call	__popcountdi2@PLT
	addl	%eax, %r13d
	cmpq	$44, %r12
	jne	.L114
	movq	104(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L121
	addq	$120, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	movl	%r13d, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L121:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14570:
	.size	_ZNK6Packer5holesERK7VariantRKSt5arrayIjLm12EEi.isra.0, .-_ZNK6Packer5holesERK7VariantRKSt5arrayIjLm12EEi.isra.0
	.section	.text._ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEElNS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_SI_T0_T1_,"axG",@progbits,_ZN9CatalogueC5ERKSt6vectorI5PieceSaIS1_EE,comdat
	.p2align 4
	.type	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEElNS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_SI_T0_T1_, @function
_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEElNS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_SI_T0_T1_:
.LFB12675:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	movq	%rsi, %r13
	subq	%rdi, %r13
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	cmpq	$16, %r13
	jle	.L122
	movq	%rdi, %r12
	movq	%rdx, %r14
	movq	%rsi, %rbp
	testq	%rdx, %rdx
	je	.L145
	movq	%rsi, %r8
	leaq	1(%r12), %rbx
.L125:
	sarq	%r13
	movzwl	(%r12), %esi
	movzbl	1(%r12), %edx
	subq	$1, %r14
	leaq	(%r12,%r13), %rax
	movzbl	-1(%r8), %r9d
	movzbl	(%r12), %ecx
	movzbl	(%rax), %edi
	rolw	$8, %si
	cmpb	%dil, %dl
	jnb	.L131
	cmpb	%r9b, %dil
	jb	.L137
	cmpb	%r9b, %dl
	jb	.L155
.L134:
	movw	%si, (%r12)
	movzbl	-1(%r8), %esi
.L133:
	movq	%r8, %rdi
	movq	%rbx, %rax
	cmpb	%dl, %cl
	jnb	.L148
	.p2align 4,,10
	.p2align 3
.L157:
	addq	$1, %rax
	.p2align 4,,10
	.p2align 3
.L139:
	movzbl	(%rax), %ecx
	movq	%rax, %rbp
	addq	$1, %rax
	cmpb	%dl, %cl
	jb	.L139
	cmpb	%sil, %dl
	jnb	.L140
.L158:
	leaq	-2(%rdi), %rax
	.p2align 4,,10
	.p2align 3
.L141:
	movzbl	(%rax), %esi
	movq	%rax, %rdi
	subq	$1, %rax
	cmpb	%sil, %dl
	jb	.L141
	cmpq	%rdi, %rbp
	jnb	.L156
.L143:
	movb	%sil, 0(%rbp)
	leaq	1(%rbp), %rax
	movzbl	-1(%rdi), %esi
	movb	%cl, (%rdi)
	movzbl	(%r12), %edx
	movzbl	1(%rbp), %ecx
	cmpb	%dl, %cl
	jb	.L157
.L148:
	movq	%rax, %rbp
	cmpb	%sil, %dl
	jb	.L158
	.p2align 4,,10
	.p2align 3
.L140:
	subq	$1, %rdi
	cmpq	%rdi, %rbp
	jb	.L143
	.p2align 4,,10
	.p2align 3
.L156:
	movq	%rbp, %r13
	movq	%r14, %rdx
	movq	%r8, %rsi
	movq	%rbp, %rdi
	call	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEElNS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_SI_T0_T1_
	subq	%r12, %r13
	cmpq	$16, %r13
	jle	.L122
	testq	%r14, %r14
	je	.L145
	movq	%rbp, %r8
	jmp	.L125
.L131:
	cmpb	%r9b, %dl
	jb	.L134
	cmpb	%r9b, %dil
	jnb	.L137
.L155:
	movb	%r9b, (%r12)
	movl	%ecx, %esi
	movb	%cl, -1(%r8)
	movzbl	(%r12), %edx
	movzbl	1(%r12), %ecx
	jmp	.L133
.L137:
	movb	%dil, (%r12)
	movb	%cl, (%rax)
	movzbl	(%r12), %edx
	movzbl	1(%r12), %ecx
	movzbl	-1(%r8), %esi
	jmp	.L133
.L145:
	leaq	-2(%r13), %rbx
	sarq	%rbx
	jmp	.L127
.L159:
	subq	$1, %rbx
.L127:
	movsbl	(%r12,%rbx), %ecx
	movq	%r13, %rdx
	movq	%rbx, %rsi
	movq	%r12, %rdi
	call	_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEElcNS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_T0_SJ_T1_T2_.isra.0
	testq	%rbx, %rbx
	jne	.L159
	subq	$1, %rbp
	.p2align 4,,10
	.p2align 3
.L128:
	movzbl	(%r12), %eax
	movsbl	0(%rbp), %ecx
	movq	%rbp, %rbx
	xorl	%esi, %esi
	subq	%r12, %rbx
	movq	%r12, %rdi
	subq	$1, %rbp
	movb	%al, 1(%rbp)
	movq	%rbx, %rdx
	call	_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEElcNS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_T0_SJ_T1_T2_.isra.0
	cmpq	$1, %rbx
	jg	.L128
.L122:
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE12675:
	.size	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEElNS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_SI_T0_T1_, .-_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEElNS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_SI_T0_T1_
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"vector::_M_realloc_insert"
	.text
	.align 2
	.p2align 4
	.type	_ZNSt6vectorIiSaIiEE12emplace_backIJiEEERiDpOT_.isra.0, @function
_ZNSt6vectorIiSaIiEE12emplace_backIJiEEERiDpOT_.isra.0:
.LFB14575:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	8(%rdi), %rax
	cmpq	16(%rdi), %rax
	je	.L161
	movl	(%rsi), %edx
	addq	$4, %rax
	movl	%edx, -4(%rax)
	movq	%rax, 8(%rdi)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L161:
	.cfi_restore_state
	movabsq	$2305843009213693951, %rcx
	movq	(%rdi), %r13
	movq	%rax, %r14
	subq	%r13, %r14
	movq	%r14, %rdx
	sarq	$2, %rdx
	cmpq	%rcx, %rdx
	je	.L179
	cmpq	%r13, %rax
	je	.L180
	leaq	(%rdx,%rdx), %rax
	cmpq	%rdx, %rax
	jb	.L173
	testq	%rax, %rax
	jne	.L181
	xorl	%ebp, %ebp
	xorl	%r12d, %r12d
.L168:
	movl	(%rsi), %eax
	leaq	4(%r12,%r14), %r15
	movl	%eax, (%r12,%r14)
	testq	%r14, %r14
	jg	.L182
	testq	%r13, %r13
	jne	.L183
.L171:
	movq	%r12, (%rbx)
	movq	%r15, 8(%rbx)
	movq	%rbp, 16(%rbx)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L182:
	.cfi_restore_state
	movq	%r13, %rsi
	movq	%r14, %rdx
	movq	%r12, %rdi
	call	memmove@PLT
	movq	16(%rbx), %rsi
	subq	%r13, %rsi
.L170:
	movq	%r13, %rdi
	call	_ZdlPvm@PLT
	jmp	.L171
	.p2align 4,,10
	.p2align 3
.L180:
	addq	$1, %rdx
	jc	.L173
	movabsq	$2305843009213693951, %rax
	cmpq	%rax, %rdx
	cmovbe	%rdx, %rax
	movq	%rax, %rbp
	salq	$2, %rbp
.L167:
	movq	%rbp, %rdi
	movq	%rsi, 8(%rsp)
	call	_Znwm@PLT
	movq	8(%rsp), %rsi
	movq	%rax, %r12
	addq	%rax, %rbp
	jmp	.L168
	.p2align 4,,10
	.p2align 3
.L173:
	movabsq	$9223372036854775804, %rbp
	jmp	.L167
	.p2align 4,,10
	.p2align 3
.L183:
	movq	16(%rbx), %rsi
	subq	%r13, %rsi
	jmp	.L170
.L181:
	movabsq	$2305843009213693951, %rdx
	cmpq	%rdx, %rax
	cmova	%rdx, %rax
	leaq	0(,%rax,4), %rbp
	jmp	.L167
.L179:
	leaq	.LC0(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE14575:
	.size	_ZNSt6vectorIiSaIiEE12emplace_backIJiEEERiDpOT_.isra.0, .-_ZNSt6vectorIiSaIiEE12emplace_backIJiEEERiDpOT_.isra.0
	.align 2
	.p2align 4
	.type	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEaSEOS4_.isra.0, @function
_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEaSEOS4_.isra.0:
.LFB14580:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	leaq	16(%rbp), %rax
	movq	%rsi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	(%rdi), %rdi
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	cmpq	%rax, %rdi
	leaq	16(%rbx), %rax
	je	.L200
	cmpq	%rsi, %rax
	je	.L186
	movq	%rsi, 0(%rbp)
	movq	16(%rbp), %rcx
	movq	%rdx, 8(%rbp)
	movq	16(%rbx), %rdx
	movq	%rdx, 16(%rbp)
	testq	%rdi, %rdi
	je	.L194
	movq	%rdi, (%rbx)
	movq	%rcx, 16(%rbx)
.L189:
	movq	$0, 8(%rbx)
	movb	$0, (%rdi)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L200:
	.cfi_restore_state
	cmpq	%rsi, %rax
	je	.L186
	movq	%rsi, 0(%rbp)
	movq	%rax, %rdi
	movq	%rdx, 8(%rbp)
	movq	16(%rbx), %rdx
	movq	%rdx, 16(%rbp)
.L192:
	movq	%rdi, (%rbx)
	jmp	.L189
	.p2align 4,,10
	.p2align 3
.L186:
	cmpq	%rbx, %rbp
	je	.L193
	testq	%rdx, %rdx
	je	.L190
	cmpq	$1, %rdx
	je	.L201
	call	memcpy@PLT
	movq	8(%rbx), %rdx
	movq	0(%rbp), %rdi
.L190:
	movq	%rdx, 8(%rbp)
	movb	$0, (%rdi,%rdx)
	movq	(%rbx), %rdi
	jmp	.L189
	.p2align 4,,10
	.p2align 3
.L194:
	movq	%rax, %rdi
	jmp	.L192
	.p2align 4,,10
	.p2align 3
.L201:
	movzbl	(%rsi), %eax
	movb	%al, (%rdi)
	movq	8(%rbx), %rdx
	movq	0(%rbp), %rdi
	jmp	.L190
	.p2align 4,,10
	.p2align 3
.L193:
	movq	%rsi, %rdi
	jmp	.L189
	.cfi_endproc
.LFE14580:
	.size	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEaSEOS4_.isra.0, .-_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEaSEOS4_.isra.0
	.p2align 4
	.type	_ZSt16__introsort_loopISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEElNS1_5__ops15_Iter_less_iterEEvT_SD_T0_T1_.isra.0, @function
_ZSt16__introsort_loopISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEElNS1_5__ops15_Iter_less_iterEEvT_SD_T0_T1_.isra.0:
.LFB14582:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	movq	(%rdi), %rcx
	movq	(%rsi), %rbx
	movq	%fs:40, %rax
	movq	%rax, 40(%rsp)
	xorl	%eax, %eax
	movq	%rcx, %rax
	subq	%rbx, %rax
	cmpq	$256, %rax
	jle	.L202
	movq	%rdi, %r12
	movq	%rsi, %r14
	movq	%rdx, %r15
	testq	%rdx, %rdx
	je	.L243
	leaq	32(%rsp), %rbp
	leaq	24(%rsp), %r13
.L205:
	sarq	$5, %rax
	movq	%rcx, %rdx
	movsd	-32(%rcx), %xmm1
	subq	$1, %r15
	salq	$4, %rax
	subq	%rax, %rdx
	leaq	-16(%rcx), %rax
	movsd	-16(%rdx), %xmm0
	comisd	%xmm1, %xmm0
	ja	.L220
	comisd	%xmm0, %xmm1
	ja	.L221
	movl	-8(%rdx), %esi
	cmpl	%esi, -24(%rcx)
	jge	.L221
	.p2align 4,,10
	.p2align 3
.L220:
	movsd	(%rbx), %xmm2
	comisd	%xmm0, %xmm2
	ja	.L233
	comisd	%xmm2, %xmm0
	ja	.L225
	movl	8(%rbx), %esi
	cmpl	%esi, -8(%rdx)
	jge	.L225
	.p2align 4,,10
	.p2align 3
.L233:
	movsd	-16(%rcx), %xmm1
	movl	-8(%rcx), %esi
	movsd	%xmm0, -16(%rcx)
	movl	-8(%rdx), %edi
	movsd	%xmm1, -16(%rdx)
	movl	%edi, -8(%rcx)
	movl	%esi, -8(%rdx)
.L228:
	movq	%rbx, %rdx
	movq	%rax, %rbx
	jmp	.L242
	.p2align 4,,10
	.p2align 3
.L256:
	comisd	%xmm0, %xmm1
	ja	.L236
	movl	-8(%rcx), %eax
	cmpl	%eax, -8(%rbx)
	jl	.L235
.L236:
	leaq	16(%rdx), %rax
.L237:
	movsd	-16(%rax), %xmm2
	movq	%rax, %rdx
	comisd	%xmm0, %xmm2
	ja	.L238
	comisd	%xmm2, %xmm0
	ja	.L239
	movl	-8(%rax), %edi
	cmpl	%edi, -8(%rcx)
	jl	.L238
.L239:
	cmpq	%rbx, %rax
	jnb	.L255
	movl	-8(%rbx), %esi
	movl	-8(%rax), %edi
	movsd	%xmm2, -16(%rbx)
	subq	$16, %rbx
	movsd	%xmm1, -16(%rax)
	movl	%edi, 8(%rbx)
	movl	%esi, -8(%rax)
.L242:
	movsd	-16(%rcx), %xmm0
.L234:
	movsd	-16(%rbx), %xmm1
	comisd	%xmm1, %xmm0
	jbe	.L256
.L235:
	subq	$16, %rbx
	jmp	.L234
	.p2align 4,,10
	.p2align 3
.L221:
	movsd	(%rbx), %xmm2
	comisd	%xmm1, %xmm2
	ja	.L222
	comisd	%xmm2, %xmm1
	ja	.L230
	movl	8(%rbx), %esi
	cmpl	%esi, -24(%rcx)
	jge	.L230
	.p2align 4,,10
	.p2align 3
.L222:
	movsd	-16(%rcx), %xmm0
	movl	-8(%rcx), %edx
	movsd	%xmm1, -16(%rcx)
	movl	-24(%rcx), %esi
	movsd	%xmm0, -32(%rcx)
	movl	%esi, -8(%rcx)
	movl	%edx, -24(%rcx)
	jmp	.L228
.L230:
	comisd	%xmm0, %xmm2
	jbe	.L257
.L231:
	movsd	-16(%rcx), %xmm0
	movl	-8(%rcx), %edx
	movsd	%xmm2, -16(%rcx)
	movl	8(%rbx), %esi
	movsd	%xmm0, (%rbx)
	movl	%esi, -8(%rcx)
	movl	%edx, 8(%rbx)
	jmp	.L228
.L225:
	comisd	%xmm1, %xmm2
	ja	.L231
	comisd	%xmm2, %xmm1
	ja	.L222
	movl	8(%rbx), %esi
	cmpl	%esi, -24(%rcx)
	jl	.L231
	jmp	.L222
	.p2align 4,,10
	.p2align 3
.L238:
	addq	$16, %rax
	jmp	.L237
	.p2align 4,,10
	.p2align 3
.L255:
	movq	(%r14), %rax
	movq	%r15, %rdx
	movq	%rbp, %rsi
	movq	%r13, %rdi
	movq	%rbx, 24(%rsp)
	movq	%rax, 32(%rsp)
	call	_ZSt16__introsort_loopISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEElNS1_5__ops15_Iter_less_iterEEvT_SD_T0_T1_.isra.0
	movq	%rbx, (%r14)
	movq	(%r12), %rcx
	movq	%rcx, %rax
	subq	%rbx, %rax
	cmpq	$256, %rax
	jle	.L202
	testq	%r15, %r15
	jne	.L205
.L243:
	movq	(%r12), %r12
	movq	(%r14), %rbx
	movq	%r12, %r14
	movq	%rbx, 24(%rsp)
	subq	%rbx, %r14
	movq	%rbx, 16(%rsp)
	movq	%r12, 8(%rsp)
	cmpq	$16, %r14
	jle	.L202
	sarq	$4, %r14
	leaq	32(%rsp), %rbp
	leaq	-2(%r14), %rax
	movq	%rax, %r15
	shrq	$63, %r15
	addq	%rax, %r15
	sarq	%r15
	movq	%r15, %r13
	notq	%r13
	salq	$4, %r13
	addq	%r12, %r13
	jmp	.L211
	.p2align 4,,10
	.p2align 3
.L258:
	subq	$1, %r15
.L211:
	movsd	0(%r13), %xmm0
	movl	8(%r13), %ecx
	movq	%r14, %rdx
	movq	%r15, %rsi
	movq	%rbp, %rdi
	movq	%r12, 32(%rsp)
	addq	$16, %r13
	call	_ZSt13__adjust_heapISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEElS4_NS1_5__ops15_Iter_less_iterEEvT_T0_SE_T1_T2_.isra.0
	testq	%r15, %r15
	jne	.L258
	.p2align 4,,10
	.p2align 3
.L219:
	movl	-8(%r12), %eax
	addq	$16, %rbx
	movq	%r12, %r13
	movl	-8(%rbx), %ecx
	movsd	-16(%r12), %xmm1
	subq	%rbx, %r13
	xorl	%esi, %esi
	movq	%rbp, %rdi
	movl	%eax, -8(%rbx)
	movq	%r13, %rdx
	movsd	-16(%rbx), %xmm0
	sarq	$4, %rdx
	movsd	%xmm1, -16(%rbx)
	movq	%r12, 32(%rsp)
	call	_ZSt13__adjust_heapISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEElS4_NS1_5__ops15_Iter_less_iterEEvT_T0_SE_T1_T2_.isra.0
	cmpq	$16, %r13
	jg	.L219
.L202:
	movq	40(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L259
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L257:
	.cfi_restore_state
	comisd	%xmm2, %xmm0
	ja	.L233
	movl	8(%rbx), %esi
	cmpl	%esi, -8(%rdx)
	jl	.L231
	jmp	.L233
.L259:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14582:
	.size	_ZSt16__introsort_loopISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEElNS1_5__ops15_Iter_less_iterEEvT_SD_T0_T1_.isra.0, .-_ZSt16__introsort_loopISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEElNS1_5__ops15_Iter_less_iterEEvT_SD_T0_T1_.isra.0
	.p2align 4
	.type	_ZSt4sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEEEvT_SB_.isra.0, @function
_ZSt4sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEEEvT_SB_.isra.0:
.LFB14591:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$40, %rsp
	.cfi_def_cfa_offset 80
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	xorl	%eax, %eax
	cmpq	%rsi, %rdi
	je	.L260
	movq	%rdi, %r12
	movq	%rsi, 8(%rsp)
	movq	%rdi, %rbp
	movq	%rsi, %rbx
	subq	%rsi, %r12
	movq	%rdi, 16(%rsp)
	movq	%r12, %rax
	sarq	$4, %rax
	je	.L274
	bsrq	%rax, %rdx
	leaq	16(%rsp), %r13
	leaq	8(%rsp), %rsi
	movslq	%edx, %rdx
	movq	%r13, %rdi
	addq	%rdx, %rdx
	call	_ZSt16__introsort_loopISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEElNS1_5__ops15_Iter_less_iterEEvT_SD_T0_T1_.isra.0
	cmpq	$256, %r12
	jle	.L263
	leaq	-256(%rbp), %rsi
	movq	%r13, %rdi
	movq	%rbp, 16(%rsp)
	call	_ZSt16__insertion_sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEENS1_5__ops15_Iter_less_iterEEvT_SD_T0_.isra.0
	cmpq	%rbx, %rsi
	jne	.L264
	jmp	.L260
	.p2align 4,,10
	.p2align 3
.L275:
	comisd	%xmm0, %xmm1
	ja	.L267
	movl	8(%rax), %edx
	cmpl	%edx, %ecx
	jl	.L268
.L267:
	subq	$16, %rsi
	movl	%ecx, -8(%rax)
	movsd	%xmm1, -16(%rax)
	cmpq	%rbx, %rsi
	je	.L260
.L264:
	movsd	-16(%rsi), %xmm1
	movl	-8(%rsi), %ecx
	movq	%rsi, %rax
.L265:
	movsd	(%rax), %xmm0
	comisd	%xmm1, %xmm0
	jbe	.L275
	movl	8(%rax), %edx
.L268:
	movl	%edx, -8(%rax)
	addq	$16, %rax
	movsd	%xmm0, -32(%rax)
	jmp	.L265
	.p2align 4,,10
	.p2align 3
.L274:
	leaq	16(%rsp), %r13
	leaq	8(%rsp), %rsi
	movq	$-2, %rdx
	movq	%r13, %rdi
	call	_ZSt16__introsort_loopISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEElNS1_5__ops15_Iter_less_iterEEvT_SD_T0_T1_.isra.0
.L263:
	movq	%rbx, %rsi
	movq	%r13, %rdi
	movq	%rbp, 16(%rsp)
	call	_ZSt16__insertion_sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEENS1_5__ops15_Iter_less_iterEEvT_SD_T0_.isra.0
.L260:
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L276
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L276:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14591:
	.size	_ZSt4sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEEEvT_SB_.isra.0, .-_ZSt4sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEEEvT_SB_.isra.0
	.align 2
	.p2align 4
	.type	_ZNSt6vectorI9PlacementSaIS0_EEaSERKS2_.isra.0, @function
_ZNSt6vectorI9PlacementSaIS0_EEaSERKS2_.isra.0:
.LFB14596:
	.cfi_startproc
	cmpq	%rdi, %rsi
	je	.L297
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	movq	%rdi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	8(%rsi), %rcx
	movq	(%rsi), %r13
	movq	(%rdi), %rdi
	movq	16(%rbx), %rax
	movq	%rcx, %r12
	subq	%r13, %r12
	subq	%rdi, %rax
	cmpq	%r12, %rax
	jb	.L300
	movq	8(%rbx), %r8
	movq	%r8, %rdx
	subq	%rdi, %rdx
	cmpq	%r12, %rdx
	jb	.L285
	cmpq	$24, %r12
	jle	.L286
	movq	%r12, %rdx
	movq	%r13, %rsi
	call	memmove@PLT
	movq	(%rbx), %rax
	addq	%r12, %rax
.L284:
	movq	%rax, 8(%rbx)
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L297:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	ret
	.p2align 4,,10
	.p2align 3
.L285:
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -40
	.cfi_offset 6, -32
	.cfi_offset 12, -24
	.cfi_offset 13, -16
	cmpq	$24, %rdx
	jle	.L288
	movq	%r13, %rsi
	call	memmove@PLT
	movq	8(%rbx), %r8
	movq	(%rbx), %rdi
	movq	8(%rbp), %rcx
	movq	0(%rbp), %r13
	movq	%r8, %rdx
	subq	%rdi, %rdx
.L289:
	leaq	0(%r13,%rdx), %rsi
	subq	%rsi, %rcx
	movq	%rcx, %rdx
	cmpq	$24, %rcx
	jle	.L290
	movq	%r8, %rdi
	call	memmove@PLT
	movq	(%rbx), %rax
	addq	%r12, %rax
	movq	%rax, 8(%rbx)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L300:
	.cfi_restore_state
	movabsq	$9223372036854775800, %rax
	cmpq	%r12, %rax
	jb	.L301
	movq	%r12, %rdi
	call	_Znwm@PLT
	movq	%rax, %rbp
	cmpq	$24, %r12
	jle	.L281
	movq	%r12, %rdx
	movq	%r13, %rsi
	movq	%rax, %rdi
	call	memmove@PLT
.L282:
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L283
	movq	16(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L283:
	leaq	0(%rbp,%r12), %rax
	movq	%rbp, (%rbx)
	movq	%rax, 16(%rbx)
	movq	%rax, 8(%rbx)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L286:
	.cfi_restore_state
	leaq	(%rdi,%r12), %rax
	jne	.L284
	movdqu	0(%r13), %xmm0
	movups	%xmm0, (%rdi)
	movq	16(%r13), %rdx
	movq	%rdx, 16(%rdi)
	jmp	.L284
	.p2align 4,,10
	.p2align 3
.L288:
	jne	.L289
	movdqu	0(%r13), %xmm1
	movups	%xmm1, (%rdi)
	movq	16(%r13), %rax
	movq	%rax, 16(%rdi)
	jmp	.L289
	.p2align 4,,10
	.p2align 3
.L290:
	leaq	(%rdi,%r12), %rax
	jne	.L284
	movdqu	(%rsi), %xmm2
	movups	%xmm2, (%r8)
	movq	16(%rsi), %rdx
	movq	%rdx, 16(%r8)
	jmp	.L284
	.p2align 4,,10
	.p2align 3
.L281:
	movdqu	0(%r13), %xmm3
	movups	%xmm3, (%rax)
	movq	16(%r13), %rax
	movq	%rax, 16(%rbp)
	jmp	.L282
	.p2align 4,,10
	.p2align 3
.L301:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
	.cfi_endproc
.LFE14596:
	.size	_ZNSt6vectorI9PlacementSaIS0_EEaSERKS2_.isra.0, .-_ZNSt6vectorI9PlacementSaIS0_EEaSERKS2_.isra.0
	.align 2
	.p2align 4
	.type	_ZN10BeamPacker5StateaSEOS0_.isra.0, @function
_ZN10BeamPacker5StateaSEOS0_.isra.0:
.LFB14602:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsi, %rbp
	pxor	%xmm0, %xmm0
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movdqu	0(%rbp), %xmm1
	movq	(%rdi), %rdi
	movq	16(%rbx), %rsi
	movups	%xmm1, (%rbx)
	movq	16(%rbp), %rax
	movq	%rax, 16(%rbx)
	movq	$0, 16(%rbp)
	movups	%xmm0, 0(%rbp)
	testq	%rdi, %rdi
	je	.L303
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L303:
	movdqu	24(%rbp), %xmm2
	movq	24(%rbx), %rdi
	pxor	%xmm0, %xmm0
	movq	40(%rbx), %rsi
	movups	%xmm2, 24(%rbx)
	movq	40(%rbp), %rax
	movq	%rax, 40(%rbx)
	movq	$0, 40(%rbp)
	movups	%xmm0, 24(%rbp)
	testq	%rdi, %rdi
	je	.L304
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L304:
	movdqu	48(%rbp), %xmm3
	movq	48(%rbx), %rdi
	pxor	%xmm0, %xmm0
	movq	64(%rbx), %rsi
	movups	%xmm3, 48(%rbx)
	movq	64(%rbp), %rax
	movq	%rax, 64(%rbx)
	movq	$0, 64(%rbp)
	movups	%xmm0, 48(%rbp)
	testq	%rdi, %rdi
	je	.L305
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L305:
	movdqu	88(%rbp), %xmm0
	movdqu	72(%rbp), %xmm4
	movdqu	112(%rbp), %xmm5
	movups	%xmm0, 88(%rbx)
	movsd	104(%rbp), %xmm0
	movups	%xmm4, 72(%rbx)
	movsd	%xmm0, 104(%rbx)
	movups	%xmm5, 112(%rbx)
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE14602:
	.size	_ZN10BeamPacker5StateaSEOS0_.isra.0, .-_ZN10BeamPacker5StateaSEOS0_.isra.0
	.align 2
	.p2align 4
	.type	_ZNSt6vectorIiSaIiEEaSERKS1_.isra.0, @function
_ZNSt6vectorIiSaIiEEaSERKS1_.isra.0:
.LFB14610:
	.cfi_startproc
	cmpq	%rdi, %rsi
	je	.L337
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	movq	%rdi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	8(%rsi), %rcx
	movq	(%rsi), %r13
	movq	(%rdi), %rdi
	movq	16(%rbx), %rax
	movq	%rcx, %r12
	subq	%r13, %r12
	subq	%rdi, %rax
	cmpq	%r12, %rax
	jb	.L340
	movq	8(%rbx), %r8
	movq	%r8, %rdx
	subq	%rdi, %rdx
	cmpq	%r12, %rdx
	jb	.L324
	cmpq	$4, %r12
	jle	.L325
	movq	%r12, %rdx
	movq	%r13, %rsi
	call	memmove@PLT
	movq	(%rbx), %rax
	addq	%r12, %rax
.L323:
	movq	%rax, 8(%rbx)
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L337:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	ret
	.p2align 4,,10
	.p2align 3
.L324:
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -40
	.cfi_offset 6, -32
	.cfi_offset 12, -24
	.cfi_offset 13, -16
	cmpq	$4, %rdx
	jle	.L328
	movq	%r13, %rsi
	call	memmove@PLT
	movq	8(%rbx), %r8
	movq	(%rbx), %rdi
	movq	8(%rbp), %rcx
	movq	0(%rbp), %r13
	movq	%r8, %rdx
	subq	%rdi, %rdx
.L329:
	leaq	0(%r13,%rdx), %rsi
	subq	%rsi, %rcx
	movq	%rcx, %rdx
	cmpq	$4, %rcx
	jle	.L330
	movq	%r8, %rdi
	call	memmove@PLT
	movq	(%rbx), %rax
	addq	%r12, %rax
	movq	%rax, 8(%rbx)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L340:
	.cfi_restore_state
	movabsq	$9223372036854775804, %rax
	cmpq	%r12, %rax
	jb	.L341
	movq	%r12, %rdi
	call	_Znwm@PLT
	movq	%rax, %rbp
	cmpq	$4, %r12
	jle	.L320
	movq	%r12, %rdx
	movq	%r13, %rsi
	movq	%rax, %rdi
	call	memmove@PLT
.L321:
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L322
	movq	16(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L322:
	leaq	0(%rbp,%r12), %rax
	movq	%rbp, (%rbx)
	movq	%rax, 16(%rbx)
	movq	%rax, 8(%rbx)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L325:
	.cfi_restore_state
	leaq	(%rdi,%r12), %rax
	jne	.L323
	movl	0(%r13), %edx
	movl	%edx, (%rdi)
	jmp	.L323
	.p2align 4,,10
	.p2align 3
.L328:
	jne	.L329
	movl	0(%r13), %eax
	movl	%eax, (%rdi)
	jmp	.L329
	.p2align 4,,10
	.p2align 3
.L330:
	leaq	(%rdi,%r12), %rax
	jne	.L323
	movl	(%rsi), %edx
	movl	%edx, (%r8)
	jmp	.L323
	.p2align 4,,10
	.p2align 3
.L320:
	movl	0(%r13), %eax
	movl	%eax, 0(%rbp)
	jmp	.L321
	.p2align 4,,10
	.p2align 3
.L341:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
	.cfi_endproc
.LFE14610:
	.size	_ZNSt6vectorIiSaIiEEaSERKS1_.isra.0, .-_ZNSt6vectorIiSaIiEEaSERKS1_.isra.0
	.section	.text._ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E.isra.0,"axG",@progbits,_ZN9CatalogueC5ERKSt6vectorI5PieceSaIS1_EE,comdat
	.align 2
	.p2align 4
	.type	_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E.isra.0, @function
_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E.isra.0:
.LFB14613:
	.cfi_startproc
	testq	%rdi, %rdi
	je	.L351
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
.L345:
	movq	24(%rbx), %rdi
	movq	%rbx, %rbp
	call	_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E.isra.0
	movq	32(%rbp), %rdi
	leaq	48(%rbp), %rax
	movq	16(%rbx), %rbx
	cmpq	%rax, %rdi
	je	.L344
	movq	48(%rbp), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L344:
	movl	$72, %esi
	movq	%rbp, %rdi
	call	_ZdlPvm@PLT
	testq	%rbx, %rbx
	jne	.L345
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L351:
	.cfi_restore 3
	.cfi_restore 6
	ret
	.cfi_endproc
.LFE14613:
	.size	_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E.isra.0, .-_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E.isra.0
	.section	.text._ZSt25__unguarded_linear_insertIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops14_Val_less_iterEEvT_T0_.isra.0,"axG",@progbits,_ZN9CatalogueC5ERKSt6vectorI5PieceSaIS1_EE,comdat
	.p2align 4
	.type	_ZSt25__unguarded_linear_insertIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops14_Val_less_iterEEvT_T0_.isra.0, @function
_ZSt25__unguarded_linear_insertIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops14_Val_less_iterEEvT_T0_.isra.0:
.LFB14618:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	movq	(%rdi), %rdi
	movq	8(%rbx), %r14
	movq	%fs:40, %rax
	movq	%rax, 56(%rsp)
	xorl	%eax, %eax
	leaq	32(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	%rax, 16(%rsp)
	leaq	16(%rbx), %rax
	cmpq	%rax, %rdi
	je	.L400
	movq	16(%rbx), %rdx
	movq	%rdi, 16(%rsp)
	movq	%rdx, 32(%rsp)
.L362:
	movq	%rax, (%rbx)
	movl	$2147483648, %r12d
	subq	$16, %rbx
	movq	$0, 24(%rbx)
	movb	$0, 32(%rbx)
	movq	%r14, 24(%rsp)
	jmp	.L363
	.p2align 4,,10
	.p2align 3
.L364:
	cmpq	%rbx, %r13
	je	.L365
	movq	(%rbx), %rax
	movq	32(%rbx), %rdx
	movq	%r13, 16(%rbx)
	movq	%r15, 24(%rbx)
	movq	%rax, 32(%rbx)
	testq	%rdi, %rdi
	je	.L371
	movq	%rdi, -16(%rbx)
	movq	%rdx, (%rbx)
.L368:
	movq	$0, -8(%rbx)
	subq	$32, %rbx
	movb	$0, (%rdi)
	movq	16(%rsp), %rdi
	movq	24(%rsp), %r14
.L363:
	movq	-8(%rbx), %r15
	movq	%r14, %rdx
	movq	-16(%rbx), %r13
	leaq	16(%rbx), %rbp
	cmpq	%r14, %r15
	cmovbe	%r15, %rdx
	testq	%rdx, %rdx
	je	.L372
	movq	%r13, %rsi
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L373
.L372:
	movq	%r14, %rax
	subq	%r15, %rax
	cmpq	%r12, %rax
	jge	.L374
	movabsq	$-2147483649, %rcx
	cmpq	%rcx, %rax
	jle	.L375
.L373:
	testl	%eax, %eax
	jns	.L374
.L375:
	movq	16(%rbx), %rdi
	leaq	32(%rbx), %rax
	cmpq	%rax, %rdi
	jne	.L364
	cmpq	%rbx, %r13
	je	.L365
	movq	(%rbx), %rax
	movq	%r13, 16(%rbx)
	movq	%r15, 24(%rbx)
	movq	%rax, 32(%rbx)
.L371:
	movq	%rbx, -16(%rbx)
	movq	%rbx, %rdi
	jmp	.L368
	.p2align 4,,10
	.p2align 3
.L365:
	leaq	-16(%rbx), %rax
	cmpq	%rax, %rbp
	je	.L378
	testq	%r15, %r15
	je	.L369
	cmpq	$1, %r15
	je	.L401
	movq	%r15, %rdx
	movq	%r13, %rsi
	call	memcpy@PLT
	movq	-8(%rbx), %r15
	movq	16(%rbx), %rdi
.L369:
	movq	%r15, 24(%rbx)
	movb	$0, (%rdi,%r15)
	movq	-16(%rbx), %rdi
	jmp	.L368
	.p2align 4,,10
	.p2align 3
.L374:
	movq	%rbp, %rdi
	leaq	16(%rsp), %rsi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEaSEOS4_.isra.0
	movq	16(%rsp), %rdi
	movq	8(%rsp), %rax
	cmpq	%rax, %rdi
	je	.L354
	movq	32(%rsp), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L354:
	movq	56(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L402
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L401:
	.cfi_restore_state
	movzbl	0(%r13), %eax
	movb	%al, (%rdi)
	movq	-8(%rbx), %r15
	movq	16(%rbx), %rdi
	movq	%r15, 24(%rbx)
	movb	$0, (%rdi,%r15)
	movq	-16(%rbx), %rdi
	jmp	.L368
	.p2align 4,,10
	.p2align 3
.L400:
	leaq	1(%r14), %rsi
	movq	8(%rsp), %r8
	movq	%rax, %rdx
	cmpl	$8, %esi
	jnb	.L403
.L356:
	xorl	%edi, %edi
	testb	$4, %sil
	je	.L359
	movl	(%rdx), %edi
	movl	%edi, (%r8)
	movl	$4, %edi
.L359:
	testb	$2, %sil
	je	.L360
	movzwl	(%rdx,%rdi), %r9d
	movw	%r9w, (%r8,%rdi)
	addq	$2, %rdi
.L360:
	andl	$1, %esi
	je	.L361
	movzbl	(%rdx,%rdi), %edx
	movb	%dl, (%r8,%rdi)
.L361:
	movq	8(%rsp), %rdi
	jmp	.L362
	.p2align 4,,10
	.p2align 3
.L378:
	movq	%r13, %rdi
	jmp	.L368
.L403:
	movl	%esi, %r9d
	xorl	%edx, %edx
	andl	$-8, %r9d
.L357:
	movl	%edx, %edi
	movq	8(%rsp), %rcx
	addl	$8, %edx
	movq	(%rax,%rdi), %r8
	movq	%r8, (%rcx,%rdi)
	cmpl	%r9d, %edx
	jb	.L357
	leaq	(%rcx,%rdx), %r8
	addq	%rax, %rdx
	jmp	.L356
.L402:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14618:
	.size	_ZSt25__unguarded_linear_insertIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops14_Val_less_iterEEvT_T0_.isra.0, .-_ZSt25__unguarded_linear_insertIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops14_Val_less_iterEEvT_T0_.isra.0
	.text
	.p2align 4
	.type	_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEElS7_NS0_5__ops15_Iter_less_iterEEvT_T0_SG_T1_T2_.isra.0, @function
_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEElS7_NS0_5__ops15_Iter_less_iterEEvT_T0_SG_T1_T2_.isra.0:
.LFB14619:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdi, %r8
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	movq	%rdx, %r14
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	movq	%rcx, %r13
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$120, %rsp
	.cfi_def_cfa_offset 176
	movq	%rsi, 32(%rsp)
	movq	%fs:40, %rdx
	movq	%rdx, 104(%rsp)
	xorl	%edx, %edx
	leaq	-1(%r14), %rdx
	movq	%rdx, %r10
	shrq	$63, %r10
	addq	%rdx, %r10
	sarq	%r10
	cmpq	%r10, %rsi
	jge	.L405
	movq	%r14, 48(%rsp)
	movq	%rsi, %r12
	movq	%rdi, %r13
	movq	%rcx, 56(%rsp)
	movq	%r10, 40(%rsp)
	jmp	.L417
	.p2align 4,,10
	.p2align 3
.L409:
	cmpq	%r15, %rax
	je	.L410
	movq	%r15, (%r12)
	movq	16(%r12), %r10
	movq	%rcx, 8(%r12)
	movq	16(%rbx), %rdx
	movq	%rdx, 16(%r12)
	testq	%rdi, %rdi
	je	.L448
	movq	%rdi, (%rbx)
	movq	%r10, 16(%rbx)
.L413:
	movq	40(%rsp), %rax
	movq	$0, 8(%rbx)
	movb	$0, (%rdi)
	cmpq	%rax, %r14
	jge	.L479
	movq	%r14, %r12
.L417:
	leaq	1(%r12), %rbp
	leaq	(%rbp,%rbp), %r11
	salq	$6, %rbp
	leaq	-1(%r11), %r14
	addq	%r13, %rbp
	movq	%r14, %rbx
	movq	8(%rbp), %r10
	movq	0(%rbp), %rdi
	salq	$5, %rbx
	addq	%r13, %rbx
	movq	8(%rbx), %rcx
	movq	(%rbx), %r15
	cmpq	%rcx, %r10
	movq	%rcx, %rdx
	cmovbe	%r10, %rdx
	testq	%rdx, %rdx
	je	.L406
	movq	%r15, %rsi
	movq	%rcx, 24(%rsp)
	movq	%r10, 16(%rsp)
	movq	%r11, 8(%rsp)
	movq	%rdi, (%rsp)
	call	memcmp@PLT
	movq	(%rsp), %rdi
	movq	8(%rsp), %r11
	testl	%eax, %eax
	movq	16(%rsp), %r10
	movq	24(%rsp), %rcx
	jne	.L407
.L406:
	movq	%r10, %rax
	movl	$2147483648, %esi
	subq	%rcx, %rax
	cmpq	%rsi, %rax
	jge	.L446
	movabsq	$-2147483649, %rsi
	cmpq	%rsi, %rax
	jle	.L408
.L407:
	testl	%eax, %eax
	cmovns	%r10, %rcx
	cmovns	%rdi, %r15
	cmovns	%rbp, %rbx
	cmovns	%r11, %r14
.L408:
	salq	$5, %r12
	addq	%r13, %r12
	movq	(%r12), %rdi
	leaq	16(%r12), %rax
	cmpq	%rax, %rdi
	leaq	16(%rbx), %rax
	jne	.L409
	cmpq	%r15, %rax
	je	.L410
	movq	%r15, (%r12)
	movq	%rax, %rdi
	movq	%rcx, 8(%r12)
	movq	16(%rbx), %rdx
	movq	%rdx, 16(%r12)
.L416:
	movq	%rdi, (%rbx)
	jmp	.L413
	.p2align 4,,10
	.p2align 3
.L410:
	cmpq	%rbx, %r12
	je	.L447
	testq	%rcx, %rcx
	je	.L414
	cmpq	$1, %rcx
	je	.L480
	movq	%rcx, %rdx
	movq	%r15, %rsi
	call	memcpy@PLT
	movq	8(%rbx), %rcx
	movq	(%r12), %rdi
.L414:
	movq	%rcx, 8(%r12)
	movb	$0, (%rdi,%rcx)
	movq	(%rbx), %rdi
	jmp	.L413
	.p2align 4,,10
	.p2align 3
.L446:
	movq	%r10, %rcx
	movq	%rdi, %r15
	movq	%rbp, %rbx
	movq	%r11, %r14
	jmp	.L408
	.p2align 4,,10
	.p2align 3
.L479:
	movq	%r14, %rbp
	movq	%r13, %r8
	movq	48(%rsp), %r14
	movq	56(%rsp), %r13
.L418:
	testb	$1, %r14b
	jne	.L420
	subq	$2, %r14
	movq	%r14, %rdx
	shrq	$63, %rdx
	addq	%r14, %rdx
	sarq	%rdx
	cmpq	%rbp, %rdx
	je	.L481
.L420:
	movq	0(%r13), %rsi
	leaq	80(%rsp), %r14
	leaq	16(%r13), %rdx
	movq	8(%r13), %rcx
	movq	%r14, 64(%rsp)
	cmpq	%rdx, %rsi
	je	.L421
	movq	%rsi, 64(%rsp)
	movq	16(%r13), %rsi
	movq	%rsi, 80(%rsp)
.L422:
	movq	%rdx, 0(%r13)
	leaq	-1(%rbp), %rdx
	movq	%rdx, %r15
	movq	%rcx, 72(%rsp)
	shrq	$63, %r15
	movq	$0, 8(%r13)
	addq	%rdx, %r15
	movb	$0, 16(%r13)
	sarq	%r15
	cmpq	%rbp, 32(%rsp)
	jge	.L429
	movq	%r14, 8(%rsp)
	movq	%r8, %r13
	movq	%rcx, %r14
	jmp	.L442
	.p2align 4,,10
	.p2align 3
.L434:
	cmpq	%rdx, %rdi
	je	.L435
	movq	%rdi, 0(%rbp)
	movq	16(%rbp), %rsi
	movq	%r12, 8(%rbp)
	movq	16(%rbx), %rcx
	movq	%rcx, 16(%rbp)
	testq	%rax, %rax
	je	.L451
	movq	%rax, (%rbx)
	movq	%rsi, 16(%rbx)
.L438:
	leaq	-1(%r15), %rdx
	movq	$0, 8(%rbx)
	movb	$0, (%rax)
	movq	%rdx, %rax
	shrq	$63, %rax
	addq	%rdx, %rax
	sarq	%rax
	cmpq	%r15, 32(%rsp)
	jge	.L476
	movq	72(%rsp), %r14
	movq	%r15, %rbp
	movq	%rax, %r15
.L442:
	movq	%r15, %rbx
	movq	%r14, %rdx
	movq	64(%rsp), %rsi
	salq	$5, %rbx
	addq	%r13, %rbx
	movq	8(%rbx), %r12
	movq	(%rbx), %rdi
	cmpq	%r14, %r12
	cmovbe	%r12, %rdx
	testq	%rdx, %rdx
	je	.L430
	movq	%rdi, (%rsp)
	call	memcmp@PLT
	movq	(%rsp), %rdi
	testl	%eax, %eax
	jne	.L431
.L430:
	movq	%r12, %rax
	movl	$2147483648, %esi
	subq	%r14, %rax
	cmpq	%rsi, %rax
	jge	.L478
	movabsq	$-2147483649, %rcx
	cmpq	%rcx, %rax
	jle	.L433
.L431:
	testl	%eax, %eax
	jns	.L478
.L433:
	salq	$5, %rbp
	addq	%r13, %rbp
	movq	0(%rbp), %rax
	leaq	16(%rbp), %rdx
	cmpq	%rdx, %rax
	leaq	16(%rbx), %rdx
	jne	.L434
	cmpq	%rdi, %rdx
	je	.L435
	movq	%rdi, 0(%rbp)
	movq	%r12, 8(%rbp)
	movq	16(%rbx), %rax
	movq	%rax, 16(%rbp)
	movq	%rdx, %rax
.L441:
	movq	%rax, (%rbx)
	jmp	.L438
	.p2align 4,,10
	.p2align 3
.L435:
	cmpq	%rbp, %rbx
	je	.L450
	testq	%r12, %r12
	je	.L439
	cmpq	$1, %r12
	je	.L482
	movq	%r12, %rdx
	movq	%rdi, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	movq	8(%rbx), %r12
	movq	0(%rbp), %rax
.L439:
	movq	%r12, 8(%rbp)
	movb	$0, (%rax,%r12)
	movq	(%rbx), %rax
	jmp	.L438
	.p2align 4,,10
	.p2align 3
.L478:
	movq	%rbp, %rbx
	movq	8(%rsp), %r14
	salq	$5, %rbx
	addq	%r13, %rbx
.L429:
	movq	%rbx, %rdi
	leaq	64(%rsp), %rsi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEaSEOS4_.isra.0
	movq	64(%rsp), %rdi
	cmpq	%r14, %rdi
	je	.L404
	movq	80(%rsp), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L404:
	movq	104(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L483
	addq	$120, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L451:
	.cfi_restore_state
	movq	%rdx, %rax
	jmp	.L441
	.p2align 4,,10
	.p2align 3
.L448:
	movq	%rax, %rdi
	jmp	.L416
	.p2align 4,,10
	.p2align 3
.L482:
	movzbl	(%rdi), %edx
	movb	%dl, (%rax)
	movq	8(%rbx), %r12
	movq	0(%rbp), %rax
	movq	%r12, 8(%rbp)
	movb	$0, (%rax,%r12)
	movq	(%rbx), %rax
	jmp	.L438
	.p2align 4,,10
	.p2align 3
.L480:
	movzbl	(%r15), %eax
	movb	%al, (%rdi)
	movq	8(%rbx), %rcx
	movq	(%r12), %rdi
	movq	%rcx, 8(%r12)
	movb	$0, (%rdi,%rcx)
	movq	(%rbx), %rdi
	jmp	.L413
	.p2align 4,,10
	.p2align 3
.L476:
	movq	8(%rsp), %r14
	jmp	.L429
	.p2align 4,,10
	.p2align 3
.L481:
	leaq	1(%rbp,%rbp), %rbp
	movq	%rbx, %rdi
	movq	%r8, (%rsp)
	movq	%rbp, %r12
	salq	$5, %r12
	addq	%r8, %r12
	movq	%r12, %rsi
	movq	%r12, %rbx
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEaSEOS4_.isra.0
	movq	(%rsp), %r8
	jmp	.L420
	.p2align 4,,10
	.p2align 3
.L421:
	leaq	1(%rcx), %rdi
	movq	%r14, %r10
	movq	%rdx, %rsi
	cmpl	$8, %edi
	jnb	.L484
.L423:
	xorl	%r9d, %r9d
	testb	$4, %dil
	je	.L426
	movl	(%rsi), %r9d
	movl	%r9d, (%r10)
	movl	$4, %r9d
.L426:
	testb	$2, %dil
	je	.L427
	movzwl	(%rsi,%r9), %r11d
	movw	%r11w, (%r10,%r9)
	addq	$2, %r9
.L427:
	andl	$1, %edi
	je	.L422
	movzbl	(%rsi,%r9), %esi
	movb	%sil, (%r10,%r9)
	jmp	.L422
	.p2align 4,,10
	.p2align 3
.L450:
	movq	%rdi, %rax
	jmp	.L438
	.p2align 4,,10
	.p2align 3
.L447:
	movq	%r15, %rdi
	jmp	.L413
	.p2align 4,,10
	.p2align 3
.L405:
	movq	32(%rsp), %rbp
	movq	%rbp, %rbx
	salq	$5, %rbx
	addq	%rdi, %rbx
	jmp	.L418
.L484:
	movl	%edi, %r11d
	xorl	%esi, %esi
	andl	$-8, %r11d
.L424:
	movl	%esi, %eax
	addl	$8, %esi
	movq	(%rdx,%rax), %r9
	movq	%r9, (%r14,%rax)
	cmpl	%r11d, %esi
	jb	.L424
	leaq	(%r14,%rsi), %r10
	addq	%rdx, %rsi
	jmp	.L423
.L483:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14619:
	.size	_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEElS7_NS0_5__ops15_Iter_less_iterEEvT_T0_SG_T1_T2_.isra.0, .-_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEElS7_NS0_5__ops15_Iter_less_iterEEvT_T0_SG_T1_T2_.isra.0
	.section	.text._ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops15_Iter_less_iterEEvT_SF_T0_.isra.0,"axG",@progbits,_ZN9CatalogueC5ERKSt6vectorI5PieceSaIS1_EE,comdat
	.p2align 4
	.type	_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops15_Iter_less_iterEEvT_SF_T0_.isra.0, @function
_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops15_Iter_less_iterEEvT_SF_T0_.isra.0:
.LFB14621:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	movq	%rsi, (%rsp)
	movq	%fs:40, %rax
	movq	%rax, 56(%rsp)
	xorl	%eax, %eax
	cmpq	%rsi, %rdi
	je	.L485
	leaq	32(%rdi), %rax
	movq	%rdi, %r14
	cmpq	%rax, %rsi
	je	.L485
	movq	%rax, %r13
	leaq	16(%rdi), %rax
	leaq	32(%rsp), %rbx
	movq	%rax, 8(%rsp)
	.p2align 4,,10
	.p2align 3
.L532:
	movq	8(%r13), %r15
	movq	8(%r14), %rbp
	movq	0(%r13), %r12
	movq	(%r14), %rsi
	cmpq	%rbp, %r15
	movq	%rbp, %rdx
	cmovbe	%r15, %rdx
	testq	%rdx, %rdx
	je	.L488
	movq	%r12, %rdi
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L489
.L488:
	movq	%r15, %rax
	movl	$2147483648, %edi
	subq	%rbp, %rax
	cmpq	%rdi, %rax
	jge	.L490
	movabsq	$-2147483649, %rdi
	cmpq	%rdi, %rax
	jle	.L491
.L489:
	testl	%eax, %eax
	jns	.L490
.L491:
	leaq	16(%r13), %rax
	movq	%rbx, 16(%rsp)
	movq	%rbx, %rdi
	cmpq	%rax, %r12
	je	.L492
	movq	16(%r13), %rdx
	movq	%r12, 16(%rsp)
	movq	%rdx, 32(%rsp)
.L493:
	movq	%r13, %rcx
	movq	%rax, 0(%r13)
	leaq	32(%r13), %r12
	subq	%r14, %rcx
	movq	%r15, 24(%rsp)
	movq	$0, 8(%r13)
	movb	$0, 16(%r13)
	testq	%rcx, %rcx
	jle	.L500
	leaq	-16(%r13), %rax
	movq	%rax, %r8
	subq	%rcx, %r8
	jmp	.L515
	.p2align 4,,10
	.p2align 3
.L501:
	cmpq	%rdx, %rax
	je	.L502
	movq	%rdx, 16(%rax)
	movq	-8(%rax), %rdx
	movq	32(%rax), %rsi
	movq	%rdx, 24(%rax)
	movq	(%rax), %rdx
	movq	%rdx, 32(%rax)
	testq	%rcx, %rcx
	je	.L514
	movq	%rcx, -16(%rax)
	movq	%rcx, %rdx
	movq	%rsi, (%rax)
.L505:
	movq	$0, -8(%rax)
	subq	$32, %rax
	movb	$0, (%rdx)
	cmpq	%r8, %rax
	je	.L583
.L515:
	movq	16(%rax), %rcx
	leaq	32(%rax), %rsi
	movq	-16(%rax), %rdx
	cmpq	%rsi, %rcx
	jne	.L501
	cmpq	%rdx, %rax
	je	.L502
	movq	%rdx, 16(%rax)
	movq	-8(%rax), %rdx
	movq	%rdx, 24(%rax)
	movq	(%rax), %rdx
	movq	%rdx, 32(%rax)
.L514:
	movq	%rax, -16(%rax)
	movq	%rax, %rdx
	jmp	.L505
	.p2align 4,,10
	.p2align 3
.L502:
	movq	-8(%rax), %rdx
	testq	%rdx, %rdx
	je	.L506
	cmpq	$1, %rdx
	je	.L584
	cmpl	$8, %edx
	jnb	.L508
	testb	$4, %dl
	jne	.L585
	testl	%edx, %edx
	jne	.L586
	.p2align 4,,10
	.p2align 3
.L506:
	movq	%rdx, 24(%rax)
	movb	$0, (%rcx,%rdx)
	movq	-16(%rax), %rdx
	jmp	.L505
	.p2align 4,,10
	.p2align 3
.L490:
	movq	%r13, %rdi
	leaq	32(%r13), %r12
	call	_ZSt25__unguarded_linear_insertIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops14_Val_less_iterEEvT_T0_.isra.0
.L531:
	movq	%r12, %r13
	cmpq	%r12, (%rsp)
	jne	.L532
.L485:
	movq	56(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L587
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L583:
	.cfi_restore_state
	movq	(%r14), %rax
	movq	8(%rsp), %rdx
	movq	24(%rsp), %r15
	movq	%rax, %rcx
	movq	%rdx, %rsi
	cmpq	%rdx, %rax
	je	.L533
.L516:
	movq	16(%rsp), %rsi
	cmpq	%rbx, %rsi
	je	.L517
	movq	%r15, %xmm0
	movq	16(%r14), %r8
	movq	%rsi, (%r14)
	movhps	32(%rsp), %xmm0
	movups	%xmm0, 8(%r14)
	testq	%rax, %rax
	je	.L529
	movq	%rax, 16(%rsp)
	movq	%r8, 32(%rsp)
.L528:
	movq	$0, 24(%rsp)
	movb	$0, (%rcx)
	movq	16(%rsp), %rax
	cmpq	%rdi, %rax
	je	.L531
	movq	32(%rsp), %rdi
	leaq	1(%rdi), %rsi
	movq	%rax, %rdi
	call	_ZdlPvm@PLT
	jmp	.L531
	.p2align 4,,10
	.p2align 3
.L500:
	movq	(%r14), %rax
	leaq	16(%r14), %rsi
	movq	%rax, %rcx
	cmpq	%rsi, %rax
	jne	.L516
	.p2align 4,,10
	.p2align 3
.L533:
	movq	16(%rsp), %rcx
	cmpq	%rbx, %rcx
	je	.L588
	movq	%r15, %xmm0
	movq	%rcx, (%r14)
	movhps	32(%rsp), %xmm0
	movups	%xmm0, 8(%r14)
.L529:
	leaq	32(%rsp), %rdi
	movq	%rbx, 16(%rsp)
	movq	%rdi, %rcx
	jmp	.L528
	.p2align 4,,10
	.p2align 3
.L584:
	movzbl	(%rax), %edx
	movb	%dl, (%rcx)
	movq	-8(%rax), %rdx
	movq	16(%rax), %rcx
	movq	%rdx, 24(%rax)
	movb	$0, (%rcx,%rdx)
	movq	-16(%rax), %rdx
	jmp	.L505
	.p2align 4,,10
	.p2align 3
.L508:
	movq	(%rax), %rsi
	movq	%rax, %r11
	movq	%rsi, (%rcx)
	movl	%edx, %esi
	movq	-8(%rax,%rsi), %r9
	movq	%r9, -8(%rcx,%rsi)
	leaq	8(%rcx), %r9
	andq	$-8, %r9
	subq	%r9, %rcx
	subq	%rcx, %r11
	addl	%edx, %ecx
	andl	$-8, %ecx
	cmpl	$8, %ecx
	jb	.L581
	andl	$-8, %ecx
	xorl	%edx, %edx
.L512:
	movl	%edx, %esi
	addl	$8, %edx
	movq	(%r11,%rsi), %r10
	movq	%r10, (%r9,%rsi)
	cmpl	%ecx, %edx
	jb	.L512
.L581:
	movq	-8(%rax), %rdx
	movq	16(%rax), %rcx
	movq	%rdx, 24(%rax)
	movb	$0, (%rcx,%rdx)
	movq	-16(%rax), %rdx
	jmp	.L505
	.p2align 4,,10
	.p2align 3
.L586:
	movzbl	(%rax), %esi
	movb	%sil, (%rcx)
	testb	$2, %dl
	je	.L581
	movl	%edx, %edx
	movzwl	-2(%rax,%rdx), %esi
	movw	%si, -2(%rcx,%rdx)
	movq	16(%rax), %rcx
	movq	-8(%rax), %rdx
	jmp	.L506
.L588:
	movq	%rsi, %rcx
	.p2align 4,,10
	.p2align 3
.L517:
	testq	%r15, %r15
	je	.L520
	cmpq	$1, %r15
	je	.L589
	movl	%r15d, %esi
	cmpl	$8, %r15d
	jnb	.L522
	andl	$4, %r15d
	jne	.L590
	testl	%esi, %esi
	je	.L523
	movzbl	(%rbx), %eax
	movb	%al, (%rcx)
	testb	$2, %sil
	je	.L582
	movzwl	-2(%rbx,%rsi), %eax
	movw	%ax, -2(%rcx,%rsi)
	movq	(%r14), %rax
.L523:
	movq	24(%rsp), %r15
.L520:
	movq	%r15, 8(%r14)
	movb	$0, (%rax,%r15)
	movq	16(%rsp), %rcx
	jmp	.L528
	.p2align 4,,10
	.p2align 3
.L492:
	leaq	1(%r15), %rcx
	movq	%rbx, %r8
	movq	%rax, %rdx
	cmpl	$8, %ecx
	jnb	.L591
.L494:
	xorl	%esi, %esi
	testb	$4, %cl
	je	.L497
	movl	(%rdx), %esi
	movl	%esi, (%r8)
	movl	$4, %esi
.L497:
	testb	$2, %cl
	je	.L498
	movzwl	(%rdx,%rsi), %r9d
	movw	%r9w, (%r8,%rsi)
	addq	$2, %rsi
.L498:
	andl	$1, %ecx
	je	.L493
	movzbl	(%rdx,%rsi), %edx
	movb	%dl, (%r8,%rsi)
	jmp	.L493
.L589:
	movzbl	32(%rsp), %eax
	movb	%al, (%rcx)
	movq	24(%rsp), %r15
	movq	(%r14), %rax
	jmp	.L520
.L591:
	movl	%ecx, %r9d
	xorl	%edx, %edx
	andl	$-8, %r9d
.L495:
	movl	%edx, %esi
	addl	$8, %edx
	movq	(%rax,%rsi), %r8
	movq	%r8, (%rbx,%rsi)
	cmpl	%r9d, %edx
	jb	.L495
	leaq	(%rbx,%rdx), %r8
	addq	%rax, %rdx
	jmp	.L494
.L522:
	movq	(%rbx), %rax
	leaq	8(%rcx), %r8
	movq	%rbx, %r10
	andq	$-8, %r8
	movq	%rax, (%rcx)
	movl	%r15d, %eax
	movq	-8(%rbx,%rax), %rsi
	movq	%rsi, -8(%rcx,%rax)
	movq	%rcx, %rsi
	subq	%r8, %rsi
	subq	%rsi, %r10
	addl	%r15d, %esi
	andl	$-8, %esi
	cmpl	$8, %esi
	jb	.L582
	andl	$-8, %esi
	xorl	%eax, %eax
.L526:
	movl	%eax, %edx
	addl	$8, %eax
	movq	(%r10,%rdx), %rcx
	movq	%rcx, (%r8,%rdx)
	cmpl	%esi, %eax
	jb	.L526
.L582:
	movq	(%r14), %rax
	jmp	.L523
.L585:
	movl	(%rax), %esi
	movl	%edx, %edx
	movl	%esi, (%rcx)
	movl	-4(%rax,%rdx), %esi
	movl	%esi, -4(%rcx,%rdx)
	movq	16(%rax), %rcx
	movq	-8(%rax), %rdx
	jmp	.L506
.L590:
	movl	(%rbx), %eax
	movl	%eax, (%rcx)
	movl	-4(%rbx,%rsi), %eax
	movl	%eax, -4(%rcx,%rsi)
	movq	(%r14), %rax
	jmp	.L523
.L587:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14621:
	.size	_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops15_Iter_less_iterEEvT_SF_T0_.isra.0, .-_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops15_Iter_less_iterEEvT_SF_T0_.isra.0
	.section	.text._ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElS3_NS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_T0_SG_T1_T2_.isra.0,"axG",@progbits,_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElNS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_T1_,comdat
	.p2align 4
	.type	_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElS3_NS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_T0_SG_T1_T2_.isra.0, @function
_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElS3_NS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_T0_SG_T1_T2_.isra.0:
.LFB14623:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	movq	%rsi, %r13
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movq	%rcx, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$168, %rsp
	.cfi_def_cfa_offset 224
	movq	%rdx, 8(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 152(%rsp)
	xorl	%eax, %eax
	leaq	-1(%rdx), %rax
	movq	%rax, %r14
	shrq	$63, %r14
	addq	%rax, %r14
	sarq	%r14
	movq	%r14, (%rsp)
	cmpq	%r14, %rsi
	jge	.L593
	movq	%rsi, %rax
	jmp	.L598
	.p2align 4,,10
	.p2align 3
.L612:
	movq	%r14, %rax
.L598:
	leaq	1(%rax), %rcx
	pxor	%xmm5, %xmm5
	leaq	(%rcx,%rcx), %rsi
	salq	$8, %rcx
	leaq	-1(%rsi), %r14
	addq	%rbp, %rcx
	movq	%r14, %rbx
	salq	$7, %rbx
	addq	%rbp, %rbx
	movsd	104(%rbx), %xmm0
	comisd	104(%rcx), %xmm0
	cmovbe	%rcx, %rbx
	cmovbe	%rsi, %r14
	salq	$7, %rax
	leaq	0(%rbp,%rax), %r15
	movdqu	(%rbx), %xmm4
	movq	(%r15), %rdi
	movq	16(%r15), %rsi
	movups	%xmm4, (%r15)
	movq	16(%rbx), %rcx
	movq	%rcx, 16(%r15)
	movq	$0, 16(%rbx)
	movups	%xmm5, (%rbx)
	testq	%rdi, %rdi
	je	.L595
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L595:
	movdqu	24(%rbx), %xmm6
	movq	24(%r15), %rdi
	pxor	%xmm7, %xmm7
	movq	40(%r15), %rsi
	movups	%xmm6, 24(%r15)
	movq	40(%rbx), %rcx
	movq	%rcx, 40(%r15)
	movq	$0, 40(%rbx)
	movups	%xmm7, 24(%rbx)
	testq	%rdi, %rdi
	je	.L596
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L596:
	movdqu	48(%rbx), %xmm1
	movq	48(%r15), %rdi
	pxor	%xmm4, %xmm4
	movq	64(%r15), %rsi
	movups	%xmm1, 48(%r15)
	movq	64(%rbx), %rcx
	movq	%rcx, 64(%r15)
	movq	$0, 64(%rbx)
	movups	%xmm4, 48(%rbx)
	testq	%rdi, %rdi
	je	.L597
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L597:
	movdqu	88(%rbx), %xmm0
	movdqu	72(%rbx), %xmm5
	movdqu	112(%rbx), %xmm6
	movq	(%rsp), %rax
	movups	%xmm0, 88(%r15)
	movsd	104(%rbx), %xmm0
	movups	%xmm5, 72(%r15)
	movsd	%xmm0, 104(%r15)
	movups	%xmm6, 112(%r15)
	cmpq	%rax, %r14
	jl	.L612
.L599:
	movq	8(%rsp), %rax
	testb	$1, %al
	jne	.L600
	movq	%rax, %r15
	subq	$2, %r15
	movq	%r15, %rax
	shrq	$63, %rax
	addq	%r15, %rax
	sarq	%rax
	cmpq	%r14, %rax
	je	.L641
.L600:
	movdqu	(%r12), %xmm2
	movq	64(%r12), %rax
	pxor	%xmm0, %xmm0
	movq	$0, 64(%r12)
	movdqu	16(%r12), %xmm3
	movdqu	32(%r12), %xmm1
	movups	%xmm0, (%r12)
	movq	%rax, 80(%rsp)
	leaq	-1(%r14), %rax
	movsd	104(%r12), %xmm7
	movaps	%xmm2, 16(%rsp)
	movdqu	48(%r12), %xmm2
	movq	%rax, %r15
	movaps	%xmm3, 32(%rsp)
	shrq	$63, %r15
	movdqu	72(%r12), %xmm3
	movaps	%xmm1, 48(%rsp)
	movdqu	88(%r12), %xmm1
	addq	%rax, %r15
	movaps	%xmm2, 64(%rsp)
	movdqu	112(%r12), %xmm2
	sarq	%r15
	movups	%xmm0, 16(%r12)
	movups	%xmm0, 32(%r12)
	movups	%xmm0, 48(%r12)
	movups	%xmm3, 88(%rsp)
	movups	%xmm1, 104(%rsp)
	movsd	%xmm7, (%rsp)
	movsd	%xmm7, 120(%rsp)
	movaps	%xmm2, 128(%rsp)
	cmpq	%r13, %r14
	jg	.L606
	jmp	.L601
	.p2align 4,,10
	.p2align 3
.L643:
	movdqu	(%r12), %xmm2
	movq	(%rbx), %rdi
	pxor	%xmm3, %xmm3
	movq	16(%rbx), %rsi
	movups	%xmm2, (%rbx)
	movq	16(%r12), %rax
	movq	%rax, 16(%rbx)
	movq	$0, 16(%r12)
	movups	%xmm3, (%r12)
	testq	%rdi, %rdi
	je	.L603
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L603:
	movdqu	24(%r12), %xmm4
	movq	24(%rbx), %rdi
	pxor	%xmm5, %xmm5
	movq	40(%rbx), %rsi
	movups	%xmm4, 24(%rbx)
	movq	40(%r12), %rax
	movq	%rax, 40(%rbx)
	movq	$0, 40(%r12)
	movups	%xmm5, 24(%r12)
	testq	%rdi, %rdi
	je	.L604
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L604:
	movdqu	48(%r12), %xmm6
	movq	48(%rbx), %rdi
	pxor	%xmm7, %xmm7
	movq	64(%rbx), %rsi
	movups	%xmm6, 48(%rbx)
	movq	64(%r12), %rax
	movq	%rax, 64(%rbx)
	movq	$0, 64(%r12)
	movups	%xmm7, 48(%r12)
	testq	%rdi, %rdi
	je	.L605
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L605:
	movdqu	88(%r12), %xmm0
	leaq	-1(%r15), %rdx
	movq	%r15, %r14
	movdqu	72(%r12), %xmm2
	movq	%rdx, %rax
	movdqu	112(%r12), %xmm3
	movups	%xmm0, 88(%rbx)
	shrq	$63, %rax
	movsd	104(%r12), %xmm0
	addq	%rdx, %rax
	movups	%xmm2, 72(%rbx)
	movsd	%xmm0, 104(%rbx)
	sarq	%rax
	movups	%xmm3, 112(%rbx)
	cmpq	%r15, %r13
	jge	.L642
	movq	%rax, %r15
.L606:
	movq	%r15, %r12
	movq	%r14, %rbx
	movsd	(%rsp), %xmm1
	salq	$7, %r12
	salq	$7, %rbx
	addq	%rbp, %r12
	addq	%rbp, %rbx
	comisd	104(%r12), %xmm1
	ja	.L643
.L601:
	movq	%rbx, %rdi
	leaq	16(%rsp), %rsi
	call	_ZN10BeamPacker5StateaSEOS0_.isra.0
	movq	64(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L607
	movq	80(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L607:
	movq	40(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L608
	movq	56(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L608:
	movq	16(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L592
	movq	152(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L640
	movq	32(%rsp), %rsi
	addq	$168, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	subq	%rdi, %rsi
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L592:
	.cfi_restore_state
	movq	152(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L640
	addq	$168, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L642:
	.cfi_restore_state
	movq	%r12, %rbx
	jmp	.L601
	.p2align 4,,10
	.p2align 3
.L641:
	leaq	1(%r14,%r14), %r14
	movq	%rbx, %rdi
	movq	%r14, %rax
	salq	$7, %rax
	leaq	0(%rbp,%rax), %r15
	movq	%r15, %rsi
	movq	%r15, %rbx
	call	_ZN10BeamPacker5StateaSEOS0_.isra.0
	jmp	.L600
	.p2align 4,,10
	.p2align 3
.L593:
	movq	%rsi, %rbx
	movq	%rsi, %r14
	salq	$7, %rbx
	addq	%rdi, %rbx
	jmp	.L599
.L640:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14623:
	.size	_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElS3_NS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_T0_SG_T1_T2_.isra.0, .-_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElS3_NS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_T0_SG_T1_T2_.isra.0
	.section	.text._ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEENS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_.isra.0,"axG",@progbits,_ZN10BeamPacker3runEdx,comdat
	.p2align 4
	.type	_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEENS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_.isra.0, @function
_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEENS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_.isra.0:
.LFB14625:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$136, %rsp
	.cfi_def_cfa_offset 192
	movq	%rsi, 120(%rsp)
	cmpq	%rsi, %rdi
	je	.L644
	leaq	128(%rdi), %rbx
	movq	%rdi, %rbp
	cmpq	%rbx, %rsi
	je	.L644
	.p2align 4,,10
	.p2align 3
.L670:
	movsd	104(%rbx), %xmm6
	movsd	104(%rbp), %xmm0
	movq	%rbx, %r14
	subq	$-128, %rbx
	movdqu	-128(%rbx), %xmm1
	movdqu	-104(%rbx), %xmm2
	comisd	%xmm6, %xmm0
	movq	-88(%rbx), %rax
	movdqu	-80(%rbx), %xmm3
	movsd	%xmm6, 8(%rsp)
	movdqu	-56(%rbx), %xmm4
	movdqu	-40(%rbx), %xmm5
	movaps	%xmm1, 80(%rsp)
	movdqu	-16(%rbx), %xmm7
	movaps	%xmm2, 96(%rsp)
	movq	-64(%rbx), %r13
	movq	%rax, 112(%rsp)
	movq	-112(%rbx), %r15
	movaps	%xmm3, 32(%rsp)
	movaps	%xmm4, 48(%rsp)
	movaps	%xmm5, 64(%rsp)
	movaps	%xmm7, 16(%rsp)
	movq	$0, -64(%rbx)
	jbe	.L707
	movq	%r14, %rcx
	pxor	%xmm7, %xmm7
	subq	%rbp, %rcx
	movups	%xmm7, -128(%rbx)
	movq	%rcx, %rdx
	movups	%xmm7, -112(%rbx)
	movups	%xmm7, -96(%rbx)
	sarq	$7, %rdx
	movups	%xmm7, -80(%rbx)
	testq	%rcx, %rcx
	jle	.L649
	salq	$7, %rdx
	movq	%r14, %r12
	subq	%rdx, %r12
	.p2align 4,,10
	.p2align 3
.L653:
	movq	-112(%r14), %rdx
	movq	(%r14), %rdi
	pxor	%xmm2, %xmm2
	addq	$-128, %r14
	movdqu	(%r14), %xmm1
	movq	144(%r14), %rsi
	movups	%xmm2, (%r14)
	movq	%rdx, 144(%r14)
	movups	%xmm1, 128(%r14)
	movq	$0, 16(%r14)
	testq	%rdi, %rdi
	je	.L650
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L650:
	movdqu	24(%r14), %xmm3
	movq	40(%r14), %rdx
	pxor	%xmm4, %xmm4
	movq	$0, 40(%r14)
	movq	152(%r14), %rdi
	movq	168(%r14), %rsi
	movups	%xmm4, 24(%r14)
	movq	%rdx, 168(%r14)
	movups	%xmm3, 152(%r14)
	testq	%rdi, %rdi
	je	.L651
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L651:
	movdqu	48(%r14), %xmm5
	movq	64(%r14), %rdx
	pxor	%xmm6, %xmm6
	movq	$0, 64(%r14)
	movq	176(%r14), %rdi
	movq	192(%r14), %rsi
	movups	%xmm6, 48(%r14)
	movq	%rdx, 192(%r14)
	movups	%xmm5, 176(%r14)
	testq	%rdi, %rdi
	je	.L652
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L652:
	movdqu	72(%r14), %xmm7
	movdqu	88(%r14), %xmm1
	movsd	104(%r14), %xmm0
	movdqu	112(%r14), %xmm2
	movups	%xmm7, 200(%r14)
	movups	%xmm1, 216(%r14)
	movsd	%xmm0, 232(%r14)
	movups	%xmm2, 240(%r14)
	cmpq	%r12, %r14
	jne	.L653
.L649:
	movq	0(%rbp), %rdi
	movdqa	80(%rsp), %xmm1
	movq	16(%rbp), %rsi
	movq	%r15, 16(%rbp)
	movups	%xmm1, 0(%rbp)
	testq	%rdi, %rdi
	je	.L654
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L654:
	movq	24(%rbp), %rdi
	movdqa	96(%rsp), %xmm2
	movq	112(%rsp), %rax
	movq	40(%rbp), %rsi
	movups	%xmm2, 24(%rbp)
	movq	%rax, 40(%rbp)
	testq	%rdi, %rdi
	je	.L655
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L655:
	movq	48(%rbp), %rdi
	movdqa	32(%rsp), %xmm3
	movq	64(%rbp), %rsi
	movq	%r13, 64(%rbp)
	movups	%xmm3, 48(%rbp)
	testq	%rdi, %rdi
	je	.L656
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L656:
	movdqa	48(%rsp), %xmm4
	movdqa	64(%rsp), %xmm5
	movsd	8(%rsp), %xmm7
	movdqa	16(%rsp), %xmm0
	movups	%xmm4, 72(%rbp)
	movups	%xmm5, 88(%rbp)
	movsd	%xmm7, 104(%rbp)
	movups	%xmm0, 112(%rbp)
.L657:
	cmpq	%rbx, 120(%rsp)
	jne	.L670
.L644:
	addq	$136, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L707:
	.cfi_restore_state
	movsd	-152(%rbx), %xmm0
	comisd	8(%rsp), %xmm0
	pxor	%xmm6, %xmm6
	leaq	-256(%rbx), %r12
	movups	%xmm6, -128(%rbx)
	movups	%xmm6, -112(%rbx)
	movups	%xmm6, -96(%rbx)
	movups	%xmm6, -80(%rbx)
	jbe	.L708
	.p2align 4,,10
	.p2align 3
.L663:
	movdqu	(%r12), %xmm3
	movq	16(%r12), %rdx
	pxor	%xmm4, %xmm4
	movq	%r12, %r14
	movq	128(%r12), %rdi
	movq	144(%r12), %rsi
	movups	%xmm4, (%r12)
	movq	%rdx, 144(%r12)
	movq	$0, 16(%r12)
	movups	%xmm3, 128(%r12)
	testq	%rdi, %rdi
	je	.L660
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L660:
	movdqu	24(%r12), %xmm5
	movq	40(%r12), %rdx
	pxor	%xmm6, %xmm6
	movq	$0, 40(%r12)
	movq	152(%r12), %rdi
	movq	168(%r12), %rsi
	movups	%xmm6, 24(%r12)
	movq	%rdx, 168(%r12)
	movups	%xmm5, 152(%r12)
	testq	%rdi, %rdi
	je	.L661
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L661:
	movdqu	48(%r12), %xmm7
	movq	64(%r12), %rdx
	pxor	%xmm1, %xmm1
	movq	$0, 64(%r12)
	movq	176(%r12), %rdi
	movq	192(%r12), %rsi
	movups	%xmm1, 48(%r12)
	movq	%rdx, 192(%r12)
	movups	%xmm7, 176(%r12)
	testq	%rdi, %rdi
	je	.L662
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L662:
	movsd	104(%r12), %xmm0
	movq	(%r12), %rdi
	addq	$-128, %r12
	movdqu	200(%r12), %xmm2
	movdqu	216(%r12), %xmm3
	movdqu	240(%r12), %xmm4
	movsd	%xmm0, 360(%r12)
	movsd	-24(%r14), %xmm0
	movups	%xmm2, 328(%r12)
	movups	%xmm3, 344(%r12)
	movups	%xmm4, 368(%r12)
	comisd	8(%rsp), %xmm0
	movq	144(%r12), %rsi
	ja	.L663
	movdqa	80(%rsp), %xmm0
	movq	%r15, 16(%r14)
	movups	%xmm0, (%r14)
	testq	%rdi, %rdi
	je	.L710
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L710:
	movq	24(%r14), %rdi
	movq	40(%r14), %rsi
	movdqa	96(%rsp), %xmm1
	movq	112(%rsp), %rax
	subq	%rdi, %rsi
	movq	%rax, 40(%r14)
	movups	%xmm1, 24(%r14)
	testq	%rdi, %rdi
	je	.L667
	call	_ZdlPvm@PLT
.L667:
	movq	48(%r14), %rdi
	movdqa	32(%rsp), %xmm2
	movq	64(%r14), %rsi
	movq	%r13, 64(%r14)
	movups	%xmm2, 48(%r14)
	testq	%rdi, %rdi
	je	.L669
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L669:
	movdqa	48(%rsp), %xmm3
	movdqa	64(%rsp), %xmm4
	movsd	8(%rsp), %xmm5
	movdqa	16(%rsp), %xmm7
	movups	%xmm3, 72(%r14)
	movups	%xmm4, 88(%r14)
	movsd	%xmm5, 104(%r14)
	movups	%xmm7, 112(%r14)
	jmp	.L657
	.p2align 4,,10
	.p2align 3
.L708:
	movdqa	80(%rsp), %xmm2
	movdqa	96(%rsp), %xmm3
	movq	%r15, -112(%rbx)
	movq	112(%rsp), %rax
	movups	%xmm2, -128(%rbx)
	movq	%rax, 40(%r14)
	movups	%xmm3, 24(%r14)
	jmp	.L667
	.cfi_endproc
.LFE14625:
	.size	_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEENS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_.isra.0, .-_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEENS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_.isra.0
	.section	.text._ZZN6Packer6nestedEdxdddEN8SnapshotD2Ev,"axG",@progbits,_ZZN6Packer6nestedEdxdddEN8SnapshotD5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZZN6Packer6nestedEdxdddEN8SnapshotD2Ev
	.type	_ZZN6Packer6nestedEdxdddEN8SnapshotD2Ev, @function
_ZZN6Packer6nestedEdxdddEN8SnapshotD2Ev:
.LFB10105:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	movq	80(%rdi), %rdi
	testq	%rdi, %rdi
	je	.L712
	movq	96(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L712:
	movq	48(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L713
	movq	64(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L713:
	movq	24(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L714
	movq	40(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L714:
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L711
	movq	16(%rbx), %rsi
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	subq	%rdi, %rsi
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L711:
	.cfi_restore_state
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE10105:
	.size	_ZZN6Packer6nestedEdxdddEN8SnapshotD2Ev, .-_ZZN6Packer6nestedEdxdddEN8SnapshotD2Ev
	.weak	_ZZN6Packer6nestedEdxdddEN8SnapshotD1Ev
	.set	_ZZN6Packer6nestedEdxdddEN8SnapshotD1Ev,_ZZN6Packer6nestedEdxdddEN8SnapshotD2Ev
	.section	.text._ZN10BeamPacker5StateD2Ev,"axG",@progbits,_ZN10BeamPacker5StateD5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZN10BeamPacker5StateD2Ev
	.type	_ZN10BeamPacker5StateD2Ev, @function
_ZN10BeamPacker5StateD2Ev:
.LFB10165:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	movq	48(%rdi), %rdi
	testq	%rdi, %rdi
	je	.L727
	movq	64(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L727:
	movq	24(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L728
	movq	40(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L728:
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L726
	movq	16(%rbx), %rsi
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	subq	%rdi, %rsi
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L726:
	.cfi_restore_state
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE10165:
	.size	_ZN10BeamPacker5StateD2Ev, .-_ZN10BeamPacker5StateD2Ev
	.weak	_ZN10BeamPacker5StateD1Ev
	.set	_ZN10BeamPacker5StateD1Ev,_ZN10BeamPacker5StateD2Ev
	.section	.text._ZN10BeamPacker5StateC2EOS0_,"axG",@progbits,_ZN10BeamPacker5StateC5EOS0_,comdat
	.align 2
	.p2align 4
	.weak	_ZN10BeamPacker5StateC2EOS0_
	.type	_ZN10BeamPacker5StateC2EOS0_, @function
_ZN10BeamPacker5StateC2EOS0_:
.LFB10180:
	.cfi_startproc
	endbr64
	movq	(%rsi), %rax
	movq	$0, (%rsi)
	movdqu	72(%rsi), %xmm1
	movdqu	88(%rsi), %xmm2
	movq	%rax, (%rdi)
	movq	8(%rsi), %rax
	movq	$0, 8(%rsi)
	movsd	104(%rsi), %xmm0
	movq	%rax, 8(%rdi)
	movq	16(%rsi), %rax
	movq	$0, 16(%rsi)
	movq	%rax, 16(%rdi)
	movq	24(%rsi), %rax
	movq	$0, 24(%rsi)
	movq	%rax, 24(%rdi)
	movq	32(%rsi), %rax
	movq	$0, 32(%rsi)
	movq	%rax, 32(%rdi)
	movq	40(%rsi), %rax
	movq	$0, 40(%rsi)
	movq	%rax, 40(%rdi)
	movq	48(%rsi), %rax
	movq	$0, 48(%rsi)
	movq	%rax, 48(%rdi)
	movq	56(%rsi), %rax
	movq	$0, 56(%rsi)
	movq	%rax, 56(%rdi)
	movq	64(%rsi), %rax
	movq	$0, 64(%rsi)
	movq	%rax, 64(%rdi)
	movups	%xmm1, 72(%rdi)
	movups	%xmm2, 88(%rdi)
	movsd	%xmm0, 104(%rdi)
	movdqu	112(%rsi), %xmm3
	movups	%xmm3, 112(%rdi)
	ret
	.cfi_endproc
.LFE10180:
	.size	_ZN10BeamPacker5StateC2EOS0_, .-_ZN10BeamPacker5StateC2EOS0_
	.weak	_ZN10BeamPacker5StateC1EOS0_
	.set	_ZN10BeamPacker5StateC1EOS0_,_ZN10BeamPacker5StateC2EOS0_
	.section	.text._ZN6PackerD2Ev,"axG",@progbits,_ZN6PackerD5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZN6PackerD2Ev
	.type	_ZN6PackerD2Ev, @function
_ZN6PackerD2Ev:
.LFB10228:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	movq	224(%rdi), %rdi
	testq	%rdi, %rdi
	je	.L739
	movq	240(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L739:
	movq	152(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L740
	movq	168(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L740:
	movq	128(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L741
	movq	144(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L741:
	movq	72(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L742
	movq	88(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L742:
	movq	48(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L743
	movq	64(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L743:
	movq	24(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L738
	movq	40(%rbx), %rsi
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	subq	%rdi, %rsi
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L738:
	.cfi_restore_state
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE10228:
	.size	_ZN6PackerD2Ev, .-_ZN6PackerD2Ev
	.weak	_ZN6PackerD1Ev
	.set	_ZN6PackerD1Ev,_ZN6PackerD2Ev
	.section	.text._ZN10BeamPackerD2Ev,"axG",@progbits,_ZN10BeamPackerD5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZN10BeamPackerD2Ev
	.type	_ZN10BeamPackerD2Ev, @function
_ZN10BeamPackerD2Ev:
.LFB10231:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	movq	80(%rdi), %rdi
	testq	%rdi, %rdi
	je	.L762
	movq	96(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L762:
	movq	56(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L763
	movq	72(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L763:
	movq	32(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L761
	movq	48(%rbx), %rsi
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	subq	%rdi, %rsi
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L761:
	.cfi_restore_state
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE10231:
	.size	_ZN10BeamPackerD2Ev, .-_ZN10BeamPackerD2Ev
	.weak	_ZN10BeamPackerD1Ev
	.set	_ZN10BeamPackerD1Ev,_ZN10BeamPackerD2Ev
	.section	.text._ZN9CatalogueD2Ev,"axG",@progbits,_ZN9CatalogueD5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZN9CatalogueD2Ev
	.type	_ZN9CatalogueD2Ev, @function
_ZN9CatalogueD2Ev:
.LFB10239:
	.cfi_startproc
	endbr64
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	48(%rdi), %rdi
	testq	%rdi, %rdi
	je	.L773
	movq	64(%rbp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L773:
	movq	32(%rbp), %r12
	movq	24(%rbp), %rbx
	cmpq	%rbx, %r12
	je	.L774
	.p2align 4,,10
	.p2align 3
.L777:
	movq	112(%rbx), %rdi
	leaq	128(%rbx), %rax
	cmpq	%rax, %rdi
	je	.L775
	movq	128(%rbx), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L775:
	movq	88(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L776
	movq	104(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L776:
	addq	$144, %rbx
	cmpq	%rbx, %r12
	jne	.L777
	movq	24(%rbp), %rbx
.L774:
	testq	%rbx, %rbx
	je	.L778
	movq	40(%rbp), %rsi
	movq	%rbx, %rdi
	subq	%rbx, %rsi
	call	_ZdlPvm@PLT
.L778:
	movq	8(%rbp), %r12
	movq	0(%rbp), %rbx
	cmpq	%rbx, %r12
	je	.L779
	.p2align 4,,10
	.p2align 3
.L782:
	movq	24(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L780
	movq	40(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L780:
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L781
	movq	16(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L781:
	addq	$48, %rbx
	cmpq	%rbx, %r12
	jne	.L782
	movq	0(%rbp), %rbx
.L779:
	testq	%rbx, %rbx
	je	.L772
	movq	16(%rbp), %rsi
	movq	%rbx, %rdi
	subq	%rbx, %rsi
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L772:
	.cfi_restore_state
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE10239:
	.size	_ZN9CatalogueD2Ev, .-_ZN9CatalogueD2Ev
	.weak	_ZN9CatalogueD1Ev
	.set	_ZN9CatalogueD1Ev,_ZN9CatalogueD2Ev
	.section	.text._ZNSt6vectorImSaImEED2Ev,"axG",@progbits,_ZNSt6vectorImSaImEED5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorImSaImEED2Ev
	.type	_ZNSt6vectorImSaImEED2Ev, @function
_ZNSt6vectorImSaImEED2Ev:
.LFB10881:
	.cfi_startproc
	endbr64
	movq	(%rdi), %rax
	testq	%rax, %rax
	je	.L802
	movq	16(%rdi), %rsi
	movq	%rax, %rdi
	subq	%rax, %rsi
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L802:
	ret
	.cfi_endproc
.LFE10881:
	.size	_ZNSt6vectorImSaImEED2Ev, .-_ZNSt6vectorImSaImEED2Ev
	.weak	_ZNSt6vectorImSaImEED1Ev
	.set	_ZNSt6vectorImSaImEED1Ev,_ZNSt6vectorImSaImEED2Ev
	.section	.text._ZNK10BeamPacker8evaluateERNS_5StateE,"axG",@progbits,_ZNK10BeamPacker8evaluateERNS_5StateE,comdat
	.align 2
	.p2align 4
	.weak	_ZNK10BeamPacker8evaluateERNS_5StateE
	.type	_ZNK10BeamPacker8evaluateERNS_5StateE, @function
_ZNK10BeamPacker8evaluateERNS_5StateE:
.LFB10135:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA10135
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$104, %rsp
	.cfi_def_cfa_offset 160
	movl	80(%rsi), %r13d
	movq	%rdi, 24(%rsp)
	movq	%rsi, 16(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 88(%rsp)
	xorl	%eax, %eax
	movl	84(%rsi), %eax
	movl	%eax, %ebp
	movl	%eax, 8(%rsp)
	subl	%r13d, %ebp
	addl	$1, %ebp
	cmpl	$1, %ebp
	jg	.L805
	movl	$8, %edi
	movl	$1, %ebp
	movl	$1, %r15d
.LEHB0:
	call	_Znwm@PLT
.LEHE0:
	movq	$8, 8(%rsp)
	leaq	8(%rax), %r14
	movq	%rax, 64(%rsp)
	movq	%rax, %rbx
	movq	%r14, 80(%rsp)
	movq	$0, (%rax)
	movq	%r14, 72(%rsp)
.L806:
	movq	8(%rsp), %rdi
.LEHB1:
	call	_Znwm@PLT
.LEHE1:
	movq	$0, (%rax)
	movq	%rax, %r12
	leaq	8(%rax), %rdi
	cmpq	$1, %r15
	je	.L809
	movq	8(%rsp), %rax
	leaq	(%r12,%rax), %r15
	cmpq	%rdi, %r15
	je	.L810
	leaq	-8(%rax), %rdx
	xorl	%esi, %esi
	call	memset@PLT
.L810:
	movq	%r15, %rdi
.L809:
	movq	24(%rsp), %rax
	movslq	%r13d, %r8
	movslq	%ebp, %r9
	xorl	%edx, %edx
	movq	104(%rax), %rsi
	movq	16(%rsp), %rax
	movq	(%rax), %r11
	movq	8(%rax), %rax
	movq	%rax, 32(%rsp)
	subq	%r11, %rax
	leaq	(%r11,%r8,8), %r15
	movl	%ebp, 32(%rsp)
	sarq	$3, %rax
	movl	%eax, %r10d
	.p2align 4,,10
	.p2align 3
.L812:
	leal	0(%r13,%rdx), %ebp
	movq	%rsi, %rcx
	cmpl	%ebp, %r10d
	jle	.L811
	movq	(%r15,%rdx,8), %rcx
	notq	%rcx
	andq	%rsi, %rcx
.L811:
	movq	%rcx, (%rbx,%rdx,8)
	addq	$1, %rdx
	cmpq	%rdx, %r9
	jne	.L812
	movl	32(%rsp), %ebp
	movq	-8(%r14), %rcx
	movq	%rcx, -8(%rdi)
	leal	-1(%rbp), %edi
	movslq	%edi, %rdi
	.p2align 4,,10
	.p2align 3
.L817:
	movq	%rdi, %rsi
	xorl	%r10d, %r10d
	.p2align 4,,10
	.p2align 3
.L816:
	movq	(%r12,%rsi,8), %r9
	movq	%r9, %r14
	leaq	(%r9,%r9), %rcx
	shrq	%r14
	orq	%r14, %rcx
	orq	%r9, %rcx
	testl	%esi, %esi
	je	.L813
	orq	-8(%r12,%rsi,8), %rcx
.L813:
	leal	1(%rsi), %r14d
	cmpl	%ebp, %r14d
	jge	.L814
	orq	8(%r12,%rsi,8), %rcx
.L814:
	andq	(%rbx,%rsi,8), %rcx
	cmpq	%rcx, %r9
	je	.L815
	movq	%rcx, (%r12,%rsi,8)
	movl	$1, %r10d
.L815:
	subq	$1, %rsi
	cmpl	$-1, %esi
	jne	.L816
	testb	%r10b, %r10b
	jne	.L817
	movq	%r11, 40(%rsp)
	xorl	%r14d, %r14d
	salq	$3, %rdx
	xorl	%ebp, %ebp
	movq	%r8, 48(%rsp)
	movq	%rax, 56(%rsp)
	movl	%r13d, 32(%rsp)
	movq	%r12, %r13
	movq	%r14, %r12
	movq	%rdx, %r14
	.p2align 4,,10
	.p2align 3
.L818:
	movq	0(%r13,%r12), %rdi
	notq	%rdi
	andq	(%rbx,%r12), %rdi
	addq	$8, %r12
	call	__popcountdi2@PLT
	addl	%eax, %ebp
	cmpq	%r12, %r14
	jne	.L818
	movq	24(%rsp), %rdi
	pxor	%xmm0, %xmm0
	pxor	%xmm1, %xmm1
	movq	%r13, %r12
	movq	16(%rsp), %rdx
	cvtsi2sdl	%ebp, %xmm0
	movl	32(%rsp), %r13d
	movabsq	$1488147231821619283, %rcx
	mulsd	120(%rdi), %xmm0
	movq	56(%rsp), %rax
	cvtsi2sdl	88(%rdx), %xmm1
	movq	40(%rsp), %r11
	movq	48(%rsp), %r8
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	96(%rdx), %xmm1
	mulsd	128(%rdi), %xmm1
	movq	%rdx, %rdi
	movq	120(%rdi), %rsi
	subsd	%xmm1, %xmm0
	movsd	%xmm0, 104(%rdx)
	movslq	80(%rdx), %rdx
	xorq	%rcx, %rdx
	movabsq	$1099511628211, %rcx
	imulq	%rcx, %rdx
	cmpl	%r13d, %eax
	jle	.L837
	subl	%r13d, %eax
	subl	$1, %eax
	addq	%r8, %rax
	leaq	8(%r11,%rax,8), %rax
	.p2align 4,,10
	.p2align 3
.L820:
	xorq	(%r15), %rdx
	addq	$8, %r15
	imulq	%rcx, %rdx
	cmpq	%rax, %r15
	jne	.L820
.L837:
	movq	16(%rsp), %rax
	xorq	%rsi, %rdx
	movq	8(%rsp), %rsi
	movq	%r12, %rdi
	movq	%rdx, 112(%rax)
	call	_ZdlPvm@PLT
	movq	88(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L839
	movq	8(%rsp), %rsi
	addq	$104, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%rbx, %rdi
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	_ZdlPvm@PLT
.L805:
	.cfi_restore_state
	movslq	%ebp, %r15
	leaq	0(,%r15,8), %r14
	movq	%r14, %rdi
	movq	%r14, 8(%rsp)
.LEHB2:
	call	_Znwm@PLT
	addq	%rax, %r14
	leaq	8(%rax), %rdi
	movq	%rax, 64(%rsp)
	movq	%rax, %rbx
	movq	%r14, 80(%rsp)
	movq	$0, (%rax)
	cmpq	%r14, %rdi
	je	.L808
	movq	8(%rsp), %rax
	xorl	%esi, %esi
	leaq	-8(%rax), %rdx
	call	memset@PLT
.L808:
	movq	%r14, 72(%rsp)
	jmp	.L806
.L824:
	leaq	64(%rsp), %rdi
	call	_ZNSt6vectorImSaImEED1Ev
	movq	88(%rsp), %rax
	subq	%fs:40, %rax
	je	.L825
.L839:
	call	__stack_chk_fail@PLT
.L828:
	endbr64
	movq	%rax, %rbx
	jmp	.L824
.L825:
	movq	%rbx, %rdi
	call	_Unwind_Resume@PLT
.LEHE2:
	.cfi_endproc
.LFE10135:
	.globl	__gxx_personality_v0
	.section	.gcc_except_table._ZNK10BeamPacker8evaluateERNS_5StateE,"aG",@progbits,_ZNK10BeamPacker8evaluateERNS_5StateE,comdat
.LLSDA10135:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE10135-.LLSDACSB10135
.LLSDACSB10135:
	.uleb128 .LEHB0-.LFB10135
	.uleb128 .LEHE0-.LEHB0
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB1-.LFB10135
	.uleb128 .LEHE1-.LEHB1
	.uleb128 .L828-.LFB10135
	.uleb128 0
	.uleb128 .LEHB2-.LFB10135
	.uleb128 .LEHE2-.LEHB2
	.uleb128 0
	.uleb128 0
.LLSDACSE10135:
	.section	.text._ZNK10BeamPacker8evaluateERNS_5StateE,"axG",@progbits,_ZNK10BeamPacker8evaluateERNS_5StateE,comdat
	.size	_ZNK10BeamPacker8evaluateERNS_5StateE, .-_ZNK10BeamPacker8evaluateERNS_5StateE
	.section	.text._ZN10BeamPacker5StateC2ERKS0_,"axG",@progbits,_ZN10BeamPacker5StateC5ERKS0_,comdat
	.align 2
	.p2align 4
	.weak	_ZN10BeamPacker5StateC2ERKS0_
	.type	_ZN10BeamPacker5StateC2ERKS0_, @function
_ZN10BeamPacker5StateC2ERKS0_:
.LFB10193:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA10193
	endbr64
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pxor	%xmm0, %xmm0
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	8(%rsi), %r12
	movq	%rdi, %rbx
	subq	(%rsi), %r12
	movq	$0, 16(%rdi)
	movups	%xmm0, (%rdi)
	je	.L858
	movabsq	$9223372036854775800, %rax
	cmpq	%r12, %rax
	jb	.L865
	movq	%r12, %rdi
.LEHB3:
	call	_Znwm@PLT
.LEHE3:
	movq	%rax, %rcx
.L841:
	movq	%rcx, %xmm0
	addq	%rcx, %r12
	punpcklqdq	%xmm0, %xmm0
	movq	%r12, 16(%rbx)
	movups	%xmm0, (%rbx)
	movq	0(%rbp), %rsi
	movq	8(%rbp), %rax
	subq	%rsi, %rax
	cmpq	$8, %rax
	jle	.L843
	movq	%rcx, %rdi
	movq	%rax, %rdx
	movq	%rax, %r12
	call	memmove@PLT
	movq	%rax, %rcx
.L844:
	addq	%r12, %rcx
	pxor	%xmm0, %xmm0
	movq	%rcx, 8(%rbx)
	movq	32(%rbp), %r12
	subq	24(%rbp), %r12
	movq	$0, 40(%rbx)
	movups	%xmm0, 24(%rbx)
	je	.L859
	movabsq	$9223372036854775800, %rax
	cmpq	%r12, %rax
	jb	.L866
	movq	%r12, %rdi
.LEHB4:
	call	_Znwm@PLT
.LEHE4:
	movq	%rax, %rcx
.L846:
	movq	%rcx, %xmm0
	addq	%rcx, %r12
	punpcklqdq	%xmm0, %xmm0
	movq	%r12, 40(%rbx)
	movups	%xmm0, 24(%rbx)
	movq	24(%rbp), %rsi
	movq	32(%rbp), %rax
	subq	%rsi, %rax
	cmpq	$8, %rax
	jle	.L848
	movq	%rcx, %rdi
	movq	%rax, %rdx
	movq	%rax, %r12
	call	memmove@PLT
	movq	%rax, %rcx
.L849:
	addq	%r12, %rcx
	pxor	%xmm0, %xmm0
	movq	56(%rbp), %r12
	subq	48(%rbp), %r12
	movq	%rcx, 32(%rbx)
	movq	$0, 64(%rbx)
	movups	%xmm0, 48(%rbx)
	je	.L860
	movabsq	$9223372036854775806, %rax
	cmpq	%r12, %rax
	jb	.L867
	movq	%r12, %rdi
.LEHB5:
	call	_Znwm@PLT
.LEHE5:
	movq	%rax, %rcx
.L851:
	movq	%rcx, %xmm0
	addq	%rcx, %r12
	punpcklqdq	%xmm0, %xmm0
	movq	%r12, 64(%rbx)
	movups	%xmm0, 48(%rbx)
	movq	48(%rbp), %rsi
	movq	56(%rbp), %rax
	subq	%rsi, %rax
	cmpq	$2, %rax
	jle	.L853
	movq	%rcx, %rdi
	movq	%rax, %rdx
	movq	%rax, %r12
	call	memmove@PLT
	movq	%rax, %rcx
.L854:
	movdqu	72(%rbp), %xmm1
	movdqu	88(%rbp), %xmm2
	addq	%r12, %rcx
	movsd	104(%rbp), %xmm0
	movdqu	112(%rbp), %xmm3
	movq	%rcx, 56(%rbx)
	movups	%xmm1, 72(%rbx)
	movups	%xmm2, 88(%rbx)
	movsd	%xmm0, 104(%rbx)
	movups	%xmm3, 112(%rbx)
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L858:
	.cfi_restore_state
	xorl	%r12d, %r12d
	xorl	%ecx, %ecx
	jmp	.L841
	.p2align 4,,10
	.p2align 3
.L859:
	xorl	%r12d, %r12d
	xorl	%ecx, %ecx
	jmp	.L846
	.p2align 4,,10
	.p2align 3
.L860:
	xorl	%ecx, %ecx
	jmp	.L851
	.p2align 4,,10
	.p2align 3
.L843:
	movq	%rax, %r12
	jne	.L844
	movq	(%rsi), %rax
	movl	$8, %r12d
	movq	%rax, (%rcx)
	jmp	.L844
	.p2align 4,,10
	.p2align 3
.L848:
	movq	%rax, %r12
	jne	.L849
	movq	(%rsi), %rax
	movl	$8, %r12d
	movq	%rax, (%rcx)
	jmp	.L849
	.p2align 4,,10
	.p2align 3
.L853:
	movq	%rax, %r12
	jne	.L854
	movzwl	(%rsi), %eax
	movl	$2, %r12d
	movw	%ax, (%rcx)
	jmp	.L854
	.p2align 4,,10
	.p2align 3
.L865:
.LEHB6:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE6:
	.p2align 4,,10
	.p2align 3
.L866:
.LEHB7:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE7:
	.p2align 4,,10
	.p2align 3
.L867:
.LEHB8:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE8:
.L862:
	endbr64
	movq	%rax, %rbp
	jmp	.L856
.L861:
	endbr64
	movq	%rax, %rbp
	jmp	.L857
.L856:
	leaq	24(%rbx), %rdi
	call	_ZNSt6vectorImSaImEED1Ev
.L857:
	movq	%rbx, %rdi
	call	_ZNSt6vectorImSaImEED1Ev
	movq	%rbp, %rdi
.LEHB9:
	call	_Unwind_Resume@PLT
.LEHE9:
	.cfi_endproc
.LFE10193:
	.section	.gcc_except_table._ZN10BeamPacker5StateC2ERKS0_,"aG",@progbits,_ZN10BeamPacker5StateC5ERKS0_,comdat
.LLSDA10193:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE10193-.LLSDACSB10193
.LLSDACSB10193:
	.uleb128 .LEHB3-.LFB10193
	.uleb128 .LEHE3-.LEHB3
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB4-.LFB10193
	.uleb128 .LEHE4-.LEHB4
	.uleb128 .L861-.LFB10193
	.uleb128 0
	.uleb128 .LEHB5-.LFB10193
	.uleb128 .LEHE5-.LEHB5
	.uleb128 .L862-.LFB10193
	.uleb128 0
	.uleb128 .LEHB6-.LFB10193
	.uleb128 .LEHE6-.LEHB6
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB7-.LFB10193
	.uleb128 .LEHE7-.LEHB7
	.uleb128 .L861-.LFB10193
	.uleb128 0
	.uleb128 .LEHB8-.LFB10193
	.uleb128 .LEHE8-.LEHB8
	.uleb128 .L862-.LFB10193
	.uleb128 0
	.uleb128 .LEHB9-.LFB10193
	.uleb128 .LEHE9-.LEHB9
	.uleb128 0
	.uleb128 0
.LLSDACSE10193:
	.section	.text._ZN10BeamPacker5StateC2ERKS0_,"axG",@progbits,_ZN10BeamPacker5StateC5ERKS0_,comdat
	.size	_ZN10BeamPacker5StateC2ERKS0_, .-_ZN10BeamPacker5StateC2ERKS0_
	.weak	_ZN10BeamPacker5StateC1ERKS0_
	.set	_ZN10BeamPacker5StateC1ERKS0_,_ZN10BeamPacker5StateC2ERKS0_
	.section	.text._ZNSt6vectorI4TypeSaIS0_EED2Ev,"axG",@progbits,_ZNSt6vectorI4TypeSaIS0_EED5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorI4TypeSaIS0_EED2Ev
	.type	_ZNSt6vectorI4TypeSaIS0_EED2Ev, @function
_ZNSt6vectorI4TypeSaIS0_EED2Ev:
.LFB11001:
	.cfi_startproc
	endbr64
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	8(%rdi), %rbp
	movq	(%rdi), %rbx
	cmpq	%rbx, %rbp
	je	.L869
	.p2align 4,,10
	.p2align 3
.L872:
	movq	24(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L870
	movq	40(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L870:
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L871
	movq	16(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L871:
	addq	$48, %rbx
	cmpq	%rbx, %rbp
	jne	.L872
	movq	(%r12), %rbx
.L869:
	testq	%rbx, %rbx
	je	.L868
	movq	16(%r12), %rsi
	movq	%rbx, %rdi
	subq	%rbx, %rsi
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L868:
	.cfi_restore_state
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE11001:
	.size	_ZNSt6vectorI4TypeSaIS0_EED2Ev, .-_ZNSt6vectorI4TypeSaIS0_EED2Ev
	.weak	_ZNSt6vectorI4TypeSaIS0_EED1Ev
	.set	_ZNSt6vectorI4TypeSaIS0_EED1Ev,_ZNSt6vectorI4TypeSaIS0_EED2Ev
	.section	.text._ZNSt6vectorI7VariantSaIS0_EED2Ev,"axG",@progbits,_ZNSt6vectorI7VariantSaIS0_EED5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorI7VariantSaIS0_EED2Ev
	.type	_ZNSt6vectorI7VariantSaIS0_EED2Ev, @function
_ZNSt6vectorI7VariantSaIS0_EED2Ev:
.LFB11013:
	.cfi_startproc
	endbr64
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	8(%rdi), %rbp
	movq	(%rdi), %rbx
	cmpq	%rbx, %rbp
	je	.L883
	.p2align 4,,10
	.p2align 3
.L886:
	movq	112(%rbx), %rdi
	leaq	128(%rbx), %rax
	cmpq	%rax, %rdi
	je	.L884
	movq	128(%rbx), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L884:
	movq	88(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L885
	movq	104(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L885:
	addq	$144, %rbx
	cmpq	%rbx, %rbp
	jne	.L886
	movq	(%r12), %rbx
.L883:
	testq	%rbx, %rbx
	je	.L882
	movq	16(%r12), %rsi
	movq	%rbx, %rdi
	subq	%rbx, %rsi
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L882:
	.cfi_restore_state
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE11013:
	.size	_ZNSt6vectorI7VariantSaIS0_EED2Ev, .-_ZNSt6vectorI7VariantSaIS0_EED2Ev
	.weak	_ZNSt6vectorI7VariantSaIS0_EED1Ev
	.set	_ZNSt6vectorI7VariantSaIS0_EED1Ev,_ZNSt6vectorI7VariantSaIS0_EED2Ev
	.section	.text._ZNSt6vectorIiSaIiEED2Ev,"axG",@progbits,_ZNSt6vectorIiSaIiEED5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorIiSaIiEED2Ev
	.type	_ZNSt6vectorIiSaIiEED2Ev, @function
_ZNSt6vectorIiSaIiEED2Ev:
.LFB11064:
	.cfi_startproc
	endbr64
	movq	(%rdi), %rax
	testq	%rax, %rax
	je	.L893
	movq	16(%rdi), %rsi
	movq	%rax, %rdi
	subq	%rax, %rsi
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L893:
	ret
	.cfi_endproc
.LFE11064:
	.size	_ZNSt6vectorIiSaIiEED2Ev, .-_ZNSt6vectorIiSaIiEED2Ev
	.weak	_ZNSt6vectorIiSaIiEED1Ev
	.set	_ZNSt6vectorIiSaIiEED1Ev,_ZNSt6vectorIiSaIiEED2Ev
	.section	.text._ZNSt6vectorISt4pairIiiESaIS1_EED2Ev,"axG",@progbits,_ZNSt6vectorISt4pairIiiESaIS1_EED5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorISt4pairIiiESaIS1_EED2Ev
	.type	_ZNSt6vectorISt4pairIiiESaIS1_EED2Ev, @function
_ZNSt6vectorISt4pairIiiESaIS1_EED2Ev:
.LFB11100:
	.cfi_startproc
	endbr64
	movq	(%rdi), %rax
	testq	%rax, %rax
	je	.L895
	movq	16(%rdi), %rsi
	movq	%rax, %rdi
	subq	%rax, %rsi
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L895:
	ret
	.cfi_endproc
.LFE11100:
	.size	_ZNSt6vectorISt4pairIiiESaIS1_EED2Ev, .-_ZNSt6vectorISt4pairIiiESaIS1_EED2Ev
	.weak	_ZNSt6vectorISt4pairIiiESaIS1_EED1Ev
	.set	_ZNSt6vectorISt4pairIiiESaIS1_EED1Ev,_ZNSt6vectorISt4pairIiiESaIS1_EED2Ev
	.section	.text._ZNSt6vectorISt4pairIdiESaIS1_EED2Ev,"axG",@progbits,_ZNSt6vectorISt4pairIdiESaIS1_EED5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorISt4pairIdiESaIS1_EED2Ev
	.type	_ZNSt6vectorISt4pairIdiESaIS1_EED2Ev, @function
_ZNSt6vectorISt4pairIdiESaIS1_EED2Ev:
.LFB11167:
	.cfi_startproc
	endbr64
	movq	(%rdi), %rax
	testq	%rax, %rax
	je	.L897
	movq	16(%rdi), %rsi
	movq	%rax, %rdi
	subq	%rax, %rsi
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L897:
	ret
	.cfi_endproc
.LFE11167:
	.size	_ZNSt6vectorISt4pairIdiESaIS1_EED2Ev, .-_ZNSt6vectorISt4pairIdiESaIS1_EED2Ev
	.weak	_ZNSt6vectorISt4pairIdiESaIS1_EED1Ev
	.set	_ZNSt6vectorISt4pairIdiESaIS1_EED1Ev,_ZNSt6vectorISt4pairIdiESaIS1_EED2Ev
	.section	.text._ZNSt6vectorIySaIyEED2Ev,"axG",@progbits,_ZNSt6vectorIySaIyEED5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorIySaIyEED2Ev
	.type	_ZNSt6vectorIySaIyEED2Ev, @function
_ZNSt6vectorIySaIyEED2Ev:
.LFB11209:
	.cfi_startproc
	endbr64
	movq	(%rdi), %rax
	testq	%rax, %rax
	je	.L899
	movq	16(%rdi), %rsi
	movq	%rax, %rdi
	subq	%rax, %rsi
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L899:
	ret
	.cfi_endproc
.LFE11209:
	.size	_ZNSt6vectorIySaIyEED2Ev, .-_ZNSt6vectorIySaIyEED2Ev
	.weak	_ZNSt6vectorIySaIyEED1Ev
	.set	_ZNSt6vectorIySaIyEED1Ev,_ZNSt6vectorIySaIyEED2Ev
	.section	.text._ZZN6Packer6nestedEdxdddENKUlvE_clEv,"axG",@progbits,_ZZN6Packer6nestedEdxdddENKUlvE_clEv,comdat
	.align 2
	.p2align 4
	.weak	_ZZN6Packer6nestedEdxdddENKUlvE_clEv
	.type	_ZZN6Packer6nestedEdxdddENKUlvE_clEv, @function
_ZZN6Packer6nestedEdxdddENKUlvE_clEv:
.LFB10100:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA10100
	endbr64
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pxor	%xmm0, %xmm0
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	movq	%rsi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	movq	%rdi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	(%rsi), %r13
	movq	32(%r13), %rbp
	subq	24(%r13), %rbp
	movq	$0, 16(%rdi)
	movups	%xmm0, (%rdi)
	je	.L925
	movabsq	$9223372036854775804, %rax
	cmpq	%rbp, %rax
	jb	.L934
	movq	%rbp, %rdi
.LEHB10:
	call	_Znwm@PLT
.LEHE10:
	movq	%rax, %rcx
.L902:
	movq	%rcx, %xmm0
	addq	%rcx, %rbp
	punpcklqdq	%xmm0, %xmm0
	movq	%rbp, 16(%rbx)
	movups	%xmm0, (%rbx)
	movq	24(%r13), %rsi
	movq	32(%r13), %rax
	subq	%rsi, %rax
	cmpq	$4, %rax
	jle	.L904
	movq	%rcx, %rdi
	movq	%rax, %rdx
	movq	%rax, %rbp
	call	memmove@PLT
	movq	%rax, %rcx
.L905:
	movq	(%r12), %r13
	addq	%rbp, %rcx
	pxor	%xmm0, %xmm0
	movq	%rcx, 8(%rbx)
	movq	56(%r13), %rbp
	subq	48(%r13), %rbp
	movq	$0, 40(%rbx)
	movups	%xmm0, 24(%rbx)
	je	.L926
	movabsq	$9223372036854775804, %rax
	cmpq	%rbp, %rax
	jb	.L935
	movq	%rbp, %rdi
.LEHB11:
	call	_Znwm@PLT
.LEHE11:
	movq	%rax, %rcx
.L907:
	movq	%rcx, %xmm0
	addq	%rcx, %rbp
	punpcklqdq	%xmm0, %xmm0
	movq	%rbp, 40(%rbx)
	movups	%xmm0, 24(%rbx)
	movq	48(%r13), %rsi
	movq	56(%r13), %rax
	subq	%rsi, %rax
	cmpq	$4, %rax
	jle	.L909
	movq	%rcx, %rdi
	movq	%rax, %rdx
	movq	%rax, %rbp
	call	memmove@PLT
	movq	%rax, %rcx
.L910:
	movq	(%r12), %r13
	addq	%rbp, %rcx
	pxor	%xmm0, %xmm0
	movq	%rcx, 32(%rbx)
	movq	136(%r13), %rbp
	subq	128(%r13), %rbp
	movq	$0, 64(%rbx)
	movups	%xmm0, 48(%rbx)
	je	.L927
	movabsq	$9223372036854775800, %rax
	cmpq	%rbp, %rax
	jb	.L936
	movq	%rbp, %rdi
.LEHB12:
	call	_Znwm@PLT
.LEHE12:
	movq	%rax, %rcx
.L912:
	movq	%rcx, %xmm0
	addq	%rcx, %rbp
	punpcklqdq	%xmm0, %xmm0
	movq	%rbp, 64(%rbx)
	movups	%xmm0, 48(%rbx)
	movq	128(%r13), %rsi
	movq	136(%r13), %rax
	subq	%rsi, %rax
	cmpq	$8, %rax
	jle	.L914
	movq	%rcx, %rdi
	movq	%rax, %rdx
	movq	%rax, %rbp
	call	memmove@PLT
	movq	%rax, %rcx
.L915:
	movq	(%r12), %r13
	addq	%rbp, %rcx
	pxor	%xmm0, %xmm0
	movq	%rcx, 56(%rbx)
	movq	216(%r13), %rax
	movq	232(%r13), %rbp
	subq	224(%r13), %rbp
	movq	$0, 96(%rbx)
	movq	%rax, 72(%rbx)
	movups	%xmm0, 80(%rbx)
	je	.L928
	movabsq	$9223372036854775800, %rax
	cmpq	%rbp, %rax
	jb	.L937
	movq	%rbp, %rdi
.LEHB13:
	call	_Znwm@PLT
.LEHE13:
	movq	%rax, %rcx
.L917:
	movq	%rcx, %xmm0
	addq	%rcx, %rbp
	punpcklqdq	%xmm0, %xmm0
	movq	%rbp, 96(%rbx)
	movups	%xmm0, 80(%rbx)
	movq	224(%r13), %rsi
	movq	232(%r13), %rax
	subq	%rsi, %rax
	cmpq	$24, %rax
	jle	.L919
	movq	%rcx, %rdi
	movq	%rax, %rdx
	movq	%rax, %rbp
	call	memmove@PLT
	movq	%rax, %rcx
.L920:
	movq	(%r12), %rax
	addq	%rbp, %rcx
	movq	%rcx, 88(%rbx)
	movq	116(%rax), %rdx
	movq	%rdx, 104(%rbx)
	movl	112(%rax), %eax
	movl	%eax, 112(%rbx)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L925:
	.cfi_restore_state
	xorl	%ecx, %ecx
	jmp	.L902
	.p2align 4,,10
	.p2align 3
.L926:
	xorl	%ebp, %ebp
	xorl	%ecx, %ecx
	jmp	.L907
	.p2align 4,,10
	.p2align 3
.L927:
	xorl	%ecx, %ecx
	jmp	.L912
	.p2align 4,,10
	.p2align 3
.L928:
	xorl	%ecx, %ecx
	jmp	.L917
	.p2align 4,,10
	.p2align 3
.L904:
	movq	%rax, %rbp
	jne	.L905
	movl	(%rsi), %eax
	movl	$4, %ebp
	movl	%eax, (%rcx)
	jmp	.L905
	.p2align 4,,10
	.p2align 3
.L909:
	movq	%rax, %rbp
	jne	.L910
	movl	(%rsi), %eax
	movl	$4, %ebp
	movl	%eax, (%rcx)
	jmp	.L910
	.p2align 4,,10
	.p2align 3
.L914:
	movq	%rax, %rbp
	jne	.L915
	movq	(%rsi), %rax
	movl	$8, %ebp
	movq	%rax, (%rcx)
	jmp	.L915
	.p2align 4,,10
	.p2align 3
.L919:
	movq	%rax, %rbp
	jne	.L920
	movdqu	(%rsi), %xmm1
	movl	$24, %ebp
	movups	%xmm1, (%rcx)
	movq	16(%rsi), %rax
	movq	%rax, 16(%rcx)
	jmp	.L920
	.p2align 4,,10
	.p2align 3
.L934:
.LEHB14:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE14:
	.p2align 4,,10
	.p2align 3
.L935:
.LEHB15:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE15:
	.p2align 4,,10
	.p2align 3
.L936:
.LEHB16:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE16:
	.p2align 4,,10
	.p2align 3
.L937:
.LEHB17:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE17:
.L931:
	endbr64
	movq	%rax, %rbp
	jmp	.L922
.L930:
	endbr64
	movq	%rax, %rbp
	jmp	.L923
.L929:
	endbr64
	movq	%rax, %rbp
	jmp	.L924
.L922:
	leaq	48(%rbx), %rdi
	call	_ZNSt6vectorIySaIyEED1Ev
.L923:
	leaq	24(%rbx), %rdi
	call	_ZNSt6vectorIiSaIiEED1Ev
.L924:
	movq	%rbx, %rdi
	call	_ZNSt6vectorIiSaIiEED1Ev
	movq	%rbp, %rdi
.LEHB18:
	call	_Unwind_Resume@PLT
.LEHE18:
	.cfi_endproc
.LFE10100:
	.section	.gcc_except_table._ZZN6Packer6nestedEdxdddENKUlvE_clEv,"aG",@progbits,_ZZN6Packer6nestedEdxdddENKUlvE_clEv,comdat
.LLSDA10100:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE10100-.LLSDACSB10100
.LLSDACSB10100:
	.uleb128 .LEHB10-.LFB10100
	.uleb128 .LEHE10-.LEHB10
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB11-.LFB10100
	.uleb128 .LEHE11-.LEHB11
	.uleb128 .L929-.LFB10100
	.uleb128 0
	.uleb128 .LEHB12-.LFB10100
	.uleb128 .LEHE12-.LEHB12
	.uleb128 .L930-.LFB10100
	.uleb128 0
	.uleb128 .LEHB13-.LFB10100
	.uleb128 .LEHE13-.LEHB13
	.uleb128 .L931-.LFB10100
	.uleb128 0
	.uleb128 .LEHB14-.LFB10100
	.uleb128 .LEHE14-.LEHB14
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB15-.LFB10100
	.uleb128 .LEHE15-.LEHB15
	.uleb128 .L929-.LFB10100
	.uleb128 0
	.uleb128 .LEHB16-.LFB10100
	.uleb128 .LEHE16-.LEHB16
	.uleb128 .L930-.LFB10100
	.uleb128 0
	.uleb128 .LEHB17-.LFB10100
	.uleb128 .LEHE17-.LEHB17
	.uleb128 .L931-.LFB10100
	.uleb128 0
	.uleb128 .LEHB18-.LFB10100
	.uleb128 .LEHE18-.LEHB18
	.uleb128 0
	.uleb128 0
.LLSDACSE10100:
	.section	.text._ZZN6Packer6nestedEdxdddENKUlvE_clEv,"axG",@progbits,_ZZN6Packer6nestedEdxdddENKUlvE_clEv,comdat
	.size	_ZZN6Packer6nestedEdxdddENKUlvE_clEv, .-_ZZN6Packer6nestedEdxdddENKUlvE_clEv
	.section	.text._ZNSt6vectorI9PlacementSaIS0_EED2Ev,"axG",@progbits,_ZNSt6vectorI9PlacementSaIS0_EED5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorI9PlacementSaIS0_EED2Ev
	.type	_ZNSt6vectorI9PlacementSaIS0_EED2Ev, @function
_ZNSt6vectorI9PlacementSaIS0_EED2Ev:
.LFB11233:
	.cfi_startproc
	endbr64
	movq	(%rdi), %rax
	testq	%rax, %rax
	je	.L938
	movq	16(%rdi), %rsi
	movq	%rax, %rdi
	subq	%rax, %rsi
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L938:
	ret
	.cfi_endproc
.LFE11233:
	.size	_ZNSt6vectorI9PlacementSaIS0_EED2Ev, .-_ZNSt6vectorI9PlacementSaIS0_EED2Ev
	.weak	_ZNSt6vectorI9PlacementSaIS0_EED1Ev
	.set	_ZNSt6vectorI9PlacementSaIS0_EED1Ev,_ZNSt6vectorI9PlacementSaIS0_EED2Ev
	.section	.text._ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EED2Ev,"axG",@progbits,_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EED5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EED2Ev
	.type	_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EED2Ev, @function
_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EED2Ev:
.LFB11292:
	.cfi_startproc
	endbr64
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	8(%rdi), %rbp
	movq	(%rdi), %rbx
	cmpq	%rbx, %rbp
	je	.L941
	.p2align 4,,10
	.p2align 3
.L946:
	movq	80(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L942
	movq	96(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L942:
	movq	48(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L943
	movq	64(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L943:
	movq	24(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L944
	movq	40(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L944:
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L945
	movq	16(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L945:
	addq	$120, %rbx
	cmpq	%rbx, %rbp
	jne	.L946
	movq	(%r12), %rbx
.L941:
	testq	%rbx, %rbx
	je	.L940
	movq	16(%r12), %rsi
	movq	%rbx, %rdi
	subq	%rbx, %rsi
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L940:
	.cfi_restore_state
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE11292:
	.size	_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EED2Ev, .-_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EED2Ev
	.weak	_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EED1Ev
	.set	_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EED1Ev,_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EED2Ev
	.section	.text._ZNSt6vectorIN10BeamPacker5StateESaIS1_EED2Ev,"axG",@progbits,_ZNSt6vectorIN10BeamPacker5StateESaIS1_EED5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorIN10BeamPacker5StateESaIS1_EED2Ev
	.type	_ZNSt6vectorIN10BeamPacker5StateESaIS1_EED2Ev, @function
_ZNSt6vectorIN10BeamPacker5StateESaIS1_EED2Ev:
.LFB11378:
	.cfi_startproc
	endbr64
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	8(%rdi), %rbp
	movq	(%rdi), %rbx
	cmpq	%rbx, %rbp
	je	.L963
	.p2align 4,,10
	.p2align 3
.L967:
	movq	48(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L964
	movq	64(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L964:
	movq	24(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L965
	movq	40(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L965:
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L966
	movq	16(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L966:
	subq	$-128, %rbx
	cmpq	%rbx, %rbp
	jne	.L967
	movq	(%r12), %rbx
.L963:
	testq	%rbx, %rbx
	je	.L962
	movq	16(%r12), %rsi
	movq	%rbx, %rdi
	subq	%rbx, %rsi
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L962:
	.cfi_restore_state
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE11378:
	.size	_ZNSt6vectorIN10BeamPacker5StateESaIS1_EED2Ev, .-_ZNSt6vectorIN10BeamPacker5StateESaIS1_EED2Ev
	.weak	_ZNSt6vectorIN10BeamPacker5StateESaIS1_EED1Ev
	.set	_ZNSt6vectorIN10BeamPacker5StateESaIS1_EED1Ev,_ZNSt6vectorIN10BeamPacker5StateESaIS1_EED2Ev
	.section	.text._ZNSt10_HashtableImmSaImENSt8__detail9_IdentityESt8equal_toImESt4hashImENS1_18_Mod_range_hashingENS1_20_Default_ranged_hashENS1_20_Prime_rehash_policyENS1_17_Hashtable_traitsILb0ELb1ELb1EEEED2Ev,"axG",@progbits,_ZNSt10_HashtableImmSaImENSt8__detail9_IdentityESt8equal_toImESt4hashImENS1_18_Mod_range_hashingENS1_20_Default_ranged_hashENS1_20_Prime_rehash_policyENS1_17_Hashtable_traitsILb0ELb1ELb1EEEED5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt10_HashtableImmSaImENSt8__detail9_IdentityESt8equal_toImESt4hashImENS1_18_Mod_range_hashingENS1_20_Default_ranged_hashENS1_20_Prime_rehash_policyENS1_17_Hashtable_traitsILb0ELb1ELb1EEEED2Ev
	.type	_ZNSt10_HashtableImmSaImENSt8__detail9_IdentityESt8equal_toImESt4hashImENS1_18_Mod_range_hashingENS1_20_Default_ranged_hashENS1_20_Prime_rehash_policyENS1_17_Hashtable_traitsILb0ELb1ELb1EEEED2Ev, @function
_ZNSt10_HashtableImmSaImENSt8__detail9_IdentityESt8equal_toImESt4hashImENS1_18_Mod_range_hashingENS1_20_Default_ranged_hashENS1_20_Prime_rehash_policyENS1_17_Hashtable_traitsILb0ELb1ELb1EEEED2Ev:
.LFB11419:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	16(%rdi), %rbx
	testq	%rbx, %rbx
	je	.L981
	.p2align 4,,10
	.p2align 3
.L982:
	movq	%rbx, %rdi
	movq	(%rbx), %rbx
	movl	$16, %esi
	call	_ZdlPvm@PLT
	testq	%rbx, %rbx
	jne	.L982
.L981:
	movq	8(%rbp), %rax
	movq	0(%rbp), %rdi
	xorl	%esi, %esi
	addq	$48, %rbp
	leaq	0(,%rax,8), %rdx
	call	memset@PLT
	movq	-48(%rbp), %rdi
	movq	-40(%rbp), %rsi
	movq	$0, -24(%rbp)
	movq	$0, -32(%rbp)
	cmpq	%rbp, %rdi
	je	.L980
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	salq	$3, %rsi
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L980:
	.cfi_restore_state
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE11419:
	.size	_ZNSt10_HashtableImmSaImENSt8__detail9_IdentityESt8equal_toImESt4hashImENS1_18_Mod_range_hashingENS1_20_Default_ranged_hashENS1_20_Prime_rehash_policyENS1_17_Hashtable_traitsILb0ELb1ELb1EEEED2Ev, .-_ZNSt10_HashtableImmSaImENSt8__detail9_IdentityESt8equal_toImESt4hashImENS1_18_Mod_range_hashingENS1_20_Default_ranged_hashENS1_20_Prime_rehash_policyENS1_17_Hashtable_traitsILb0ELb1ELb1EEEED2Ev
	.weak	_ZNSt10_HashtableImmSaImENSt8__detail9_IdentityESt8equal_toImESt4hashImENS1_18_Mod_range_hashingENS1_20_Default_ranged_hashENS1_20_Prime_rehash_policyENS1_17_Hashtable_traitsILb0ELb1ELb1EEEED1Ev
	.set	_ZNSt10_HashtableImmSaImENSt8__detail9_IdentityESt8equal_toImESt4hashImENS1_18_Mod_range_hashingENS1_20_Default_ranged_hashENS1_20_Prime_rehash_policyENS1_17_Hashtable_traitsILb0ELb1ELb1EEEED1Ev,_ZNSt10_HashtableImmSaImENSt8__detail9_IdentityESt8equal_toImESt4hashImENS1_18_Mod_range_hashingENS1_20_Default_ranged_hashENS1_20_Prime_rehash_policyENS1_17_Hashtable_traitsILb0ELb1ELb1EEEED2Ev
	.section	.rodata._ZNSt6vectorIiSaIiEEC2ESt16initializer_listIiERKS0_.str1.8,"aMS",@progbits,1
	.align 8
.LC1:
	.string	"cannot create std::vector larger than max_size()"
	.section	.text._ZNSt6vectorIiSaIiEEC2ESt16initializer_listIiERKS0_,"axG",@progbits,_ZNSt6vectorIiSaIiEEC5ESt16initializer_listIiERKS0_,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorIiSaIiEEC2ESt16initializer_listIiERKS0_
	.type	_ZNSt6vectorIiSaIiEEC2ESt16initializer_listIiERKS0_, @function
_ZNSt6vectorIiSaIiEEC2ESt16initializer_listIiERKS0_:
.LFB11431:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA11431
	endbr64
	movabsq	$9223372036854775804, %rax
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pxor	%xmm0, %xmm0
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	leaq	0(,%rdx,4), %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	movq	%rdi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	movq	$0, 16(%rdi)
	movups	%xmm0, (%rdi)
	cmpq	%rbp, %rax
	jb	.L1003
	testq	%rbp, %rbp
	je	.L1004
	movq	%rbp, %rdi
	movq	%rsi, %r12
.LEHB19:
	call	_Znwm@PLT
	leaq	(%rax,%rbp), %r13
	movq	%rax, (%rbx)
	movq	%rax, %rdi
	movq	%r13, 16(%rbx)
	cmpq	$4, %rbp
	je	.L993
	movq	%rbp, %rdx
	movq	%r12, %rsi
	call	memcpy@PLT
.L992:
	movq	%r13, 8(%rbx)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1004:
	.cfi_restore_state
	xorl	%r13d, %r13d
	movq	$0, (%rdi)
	movq	$0, 16(%rdi)
	movq	%r13, 8(%rbx)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L993:
	.cfi_restore_state
	movl	(%r12), %eax
	movl	%eax, (%rdi)
	jmp	.L992
.L1003:
	leaq	.LC1(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE19:
.L997:
	endbr64
	movq	%rax, %rbp
.L995:
	movq	(%rbx), %rdi
	movq	16(%rbx), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L996
	call	_ZdlPvm@PLT
.L996:
	movq	%rbp, %rdi
.LEHB20:
	call	_Unwind_Resume@PLT
.LEHE20:
	.cfi_endproc
.LFE11431:
	.section	.gcc_except_table._ZNSt6vectorIiSaIiEEC2ESt16initializer_listIiERKS0_,"aG",@progbits,_ZNSt6vectorIiSaIiEEC5ESt16initializer_listIiERKS0_,comdat
.LLSDA11431:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE11431-.LLSDACSB11431
.LLSDACSB11431:
	.uleb128 .LEHB19-.LFB11431
	.uleb128 .LEHE19-.LEHB19
	.uleb128 .L997-.LFB11431
	.uleb128 0
	.uleb128 .LEHB20-.LFB11431
	.uleb128 .LEHE20-.LEHB20
	.uleb128 0
	.uleb128 0
.LLSDACSE11431:
	.section	.text._ZNSt6vectorIiSaIiEEC2ESt16initializer_listIiERKS0_,"axG",@progbits,_ZNSt6vectorIiSaIiEEC5ESt16initializer_listIiERKS0_,comdat
	.size	_ZNSt6vectorIiSaIiEEC2ESt16initializer_listIiERKS0_, .-_ZNSt6vectorIiSaIiEEC2ESt16initializer_listIiERKS0_
	.weak	_ZNSt6vectorIiSaIiEEC1ESt16initializer_listIiERKS0_
	.set	_ZNSt6vectorIiSaIiEEC1ESt16initializer_listIiERKS0_,_ZNSt6vectorIiSaIiEEC2ESt16initializer_listIiERKS0_
	.section	.text._ZNSt6vectorI5PieceSaIS0_EED2Ev,"axG",@progbits,_ZNSt6vectorI5PieceSaIS0_EED5Ev,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorI5PieceSaIS0_EED2Ev
	.type	_ZNSt6vectorI5PieceSaIS0_EED2Ev, @function
_ZNSt6vectorI5PieceSaIS0_EED2Ev:
.LFB11452:
	.cfi_startproc
	endbr64
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	8(%rdi), %rbp
	movq	(%rdi), %rbx
	cmpq	%rbx, %rbp
	je	.L1006
	.p2align 4,,10
	.p2align 3
.L1008:
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L1007
	movq	16(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L1007:
	addq	$24, %rbx
	cmpq	%rbx, %rbp
	jne	.L1008
	movq	(%r12), %rbx
.L1006:
	testq	%rbx, %rbx
	je	.L1005
	movq	16(%r12), %rsi
	movq	%rbx, %rdi
	subq	%rbx, %rsi
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L1005:
	.cfi_restore_state
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE11452:
	.size	_ZNSt6vectorI5PieceSaIS0_EED2Ev, .-_ZNSt6vectorI5PieceSaIS0_EED2Ev
	.weak	_ZNSt6vectorI5PieceSaIS0_EED1Ev
	.set	_ZNSt6vectorI5PieceSaIS0_EED1Ev,_ZNSt6vectorI5PieceSaIS0_EED2Ev
	.section	.text._ZNSt6vectorI5PointSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_,"axG",@progbits,_ZNSt6vectorI5PointSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorI5PointSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_
	.type	_ZNSt6vectorI5PointSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_, @function
_ZNSt6vectorI5PointSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_:
.LFB11901:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdx, %r15
	movabsq	$576460752303423487, %rdx
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	8(%rdi), %r12
	movq	(%rdi), %r13
	movq	%r12, %rax
	subq	%r13, %rax
	sarq	$4, %rax
	cmpq	%rdx, %rax
	je	.L1037
	movq	%rsi, %rdx
	movq	%rdi, %rbp
	movq	%rsi, %r14
	subq	%r13, %rdx
	cmpq	%r12, %r13
	je	.L1038
	leaq	(%rax,%rax), %rcx
	cmpq	%rax, %rcx
	jb	.L1030
	testq	%rcx, %rcx
	jne	.L1039
	xorl	%ebx, %ebx
	xorl	%ecx, %ecx
.L1021:
	movdqu	(%r15), %xmm0
	leaq	16(%rcx,%rdx), %r8
	subq	%r14, %r12
	leaq	(%r8,%r12), %r15
	movups	%xmm0, (%rcx,%rdx)
	testq	%rdx, %rdx
	jg	.L1040
	testq	%r12, %r12
	jle	.L1025
	movq	%r12, %rdx
	movq	%r14, %rsi
	movq	%r8, %rdi
	movq	%rcx, (%rsp)
	call	memcpy@PLT
	movq	(%rsp), %rcx
.L1025:
	testq	%r13, %r13
	jne	.L1024
.L1027:
	movq	%rcx, 0(%rbp)
	movq	%r15, 8(%rbp)
	movq	%rbx, 16(%rbp)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1030:
	.cfi_restore_state
	movabsq	$9223372036854775792, %rbx
.L1020:
	movq	%rbx, %rdi
	movq	%rdx, (%rsp)
	call	_Znwm@PLT
	movq	(%rsp), %rdx
	movq	%rax, %rcx
	addq	%rax, %rbx
	jmp	.L1021
	.p2align 4,,10
	.p2align 3
.L1040:
	movq	%rcx, %rdi
	movq	%r13, %rsi
	movq	%r8, (%rsp)
	call	memmove@PLT
	movq	%rax, %rcx
	testq	%r12, %r12
	jg	.L1041
.L1024:
	movq	16(%rbp), %rsi
	movq	%r13, %rdi
	movq	%rcx, (%rsp)
	subq	%r13, %rsi
	call	_ZdlPvm@PLT
	movq	(%rsp), %rcx
	jmp	.L1027
	.p2align 4,,10
	.p2align 3
.L1038:
	addq	$1, %rax
	jc	.L1030
	movabsq	$576460752303423487, %rcx
	cmpq	%rcx, %rax
	movq	%rcx, %rbx
	cmovbe	%rax, %rbx
	salq	$4, %rbx
	jmp	.L1020
	.p2align 4,,10
	.p2align 3
.L1041:
	movq	(%rsp), %rdi
	movq	%r12, %rdx
	movq	%r14, %rsi
	movq	%rax, 8(%rsp)
	call	memcpy@PLT
	movq	8(%rsp), %rcx
	jmp	.L1024
.L1039:
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %rcx
	cmova	%rax, %rcx
	movq	%rcx, %rbx
	salq	$4, %rbx
	jmp	.L1020
.L1037:
	leaq	.LC0(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE11901:
	.size	_ZNSt6vectorI5PointSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_, .-_ZNSt6vectorI5PointSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_
	.section	.rodata._ZNSt6vectorISt5arrayI9PlacementLm8EESaIS2_EE17_M_default_appendEm.str1.1,"aMS",@progbits,1
.LC2:
	.string	"vector::_M_default_append"
	.section	.text._ZNSt6vectorISt5arrayI9PlacementLm8EESaIS2_EE17_M_default_appendEm,"axG",@progbits,_ZNSt6vectorISt5arrayI9PlacementLm8EESaIS2_EE17_M_default_appendEm,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorISt5arrayI9PlacementLm8EESaIS2_EE17_M_default_appendEm
	.type	_ZNSt6vectorISt5arrayI9PlacementLm8EESaIS2_EE17_M_default_appendEm, @function
_ZNSt6vectorISt5arrayI9PlacementLm8EESaIS2_EE17_M_default_appendEm:
.LFB11961:
	.cfi_startproc
	endbr64
	testq	%rsi, %rsi
	je	.L1074
	movabsq	$-6148914691236517205, %rcx
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdi, %r15
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	movq	%rsi, %r14
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	8(%rdi), %rbx
	movq	16(%rdi), %rax
	movq	(%rdi), %r13
	subq	%rbx, %rax
	sarq	$6, %rax
	imulq	%rcx, %rax
	cmpq	%rsi, %rax
	jnb	.L1078
	movabsq	$48038396025285290, %rdx
	subq	%r13, %rbx
	movq	%rbx, %rax
	sarq	$6, %rax
	imulq	%rcx, %rax
	subq	%rax, %rdx
	cmpq	%rsi, %rdx
	jb	.L1079
	leaq	-1(%rsi), %rsi
	leaq	(%r14,%rax), %r12
	movq	%rsi, 8(%rsp)
	cmpq	%r14, %rax
	jb	.L1048
	movabsq	$48038396025285290, %rdx
	addq	%rax, %rax
	cmpq	%rdx, %rax
	cmova	%rdx, %rax
	leaq	(%rax,%rax,2), %rbp
	salq	$6, %rbp
	movq	%rbp, %rdi
	call	_Znwm@PLT
	movl	$24, %ecx
	leaq	(%rax,%rbx), %rdx
	movq	%rax, %r9
	xorl	%eax, %eax
	movq	%rdx, %rdi
	rep stosq
	cmpq	$1, %r14
	je	.L1049
.L1077:
	movq	8(%rsp), %rdi
	leaq	192(%rdx), %rax
	leaq	(%rdi,%rdi,2), %rcx
	salq	$6, %rcx
	addq	%rax, %rcx
	.p2align 4,,10
	.p2align 3
.L1052:
	movdqu	(%rdx), %xmm4
	addq	$192, %rax
	movups	%xmm4, -192(%rax)
	movdqu	16(%rdx), %xmm5
	movups	%xmm5, -176(%rax)
	movdqu	32(%rdx), %xmm6
	movups	%xmm6, -160(%rax)
	movdqu	48(%rdx), %xmm7
	movups	%xmm7, -144(%rax)
	movdqu	64(%rdx), %xmm4
	movups	%xmm4, -128(%rax)
	movdqu	80(%rdx), %xmm5
	movups	%xmm5, -112(%rax)
	movdqu	96(%rdx), %xmm6
	movups	%xmm6, -96(%rax)
	movdqu	112(%rdx), %xmm7
	movups	%xmm7, -80(%rax)
	movdqu	128(%rdx), %xmm0
	movups	%xmm0, -64(%rax)
	movdqu	144(%rdx), %xmm1
	movups	%xmm1, -48(%rax)
	movdqu	160(%rdx), %xmm2
	movups	%xmm2, -32(%rax)
	movdqu	176(%rdx), %xmm3
	movups	%xmm3, -16(%rax)
	cmpq	%rax, %rcx
	jne	.L1052
.L1051:
	testq	%rbx, %rbx
	jne	.L1049
	testq	%r13, %r13
	jne	.L1080
.L1055:
	leaq	(%r12,%r12,2), %rax
	movq	%r9, (%r15)
	salq	$6, %rax
	addq	%r9, %rax
	addq	%rbp, %r9
	movq	%rax, 8(%r15)
	movq	%r9, 16(%r15)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1078:
	.cfi_restore_state
	movl	$24, %ecx
	xorl	%eax, %eax
	movq	%rbx, %rdi
	rep stosq
	leaq	192(%rbx), %rsi
	subq	$1, %r14
	jne	.L1081
.L1045:
	movq	%rsi, 8(%r15)
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1074:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
	ret
	.p2align 4,,10
	.p2align 3
.L1081:
	.cfi_def_cfa_offset 80
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	leaq	(%r14,%r14,2), %rcx
	movq	%rsi, %rax
	salq	$6, %rcx
	addq	%rsi, %rcx
	.p2align 4,,10
	.p2align 3
.L1046:
	movdqu	(%rbx), %xmm0
	addq	$192, %rax
	movups	%xmm0, -192(%rax)
	movdqu	16(%rbx), %xmm1
	movups	%xmm1, -176(%rax)
	movdqu	32(%rbx), %xmm2
	movups	%xmm2, -160(%rax)
	movdqu	48(%rbx), %xmm3
	movups	%xmm3, -144(%rax)
	movdqu	64(%rbx), %xmm4
	movups	%xmm4, -128(%rax)
	movdqu	80(%rbx), %xmm5
	movups	%xmm5, -112(%rax)
	movdqu	96(%rbx), %xmm6
	movups	%xmm6, -96(%rax)
	movdqu	112(%rbx), %xmm7
	movups	%xmm7, -80(%rax)
	movdqu	128(%rbx), %xmm0
	movups	%xmm0, -64(%rax)
	movdqu	144(%rbx), %xmm1
	movups	%xmm1, -48(%rax)
	movdqu	160(%rbx), %xmm2
	movups	%xmm2, -32(%rax)
	movdqu	176(%rbx), %xmm3
	movups	%xmm3, -16(%rax)
	cmpq	%rax, %rcx
	jne	.L1046
	movabsq	$192153584101141163, %rdx
	subq	%rbx, %rcx
	leaq	-384(%rcx), %rax
	shrq	$6, %rax
	imulq	%rdx, %rax
	movabsq	$288230376151711743, %rdx
	andq	%rdx, %rax
	leaq	3(%rax,%rax,2), %rax
	salq	$6, %rax
	addq	%rax, %rsi
	jmp	.L1045
	.p2align 4,,10
	.p2align 3
.L1049:
	movq	%r13, %rsi
	movq	%r9, %rdi
	movq	%rbx, %rdx
	call	memmove@PLT
	movq	16(%r15), %rsi
	movq	%rax, %r9
	subq	%r13, %rsi
.L1054:
	movq	%r13, %rdi
	movq	%r9, 8(%rsp)
	call	_ZdlPvm@PLT
	movq	8(%rsp), %r9
	jmp	.L1055
	.p2align 4,,10
	.p2align 3
.L1048:
	movabsq	$48038396025285290, %rax
	cmpq	%rax, %r12
	cmovbe	%r12, %rax
	leaq	(%rax,%rax,2), %rbp
	salq	$6, %rbp
	movq	%rbp, %rdi
	call	_Znwm@PLT
	movl	$24, %ecx
	leaq	(%rax,%rbx), %rdx
	movq	%rax, %r9
	xorl	%eax, %eax
	cmpq	$0, 8(%rsp)
	movq	%rdx, %rdi
	rep stosq
	je	.L1051
	jmp	.L1077
	.p2align 4,,10
	.p2align 3
.L1080:
	movq	16(%r15), %rsi
	subq	%r13, %rsi
	jmp	.L1054
.L1079:
	leaq	.LC2(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE11961:
	.size	_ZNSt6vectorISt5arrayI9PlacementLm8EESaIS2_EE17_M_default_appendEm, .-_ZNSt6vectorISt5arrayI9PlacementLm8EESaIS2_EE17_M_default_appendEm
	.section	.text._ZNSt6vectorIiSaIiEE17_M_realloc_insertIJRKiEEEvN9__gnu_cxx17__normal_iteratorIPiS1_EEDpOT_,"axG",@progbits,_ZNSt6vectorIiSaIiEE17_M_realloc_insertIJRKiEEEvN9__gnu_cxx17__normal_iteratorIPiS1_EEDpOT_,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorIiSaIiEE17_M_realloc_insertIJRKiEEEvN9__gnu_cxx17__normal_iteratorIPiS1_EEDpOT_
	.type	_ZNSt6vectorIiSaIiEE17_M_realloc_insertIJRKiEEEvN9__gnu_cxx17__normal_iteratorIPiS1_EEDpOT_, @function
_ZNSt6vectorIiSaIiEE17_M_realloc_insertIJRKiEEEvN9__gnu_cxx17__normal_iteratorIPiS1_EEDpOT_:
.LFB12055:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdx, %r15
	movabsq	$2305843009213693951, %rdx
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	8(%rdi), %r12
	movq	(%rdi), %r13
	movq	%r12, %rax
	subq	%r13, %rax
	sarq	$2, %rax
	cmpq	%rdx, %rax
	je	.L1104
	movq	%rsi, %rdx
	movq	%rdi, %rbp
	movq	%rsi, %r14
	subq	%r13, %rdx
	cmpq	%r12, %r13
	je	.L1105
	leaq	(%rax,%rax), %rcx
	cmpq	%rax, %rcx
	jb	.L1097
	testq	%rcx, %rcx
	jne	.L1106
	xorl	%ebx, %ebx
	xorl	%ecx, %ecx
.L1088:
	movl	(%r15), %eax
	leaq	4(%rcx,%rdx), %r8
	subq	%r14, %r12
	leaq	(%r8,%r12), %r15
	movl	%eax, (%rcx,%rdx)
	testq	%rdx, %rdx
	jg	.L1107
	testq	%r12, %r12
	jle	.L1092
	movq	%r12, %rdx
	movq	%r14, %rsi
	movq	%r8, %rdi
	movq	%rcx, (%rsp)
	call	memcpy@PLT
	movq	(%rsp), %rcx
.L1092:
	testq	%r13, %r13
	jne	.L1091
.L1094:
	movq	%rcx, 0(%rbp)
	movq	%r15, 8(%rbp)
	movq	%rbx, 16(%rbp)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1097:
	.cfi_restore_state
	movabsq	$9223372036854775804, %rbx
.L1087:
	movq	%rbx, %rdi
	movq	%rdx, (%rsp)
	call	_Znwm@PLT
	movq	(%rsp), %rdx
	movq	%rax, %rcx
	addq	%rax, %rbx
	jmp	.L1088
	.p2align 4,,10
	.p2align 3
.L1107:
	movq	%rcx, %rdi
	movq	%r13, %rsi
	movq	%r8, (%rsp)
	call	memmove@PLT
	movq	%rax, %rcx
	testq	%r12, %r12
	jg	.L1108
.L1091:
	movq	16(%rbp), %rsi
	movq	%r13, %rdi
	movq	%rcx, (%rsp)
	subq	%r13, %rsi
	call	_ZdlPvm@PLT
	movq	(%rsp), %rcx
	jmp	.L1094
	.p2align 4,,10
	.p2align 3
.L1105:
	addq	$1, %rax
	jc	.L1097
	movabsq	$2305843009213693951, %rcx
	cmpq	%rcx, %rax
	movq	%rcx, %rbx
	cmovbe	%rax, %rbx
	salq	$2, %rbx
	jmp	.L1087
	.p2align 4,,10
	.p2align 3
.L1108:
	movq	(%rsp), %rdi
	movq	%r12, %rdx
	movq	%r14, %rsi
	movq	%rax, 8(%rsp)
	call	memcpy@PLT
	movq	8(%rsp), %rcx
	jmp	.L1091
.L1106:
	movabsq	$2305843009213693951, %rax
	cmpq	%rax, %rcx
	cmova	%rax, %rcx
	leaq	0(,%rcx,4), %rbx
	jmp	.L1087
.L1104:
	leaq	.LC0(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE12055:
	.size	_ZNSt6vectorIiSaIiEE17_M_realloc_insertIJRKiEEEvN9__gnu_cxx17__normal_iteratorIPiS1_EEDpOT_, .-_ZNSt6vectorIiSaIiEE17_M_realloc_insertIJRKiEEEvN9__gnu_cxx17__normal_iteratorIPiS1_EEDpOT_
	.section	.text._ZNSt6vectorISt4pairIdiESaIS1_EE17_M_default_appendEm,"axG",@progbits,_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_default_appendEm,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_default_appendEm
	.type	_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_default_appendEm, @function
_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_default_appendEm:
.LFB12101:
	.cfi_startproc
	endbr64
	testq	%rsi, %rsi
	je	.L1130
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	movq	%rdi, %r14
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	8(%rdi), %rbx
	movq	16(%rdi), %rax
	movq	(%rdi), %r15
	subq	%rbx, %rax
	sarq	$4, %rax
	cmpq	%rsi, %rax
	jb	.L1111
	salq	$4, %rbp
	addq	%rbx, %rbp
	.p2align 4,,10
	.p2align 3
.L1112:
	movq	$0x000000000, (%rbx)
	addq	$16, %rbx
	movl	$0, -8(%rbx)
	cmpq	%rbp, %rbx
	jne	.L1112
	movq	%rbx, 8(%r14)
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1130:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
	ret
	.p2align 4,,10
	.p2align 3
.L1111:
	.cfi_def_cfa_offset 80
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movabsq	$576460752303423487, %rdx
	movq	%rbx, %rcx
	subq	%r15, %rcx
	movq	%rcx, %rax
	sarq	$4, %rax
	subq	%rax, %rdx
	cmpq	%rsi, %rdx
	jb	.L1133
	movabsq	$576460752303423487, %r13
	leaq	(%rsi,%rax), %r12
	cmpq	%r13, %r12
	cmovbe	%r12, %r13
	cmpq	%rsi, %rax
	jb	.L1115
	leaq	(%rax,%rax), %r13
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %r13
	cmova	%rax, %r13
.L1115:
	salq	$4, %r13
	movq	%rcx, 8(%rsp)
	movq	%r13, %rdi
	salq	$4, %rbp
	call	_Znwm@PLT
	movq	8(%rsp), %rcx
	movq	%rax, %r8
	leaq	(%rax,%rcx), %rax
	addq	%rax, %rbp
	.p2align 4,,10
	.p2align 3
.L1116:
	movq	$0x000000000, (%rax)
	addq	$16, %rax
	movl	$0, -8(%rax)
	cmpq	%rbp, %rax
	jne	.L1116
	movq	%r8, %rdx
	movq	%r15, %rax
	cmpq	%rbx, %r15
	je	.L1120
	.p2align 4,,10
	.p2align 3
.L1117:
	movdqu	(%rax), %xmm0
	addq	$16, %rax
	addq	$16, %rdx
	movups	%xmm0, -16(%rdx)
	cmpq	%rax, %rbx
	jne	.L1117
.L1120:
	testq	%r15, %r15
	je	.L1119
	movq	16(%r14), %rsi
	movq	%r15, %rdi
	movq	%r8, 8(%rsp)
	subq	%r15, %rsi
	call	_ZdlPvm@PLT
	movq	8(%rsp), %r8
.L1119:
	movq	%r12, %rcx
	movq	%r8, (%r14)
	salq	$4, %rcx
	addq	%r8, %rcx
	addq	%r13, %r8
	movq	%rcx, 8(%r14)
	movq	%r8, 16(%r14)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1133:
	.cfi_restore_state
	leaq	.LC2(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE12101:
	.size	_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_default_appendEm, .-_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_default_appendEm
	.section	.text._ZNSt6vectorIiSaIiEE17_M_default_appendEm,"axG",@progbits,_ZNSt6vectorIiSaIiEE17_M_default_appendEm,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorIiSaIiEE17_M_default_appendEm
	.type	_ZNSt6vectorIiSaIiEE17_M_default_appendEm, @function
_ZNSt6vectorIiSaIiEE17_M_default_appendEm:
.LFB12154:
	.cfi_startproc
	endbr64
	testq	%rsi, %rsi
	je	.L1162
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	movq	%rdi, %r14
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rsi, %rbx
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	8(%rdi), %rdx
	movq	16(%rdi), %rax
	movq	(%rdi), %r12
	subq	%rdx, %rax
	sarq	$2, %rax
	cmpq	%rsi, %rax
	jnb	.L1166
	subq	%r12, %rdx
	movq	%rdx, %rax
	movq	%rdx, %r13
	movabsq	$2305843009213693951, %rdx
	sarq	$2, %rax
	subq	%rax, %rdx
	cmpq	%rsi, %rdx
	jb	.L1167
	leaq	-1(%rsi), %rcx
	movq	%rcx, 8(%rsp)
	leaq	(%rsi,%rax), %rcx
	movq	%rcx, (%rsp)
	cmpq	%rsi, %rax
	jb	.L1139
	movabsq	$2305843009213693951, %rdx
	addq	%rax, %rax
	cmpq	%rdx, %rax
	cmova	%rdx, %rax
	leaq	0(,%rax,4), %r15
	movq	%r15, %rdi
	call	_Znwm@PLT
	leaq	(%rax,%r13), %rdi
	movq	%rax, %rbp
	movl	$0, (%rdi)
	cmpq	$1, %rbx
	je	.L1140
.L1165:
	movq	8(%rsp), %rdx
	addq	$4, %rdi
	xorl	%esi, %esi
	salq	$2, %rdx
	call	memset@PLT
.L1142:
	testq	%r13, %r13
	jne	.L1140
	testq	%r12, %r12
	jne	.L1168
.L1145:
	movq	(%rsp), %rax
	movq	%rbp, (%r14)
	leaq	0(%rbp,%rax,4), %rax
	addq	%r15, %rbp
	movq	%rax, 8(%r14)
	movq	%rbp, 16(%r14)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1166:
	.cfi_restore_state
	movl	$0, (%rdx)
	leaq	4(%rdx), %rcx
	subq	$1, %rbx
	je	.L1137
	leaq	(%rcx,%rbx,4), %rax
	movq	%rcx, %rdi
	xorl	%esi, %esi
	subq	%rdx, %rax
	leaq	-4(%rax), %rbx
	movq	%rbx, %rdx
	call	memset@PLT
	movq	%rax, %rcx
	addq	%rbx, %rcx
.L1137:
	movq	%rcx, 8(%r14)
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1162:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
	ret
	.p2align 4,,10
	.p2align 3
.L1139:
	.cfi_def_cfa_offset 80
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movabsq	$2305843009213693951, %rax
	movq	(%rsp), %rcx
	cmpq	%rax, %rcx
	cmovbe	%rcx, %rax
	leaq	0(,%rax,4), %r15
	movq	%r15, %rdi
	call	_Znwm@PLT
	cmpq	$0, 8(%rsp)
	leaq	(%rax,%r13), %rdi
	movq	%rax, %rbp
	movl	$0, (%rdi)
	jne	.L1165
	jmp	.L1142
	.p2align 4,,10
	.p2align 3
.L1140:
	movq	%r12, %rsi
	movq	%r13, %rdx
	movq	%rbp, %rdi
	call	memmove@PLT
	movq	16(%r14), %rsi
	subq	%r12, %rsi
.L1144:
	movq	%r12, %rdi
	call	_ZdlPvm@PLT
	jmp	.L1145
	.p2align 4,,10
	.p2align 3
.L1168:
	movq	16(%r14), %rsi
	subq	%r12, %rsi
	jmp	.L1144
.L1167:
	leaq	.LC2(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE12154:
	.size	_ZNSt6vectorIiSaIiEE17_M_default_appendEm, .-_ZNSt6vectorIiSaIiEE17_M_default_appendEm
	.section	.text._ZNSt6vectorIySaIyEE17_M_default_appendEm,"axG",@progbits,_ZNSt6vectorIySaIyEE17_M_default_appendEm,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorIySaIyEE17_M_default_appendEm
	.type	_ZNSt6vectorIySaIyEE17_M_default_appendEm, @function
_ZNSt6vectorIySaIyEE17_M_default_appendEm:
.LFB12157:
	.cfi_startproc
	endbr64
	testq	%rsi, %rsi
	je	.L1197
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	movq	%rdi, %r14
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rsi, %rbx
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	8(%rdi), %rdx
	movq	16(%rdi), %rax
	movq	(%rdi), %r12
	subq	%rdx, %rax
	sarq	$3, %rax
	cmpq	%rsi, %rax
	jnb	.L1201
	subq	%r12, %rdx
	movq	%rdx, %rax
	movq	%rdx, %r13
	movabsq	$1152921504606846975, %rdx
	sarq	$3, %rax
	subq	%rax, %rdx
	cmpq	%rsi, %rdx
	jb	.L1202
	leaq	-1(%rsi), %rcx
	movq	%rcx, 8(%rsp)
	leaq	(%rsi,%rax), %rcx
	movq	%rcx, (%rsp)
	cmpq	%rsi, %rax
	jb	.L1174
	movabsq	$1152921504606846975, %rdx
	addq	%rax, %rax
	cmpq	%rdx, %rax
	cmova	%rdx, %rax
	leaq	0(,%rax,8), %r15
	movq	%r15, %rdi
	call	_Znwm@PLT
	leaq	(%rax,%r13), %rdi
	movq	%rax, %rbp
	movq	$0, (%rdi)
	cmpq	$1, %rbx
	je	.L1175
.L1200:
	movq	8(%rsp), %rdx
	addq	$8, %rdi
	xorl	%esi, %esi
	salq	$3, %rdx
	call	memset@PLT
.L1177:
	testq	%r13, %r13
	jne	.L1175
	testq	%r12, %r12
	jne	.L1203
.L1180:
	movq	(%rsp), %rax
	movq	%rbp, (%r14)
	leaq	0(%rbp,%rax,8), %rax
	addq	%r15, %rbp
	movq	%rax, 8(%r14)
	movq	%rbp, 16(%r14)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1201:
	.cfi_restore_state
	movq	$0, (%rdx)
	leaq	8(%rdx), %rcx
	subq	$1, %rbx
	je	.L1172
	leaq	(%rcx,%rbx,8), %rax
	movq	%rcx, %rdi
	xorl	%esi, %esi
	subq	%rdx, %rax
	leaq	-8(%rax), %rbx
	movq	%rbx, %rdx
	call	memset@PLT
	movq	%rax, %rcx
	addq	%rbx, %rcx
.L1172:
	movq	%rcx, 8(%r14)
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1197:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
	ret
	.p2align 4,,10
	.p2align 3
.L1174:
	.cfi_def_cfa_offset 80
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movabsq	$1152921504606846975, %rax
	movq	(%rsp), %rcx
	cmpq	%rax, %rcx
	cmovbe	%rcx, %rax
	leaq	0(,%rax,8), %r15
	movq	%r15, %rdi
	call	_Znwm@PLT
	cmpq	$0, 8(%rsp)
	leaq	(%rax,%r13), %rdi
	movq	%rax, %rbp
	movq	$0, (%rdi)
	jne	.L1200
	jmp	.L1177
	.p2align 4,,10
	.p2align 3
.L1175:
	movq	%r12, %rsi
	movq	%r13, %rdx
	movq	%rbp, %rdi
	call	memmove@PLT
	movq	16(%r14), %rsi
	subq	%r12, %rsi
.L1179:
	movq	%r12, %rdi
	call	_ZdlPvm@PLT
	jmp	.L1180
	.p2align 4,,10
	.p2align 3
.L1203:
	movq	16(%r14), %rsi
	subq	%r12, %rsi
	jmp	.L1179
.L1202:
	leaq	.LC2(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE12157:
	.size	_ZNSt6vectorIySaIyEE17_M_default_appendEm, .-_ZNSt6vectorIySaIyEE17_M_default_appendEm
	.section	.text._ZNSt6vectorI9PlacementSaIS0_EE17_M_default_appendEm,"axG",@progbits,_ZNSt6vectorI9PlacementSaIS0_EE17_M_default_appendEm,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorI9PlacementSaIS0_EE17_M_default_appendEm
	.type	_ZNSt6vectorI9PlacementSaIS0_EE17_M_default_appendEm, @function
_ZNSt6vectorI9PlacementSaIS0_EE17_M_default_appendEm:
.LFB12163:
	.cfi_startproc
	endbr64
	testq	%rsi, %rsi
	je	.L1236
	movabsq	$-6148914691236517205, %rcx
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rsi, %rbx
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	8(%rdi), %rdx
	movq	16(%rdi), %rax
	movq	(%rdi), %r15
	subq	%rdx, %rax
	sarq	$3, %rax
	imulq	%rcx, %rax
	cmpq	%rsi, %rax
	jnb	.L1239
	subq	%r15, %rdx
	movq	%rdx, %rax
	movq	%rdx, %rbp
	movabsq	$384307168202282325, %rdx
	sarq	$3, %rax
	imulq	%rcx, %rax
	subq	%rax, %rdx
	cmpq	%rsi, %rdx
	jb	.L1240
	leaq	-1(%rsi), %rcx
	leaq	(%rsi,%rax), %r14
	movq	%rcx, 8(%rsp)
	cmpq	%rsi, %rax
	jb	.L1210
	movabsq	$384307168202282325, %rdx
	addq	%rax, %rax
	cmpq	%rdx, %rax
	cmova	%rdx, %rax
	leaq	(%rax,%rax,2), %r13
	salq	$3, %r13
	movq	%r13, %rdi
	call	_Znwm@PLT
	pxor	%xmm0, %xmm0
	leaq	(%rax,%rbp), %rdx
	movq	%rax, %r8
	movq	$0, 16(%rdx)
	movups	%xmm0, (%rdx)
	cmpq	$1, %rbx
	je	.L1211
	movq	8(%rsp), %rcx
	leaq	24(%rdx), %rax
.L1212:
	leaq	(%rcx,%rcx,2), %rcx
	leaq	(%rax,%rcx,8), %rsi
	.p2align 4,,10
	.p2align 3
.L1214:
	movdqu	(%rdx), %xmm2
	addq	$24, %rax
	movups	%xmm2, -24(%rax)
	movq	16(%rdx), %rcx
	movq	%rcx, -8(%rax)
	cmpq	%rax, %rsi
	jne	.L1214
.L1213:
	testq	%rbp, %rbp
	jne	.L1211
	testq	%r15, %r15
	jne	.L1241
.L1217:
	leaq	(%r14,%r14,2), %rax
	movq	%r8, (%r12)
	leaq	(%r8,%rax,8), %rax
	addq	%r13, %r8
	movq	%rax, 8(%r12)
	movq	%r8, 16(%r12)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1239:
	.cfi_restore_state
	pxor	%xmm0, %xmm0
	movq	$0, 16(%rdx)
	leaq	24(%rdx), %rdi
	movups	%xmm0, (%rdx)
	subq	$1, %rbx
	je	.L1207
	leaq	(%rbx,%rbx,2), %rax
	leaq	(%rdi,%rax,8), %rsi
	movq	%rdi, %rax
	.p2align 4,,10
	.p2align 3
.L1208:
	movdqu	(%rdx), %xmm1
	addq	$24, %rax
	movups	%xmm1, -24(%rax)
	movq	16(%rdx), %rcx
	movq	%rcx, -8(%rax)
	cmpq	%rax, %rsi
	jne	.L1208
	subq	%rdx, %rsi
	leaq	-48(%rsi), %rax
	shrq	$3, %rax
	leaq	24(%rdi,%rax,8), %rdi
.L1207:
	movq	%rdi, 8(%r12)
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1236:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
	ret
	.p2align 4,,10
	.p2align 3
.L1210:
	.cfi_def_cfa_offset 80
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movabsq	$384307168202282325, %rax
	cmpq	%rax, %r14
	cmovbe	%r14, %rax
	leaq	(%rax,%rax,2), %r13
	salq	$3, %r13
	movq	%r13, %rdi
	call	_Znwm@PLT
	movq	8(%rsp), %rcx
	pxor	%xmm0, %xmm0
	leaq	(%rax,%rbp), %rdx
	movq	%rax, %r8
	movq	$0, 16(%rdx)
	movups	%xmm0, (%rdx)
	testq	%rcx, %rcx
	je	.L1213
	leaq	24(%rdx), %rax
	jmp	.L1212
	.p2align 4,,10
	.p2align 3
.L1211:
	movq	%r15, %rsi
	movq	%r8, %rdi
	movq	%rbp, %rdx
	call	memmove@PLT
	movq	16(%r12), %rsi
	movq	%rax, %r8
	subq	%r15, %rsi
.L1216:
	movq	%r15, %rdi
	movq	%r8, 8(%rsp)
	call	_ZdlPvm@PLT
	movq	8(%rsp), %r8
	jmp	.L1217
	.p2align 4,,10
	.p2align 3
.L1241:
	movq	16(%r12), %rsi
	subq	%r15, %rsi
	jmp	.L1216
.L1240:
	leaq	.LC2(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE12163:
	.size	_ZNSt6vectorI9PlacementSaIS0_EE17_M_default_appendEm, .-_ZNSt6vectorI9PlacementSaIS0_EE17_M_default_appendEm
	.section	.text._ZN6PackerC2ERK9Cataloguei,"axG",@progbits,_ZN6PackerC5ERK9Cataloguei,comdat
	.align 2
	.p2align 4
	.weak	_ZN6PackerC2ERK9Cataloguei
	.type	_ZN6PackerC2ERK9Cataloguei, @function
_ZN6PackerC2ERK9Cataloguei:
.LFB10084:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA10084
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pxor	%xmm0, %xmm0
	pxor	%xmm1, %xmm1
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movq	%rsi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	movq	%fs:40, %rax
	movq	%rax, 40(%rsp)
	xorl	%eax, %eax
	leaq	24(%rsi), %rax
	movq	%rsi, (%rdi)
	movq	%rax, 16(%rdi)
	leaq	24(%rdi), %rax
	movq	%rax, 24(%rsp)
	leaq	72(%rdi), %rax
	movq	%rax, 16(%rsp)
	leaq	128(%rdi), %rax
	movq	%rax, 8(%rsp)
	leaq	224(%rdi), %rax
	movq	%rsi, 8(%rdi)
	movq	$0, 88(%rdi)
	movl	%edx, 96(%rdi)
	movq	$0, 116(%rdi)
	movups	%xmm0, 24(%rdi)
	movups	%xmm0, 40(%rdi)
	movups	%xmm0, 56(%rdi)
	movups	%xmm0, 72(%rdi)
	movups	%xmm0, 128(%rdi)
	movups	%xmm0, 144(%rdi)
	movups	%xmm0, 160(%rdi)
	movb	$0, 176(%rdi)
	movq	(%rsi), %rbp
	movups	%xmm1, 184(%rdi)
	movq	8(%rsi), %r14
	movdqa	.LC4(%rip), %xmm1
	movq	$0x000000000, 200(%rdi)
	movq	%rax, (%rsp)
	movq	$0, 240(%rdi)
	movups	%xmm1, 208(%rdi)
	movups	%xmm0, 224(%rdi)
	cmpq	%r14, %rbp
	je	.L1243
	leaq	36(%rsp), %r15
	leaq	48(%rdi), %r13
	.p2align 4,,10
	.p2align 3
.L1244:
	movq	8(%rbp), %rax
	subq	0(%rbp), %rax
	movq	%r15, %rsi
	movq	%r13, %rdi
	sarq	$2, %rax
	movl	%eax, 36(%rsp)
.LEHB21:
	call	_ZNSt6vectorIiSaIiEE12emplace_backIJiEEERiDpOT_.isra.0
	addq	$48, %rbp
	cmpq	%rbp, %r14
	jne	.L1244
	movq	16(%rbx), %rcx
	movq	32(%rbx), %rdx
	movq	24(%rbx), %rdi
	movq	8(%rcx), %rax
	subq	(%rcx), %rax
	movq	%rdx, %r14
	movabsq	$-8198552921648689607, %rcx
	sarq	$4, %rax
	subq	%rdi, %r14
	imulq	%rcx, %rax
	movq	%r14, %r10
	sarq	$2, %r10
	movq	%r10, %r15
	movq	%rax, %rsi
	cmpq	%rax, %r10
	jb	.L1271
	cmpq	%r10, %rax
	jnb	.L1246
	salq	$2, %rax
	leaq	(%rdi,%rax), %rcx
	cmpq	%rdx, %rcx
	je	.L1246
	movq	%rax, %r10
	movq	%rcx, 32(%rbx)
	movq	%rax, %r14
	movq	%rcx, %rdx
	sarq	$2, %r10
	movq	%r10, %r15
	.p2align 4,,10
	.p2align 3
.L1246:
	cmpq	%rdi, %rdx
	je	.L1248
	subq	$4, %rdx
	xorl	%eax, %eax
	subq	%rdi, %rdx
	shrq	$2, %rdx
	.p2align 4,,10
	.p2align 3
.L1249:
	movq	%rax, %rcx
	movl	%eax, (%rdi,%rax,4)
	addq	$1, %rax
	cmpq	%rdx, %rcx
	jne	.L1249
	leal	-1(%r10), %ebp
	movl	%r10d, %r13d
	testl	%ebp, %ebp
	jle	.L1248
	movslq	%r10d, %rsi
	leal	-2(%r10), %eax
	movq	_ZL12random_state(%rip), %rcx
	movslq	%ebp, %rbp
	leaq	-1(%rsi), %r8
	movq	%r8, %r11
	subq	%rax, %r11
	jmp	.L1251
	.p2align 4,,10
	.p2align 3
.L1288:
	subq	$1, %r8
.L1251:
	movq	%rcx, %rax
	xorl	%edx, %edx
	salq	$7, %rax
	xorq	%rcx, %rax
	movq	%rax, %rcx
	shrq	$9, %rcx
	xorq	%rax, %rcx
	movq	%rcx, %rax
	divq	%rsi
	leaq	(%rdi,%rdx,4), %rax
	movl	-4(%rdi,%rsi,4), %edx
	movl	(%rax), %r9d
	movl	%r9d, -4(%rdi,%rsi,4)
	movq	%r8, %rsi
	movl	%edx, (%rax)
	cmpq	%r11, %r8
	jne	.L1288
	subl	$2, %r13d
	movq	%rcx, _ZL12random_state(%rip)
	movslq	%r13d, %r13
	subq	%r13, %rbp
	movl	%r9d, (%rdi,%rbp,4)
	movl	%edx, (%rax)
.L1248:
	movq	80(%rbx), %rcx
	movq	72(%rbx), %rdx
	movq	%rcx, %rax
	subq	%rdx, %rax
	cmpq	%r14, %rax
	jb	.L1289
	cmpq	%rax, %r14
	jb	.L1290
.L1253:
	testl	%r10d, %r10d
	jle	.L1260
	movq	72(%rbx), %rsi
	leal	-1(%r10), %ecx
	xorl	%eax, %eax
	.p2align 4,,10
	.p2align 3
.L1259:
	movslq	(%rdi,%rax,4), %rdx
	movl	%eax, (%rsi,%rdx,4)
	movq	%rax, %rdx
	addq	$1, %rax
	cmpq	%rcx, %rdx
	jne	.L1259
.L1260:
	movl	96(%rbx), %edx
	movq	136(%rbx), %rcx
	movq	128(%rbx), %rdi
	movl	%edx, %eax
	leal	126(%rdx), %esi
	addl	$63, %eax
	cmovns	%eax, %esi
	movl	72(%r12), %eax
	sarl	$6, %esi
	addl	$12, %eax
	movl	%esi, 100(%rbx)
	imull	%eax, %esi
	movl	%eax, 104(%rbx)
	movl	%eax, 108(%rbx)
	movq	%rcx, %rax
	subq	%rdi, %rax
	movslq	%esi, %rsi
	sarq	$3, %rax
	cmpq	%rsi, %rax
	jb	.L1291
	cmpq	%rax, %rsi
	jb	.L1292
.L1261:
	movq	232(%rbx), %r9
	movl	%edx, 216(%rbx)
	movabsq	$-6148914691236517205, %rdi
	movq	224(%rbx), %r8
	movq	56(%r12), %rdx
	movl	$0, 220(%rbx)
	subq	48(%r12), %rdx
	movq	%r9, %rax
	sarq	$6, %rdx
	subq	%r8, %rax
	movq	%rdx, %rsi
	sarq	$3, %rax
	imulq	%rdi, %rsi
	imulq	%rdi, %rax
	movq	%rsi, %rcx
	cmpq	%rsi, %rax
	jb	.L1293
	cmpq	%rax, %rsi
	jb	.L1294
.L1265:
	movl	%ecx, 112(%rbx)
	movq	40(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1286
	addq	$56, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1294:
	.cfi_restore_state
	leaq	(%r8,%rdx,8), %rax
	cmpq	%rax, %r9
	je	.L1265
	movq	%rax, 232(%rbx)
	jmp	.L1265
	.p2align 4,,10
	.p2align 3
.L1292:
	leaq	(%rdi,%rsi,8), %rax
	cmpq	%rax, %rcx
	je	.L1261
	movq	%rax, 136(%rbx)
	jmp	.L1261
	.p2align 4,,10
	.p2align 3
.L1290:
	addq	%r14, %rdx
	cmpq	%rdx, %rcx
	je	.L1253
	movq	%rdx, 80(%rbx)
	jmp	.L1253
	.p2align 4,,10
	.p2align 3
.L1289:
	sarq	$2, %rax
	movq	%r15, %rsi
	movq	16(%rsp), %rdi
	leaq	48(%rbx), %r13
	subq	%rax, %rsi
	call	_ZNSt6vectorIiSaIiEE17_M_default_appendEm
	movq	24(%rbx), %rdi
	movq	32(%rbx), %r10
	subq	%rdi, %r10
	sarq	$2, %r10
	jmp	.L1253
	.p2align 4,,10
	.p2align 3
.L1293:
	movq	(%rsp), %rdi
	subq	%rax, %rsi
	leaq	48(%rbx), %r13
	call	_ZNSt6vectorI9PlacementSaIS0_EE17_M_default_appendEm
	movabsq	$-6148914691236517205, %rax
	movq	56(%r12), %rcx
	subq	48(%r12), %rcx
	sarq	$6, %rcx
	imulq	%rax, %rcx
	jmp	.L1265
	.p2align 4,,10
	.p2align 3
.L1291:
	movq	8(%rsp), %rdi
	subq	%rax, %rsi
	leaq	48(%rbx), %r13
	call	_ZNSt6vectorIySaIyEE17_M_default_appendEm
	movl	96(%rbx), %edx
	jmp	.L1261
.L1275:
	movq	%r15, %rsi
	xorl	%r15d, %r15d
	.p2align 4,,10
	.p2align 3
.L1271:
	movq	24(%rsp), %rdi
	subq	%r15, %rsi
	leaq	48(%rbx), %r13
	call	_ZNSt6vectorIiSaIiEE17_M_default_appendEm
.LEHE21:
	movq	32(%rbx), %rdx
	movq	24(%rbx), %rdi
	movq	%rdx, %r14
	subq	%rdi, %r14
	movq	%r14, %r10
	sarq	$2, %r10
	movq	%r10, %r15
	jmp	.L1246
	.p2align 4,,10
	.p2align 3
.L1243:
	movabsq	$-8198552921648689607, %rax
	movq	32(%rsi), %r15
	subq	24(%rsi), %r15
	sarq	$4, %r15
	imulq	%rax, %r15
	testq	%r15, %r15
	jne	.L1275
	xorl	%r10d, %r10d
	xorl	%r14d, %r14d
	xorl	%edi, %edi
	jmp	.L1248
.L1268:
	movq	(%rsp), %rdi
	call	_ZNSt6vectorI9PlacementSaIS0_EED1Ev
	movq	152(%rbx), %rdi
	movq	168(%rbx), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L1269
	call	_ZdlPvm@PLT
.L1269:
	movq	8(%rsp), %rdi
	call	_ZNSt6vectorIySaIyEED1Ev
	movq	16(%rsp), %rdi
	call	_ZNSt6vectorIiSaIiEED1Ev
	movq	%r13, %rdi
	call	_ZNSt6vectorIiSaIiEED1Ev
	movq	24(%rsp), %rdi
	call	_ZNSt6vectorIiSaIiEED1Ev
	movq	40(%rsp), %rax
	subq	%fs:40, %rax
	je	.L1270
.L1286:
	call	__stack_chk_fail@PLT
.L1276:
	endbr64
	movq	%rax, %rbp
	jmp	.L1268
.L1270:
	movq	%rbp, %rdi
.LEHB22:
	call	_Unwind_Resume@PLT
.LEHE22:
	.cfi_endproc
.LFE10084:
	.section	.gcc_except_table._ZN6PackerC2ERK9Cataloguei,"aG",@progbits,_ZN6PackerC5ERK9Cataloguei,comdat
.LLSDA10084:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE10084-.LLSDACSB10084
.LLSDACSB10084:
	.uleb128 .LEHB21-.LFB10084
	.uleb128 .LEHE21-.LEHB21
	.uleb128 .L1276-.LFB10084
	.uleb128 0
	.uleb128 .LEHB22-.LFB10084
	.uleb128 .LEHE22-.LEHB22
	.uleb128 0
	.uleb128 0
.LLSDACSE10084:
	.section	.text._ZN6PackerC2ERK9Cataloguei,"axG",@progbits,_ZN6PackerC5ERK9Cataloguei,comdat
	.size	_ZN6PackerC2ERK9Cataloguei, .-_ZN6PackerC2ERK9Cataloguei
	.weak	_ZN6PackerC1ERK9Cataloguei
	.set	_ZN6PackerC1ERK9Cataloguei,_ZN6PackerC2ERK9Cataloguei
	.section	.text._ZNSt6vectorImSaImEE17_M_default_appendEm,"axG",@progbits,_ZNSt6vectorImSaImEE17_M_default_appendEm,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorImSaImEE17_M_default_appendEm
	.type	_ZNSt6vectorImSaImEE17_M_default_appendEm, @function
_ZNSt6vectorImSaImEE17_M_default_appendEm:
.LFB12276:
	.cfi_startproc
	endbr64
	testq	%rsi, %rsi
	je	.L1323
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	movq	%rdi, %r14
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rsi, %rbx
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	8(%rdi), %rdx
	movq	16(%rdi), %rax
	movq	(%rdi), %r12
	subq	%rdx, %rax
	sarq	$3, %rax
	cmpq	%rsi, %rax
	jnb	.L1327
	subq	%r12, %rdx
	movq	%rdx, %rax
	movq	%rdx, %r13
	movabsq	$1152921504606846975, %rdx
	sarq	$3, %rax
	subq	%rax, %rdx
	cmpq	%rsi, %rdx
	jb	.L1328
	leaq	-1(%rsi), %rcx
	movq	%rcx, 8(%rsp)
	leaq	(%rsi,%rax), %rcx
	movq	%rcx, (%rsp)
	cmpq	%rsi, %rax
	jb	.L1300
	movabsq	$1152921504606846975, %rdx
	addq	%rax, %rax
	cmpq	%rdx, %rax
	cmova	%rdx, %rax
	leaq	0(,%rax,8), %r15
	movq	%r15, %rdi
	call	_Znwm@PLT
	leaq	(%rax,%r13), %rdi
	movq	%rax, %rbp
	movq	$0, (%rdi)
	cmpq	$1, %rbx
	je	.L1301
.L1326:
	movq	8(%rsp), %rdx
	addq	$8, %rdi
	xorl	%esi, %esi
	salq	$3, %rdx
	call	memset@PLT
.L1303:
	testq	%r13, %r13
	jne	.L1301
	testq	%r12, %r12
	jne	.L1329
.L1306:
	movq	(%rsp), %rax
	movq	%rbp, (%r14)
	leaq	0(%rbp,%rax,8), %rax
	addq	%r15, %rbp
	movq	%rax, 8(%r14)
	movq	%rbp, 16(%r14)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1327:
	.cfi_restore_state
	movq	$0, (%rdx)
	leaq	8(%rdx), %rcx
	subq	$1, %rbx
	je	.L1298
	leaq	(%rcx,%rbx,8), %rax
	movq	%rcx, %rdi
	xorl	%esi, %esi
	subq	%rdx, %rax
	leaq	-8(%rax), %rbx
	movq	%rbx, %rdx
	call	memset@PLT
	movq	%rax, %rcx
	addq	%rbx, %rcx
.L1298:
	movq	%rcx, 8(%r14)
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1323:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
	ret
	.p2align 4,,10
	.p2align 3
.L1300:
	.cfi_def_cfa_offset 80
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movabsq	$1152921504606846975, %rax
	movq	(%rsp), %rcx
	cmpq	%rax, %rcx
	cmovbe	%rcx, %rax
	leaq	0(,%rax,8), %r15
	movq	%r15, %rdi
	call	_Znwm@PLT
	cmpq	$0, 8(%rsp)
	leaq	(%rax,%r13), %rdi
	movq	%rax, %rbp
	movq	$0, (%rdi)
	jne	.L1326
	jmp	.L1303
	.p2align 4,,10
	.p2align 3
.L1301:
	movq	%r12, %rsi
	movq	%r13, %rdx
	movq	%rbp, %rdi
	call	memmove@PLT
	movq	16(%r14), %rsi
	subq	%r12, %rsi
.L1305:
	movq	%r12, %rdi
	call	_ZdlPvm@PLT
	jmp	.L1306
	.p2align 4,,10
	.p2align 3
.L1329:
	movq	16(%r14), %rsi
	subq	%r12, %rsi
	jmp	.L1305
.L1328:
	leaq	.LC2(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE12276:
	.size	_ZNSt6vectorImSaImEE17_M_default_appendEm, .-_ZNSt6vectorImSaImEE17_M_default_appendEm
	.section	.text._ZNSt6vectorI5PointSaIS0_EE17_M_default_appendEm,"axG",@progbits,_ZNSt6vectorI5PointSaIS0_EE17_M_default_appendEm,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorI5PointSaIS0_EE17_M_default_appendEm
	.type	_ZNSt6vectorI5PointSaIS0_EE17_M_default_appendEm, @function
_ZNSt6vectorI5PointSaIS0_EE17_M_default_appendEm:
.LFB12447:
	.cfi_startproc
	endbr64
	testq	%rsi, %rsi
	je	.L1362
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rsi, %rbx
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	8(%rdi), %rdx
	movq	16(%rdi), %rax
	movq	(%rdi), %r14
	subq	%rdx, %rax
	sarq	$4, %rax
	cmpq	%rsi, %rax
	jnb	.L1366
	movabsq	$576460752303423487, %rax
	subq	%r14, %rdx
	movq	%rdx, %r12
	movq	%rdx, %r15
	sarq	$4, %r12
	subq	%r12, %rax
	cmpq	%rsi, %rax
	jb	.L1367
	leaq	(%rsi,%r12), %rax
	leaq	-1(%rsi), %r13
	movq	%rax, (%rsp)
	cmpq	%rsi, %r12
	jb	.L1336
	movabsq	$576460752303423487, %rax
	addq	%r12, %r12
	cmpq	%rax, %r12
	cmova	%rax, %r12
	salq	$4, %r12
	movq	%r12, %rdi
	call	_Znwm@PLT
	pxor	%xmm0, %xmm0
	leaq	(%rax,%r15), %rdx
	movq	%rax, %r8
	movups	%xmm0, (%rdx)
	cmpq	$1, %rbx
	je	.L1337
.L1365:
	leaq	16(%rdx), %rax
	salq	$4, %r13
	addq	%rax, %r13
	.p2align 4,,10
	.p2align 3
.L1340:
	movdqu	(%rdx), %xmm2
	addq	$16, %rax
	movups	%xmm2, -16(%rax)
	cmpq	%rax, %r13
	jne	.L1340
.L1339:
	testq	%r15, %r15
	jne	.L1337
	testq	%r14, %r14
	jne	.L1368
.L1343:
	movq	(%rsp), %r14
	movq	%r8, 0(%rbp)
	salq	$4, %r14
	addq	%r8, %r14
	addq	%r12, %r8
	movq	%r14, 8(%rbp)
	movq	%r8, 16(%rbp)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1366:
	.cfi_restore_state
	pxor	%xmm0, %xmm0
	leaq	16(%rdx), %rcx
	movups	%xmm0, (%rdx)
	subq	$1, %rbx
	je	.L1333
	salq	$4, %rbx
	movq	%rcx, %rax
	addq	%rcx, %rbx
	.p2align 4,,10
	.p2align 3
.L1334:
	movdqu	(%rdx), %xmm1
	addq	$16, %rax
	movups	%xmm1, -16(%rax)
	cmpq	%rax, %rbx
	jne	.L1334
	subq	%rdx, %rbx
	leaq	-16(%rcx,%rbx), %rcx
.L1333:
	movq	%rcx, 8(%rbp)
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1362:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
	ret
	.p2align 4,,10
	.p2align 3
.L1336:
	.cfi_def_cfa_offset 80
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movabsq	$576460752303423487, %r12
	movq	(%rsp), %rax
	cmpq	%r12, %rax
	cmovbe	%rax, %r12
	salq	$4, %r12
	movq	%r12, %rdi
	call	_Znwm@PLT
	pxor	%xmm0, %xmm0
	leaq	(%rax,%r15), %rdx
	movq	%rax, %r8
	movups	%xmm0, (%rdx)
	testq	%r13, %r13
	jne	.L1365
	jmp	.L1339
	.p2align 4,,10
	.p2align 3
.L1337:
	movq	%r14, %rsi
	movq	%r8, %rdi
	movq	%r15, %rdx
	call	memmove@PLT
	movq	16(%rbp), %rsi
	movq	%rax, %r8
	subq	%r14, %rsi
.L1342:
	movq	%r14, %rdi
	movq	%r8, 8(%rsp)
	call	_ZdlPvm@PLT
	movq	8(%rsp), %r8
	jmp	.L1343
	.p2align 4,,10
	.p2align 3
.L1368:
	movq	16(%rbp), %rsi
	subq	%r14, %rsi
	jmp	.L1342
.L1367:
	leaq	.LC2(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE12447:
	.size	_ZNSt6vectorI5PointSaIS0_EE17_M_default_appendEm, .-_ZNSt6vectorI5PointSaIS0_EE17_M_default_appendEm
	.section	.text._ZNSt6vectorI4TypeSaIS0_EE17_M_realloc_insertIJS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_,"axG",@progbits,_ZNSt6vectorI4TypeSaIS0_EE17_M_realloc_insertIJS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorI4TypeSaIS0_EE17_M_realloc_insertIJS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_
	.type	_ZNSt6vectorI4TypeSaIS0_EE17_M_realloc_insertIJS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_, @function
_ZNSt6vectorI4TypeSaIS0_EE17_M_realloc_insertIJS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_:
.LFB12741:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rsi, %r15
	movabsq	$-6148914691236517205, %rsi
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	8(%rdi), %r13
	movq	(%rdi), %r12
	movq	%r13, %rax
	subq	%r12, %rax
	sarq	$4, %rax
	imulq	%rsi, %rax
	movabsq	$192153584101141162, %rsi
	cmpq	%rsi, %rax
	je	.L1394
	movq	%r15, %rsi
	movq	%rdi, %rbp
	movq	%rdx, %r14
	subq	%r12, %rsi
	cmpq	%r13, %r12
	je	.L1395
	leaq	(%rax,%rax), %rdi
	cmpq	%rax, %rdi
	jb	.L1383
	testq	%rdi, %rdi
	jne	.L1396
	movq	$0, 16(%rsp)
	movl	$48, %ebx
	movq	$0, 8(%rsp)
.L1375:
	movq	8(%rsp), %rcx
	movdqu	(%r14), %xmm4
	pxor	%xmm0, %xmm0
	movdqu	16(%r14), %xmm5
	movdqu	32(%r14), %xmm6
	movups	%xmm0, (%r14)
	leaq	(%rcx,%rsi), %rax
	movups	%xmm0, 16(%r14)
	movups	%xmm4, (%rax)
	movups	%xmm5, 16(%rax)
	movups	%xmm6, 32(%rax)
	movups	%xmm0, 32(%r14)
	cmpq	%r12, %r15
	je	.L1376
	movq	%r12, %rbx
	movq	%rcx, %r14
	jmp	.L1378
	.p2align 4,,10
	.p2align 3
.L1385:
	movq	%rdx, %r14
.L1378:
	movq	(%rbx), %rdx
	movq	%rdx, (%r14)
	movq	8(%rbx), %rdx
	movups	%xmm0, (%rbx)
	movq	%rdx, 8(%r14)
	movq	16(%rbx), %rdx
	movq	$0, 16(%rbx)
	movq	%rdx, 16(%r14)
	movq	24(%rbx), %rdx
	movq	%rdx, 24(%r14)
	movq	32(%rbx), %rdx
	movq	%rdx, 32(%r14)
	movq	40(%rbx), %rdx
	movq	%rdx, 40(%r14)
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L1377
	movq	16(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	pxor	%xmm0, %xmm0
.L1377:
	addq	$48, %rbx
	leaq	48(%r14), %rdx
	cmpq	%r15, %rbx
	jne	.L1385
	leaq	96(%r14), %rbx
.L1376:
	cmpq	%r13, %r15
	je	.L1379
	subq	%r15, %r13
	movq	%r15, %rax
	xorl	%ecx, %ecx
	movabsq	$768614336404564651, %rdx
	leaq	-48(%r13), %rsi
	shrq	$4, %rsi
	imulq	%rdx, %rsi
	movabsq	$1152921504606846975, %rdx
	andq	%rdx, %rsi
	movq	%rbx, %rdx
	addq	$1, %rsi
	.p2align 4,,10
	.p2align 3
.L1380:
	movdqu	(%rax), %xmm1
	addq	$1, %rcx
	addq	$48, %rax
	addq	$48, %rdx
	movdqu	-32(%rax), %xmm2
	movdqu	-16(%rax), %xmm3
	movups	%xmm1, -48(%rdx)
	movups	%xmm2, -32(%rdx)
	movups	%xmm3, -16(%rdx)
	cmpq	%rsi, %rcx
	jb	.L1380
	leaq	(%rsi,%rsi,2), %rax
	salq	$4, %rax
	addq	%rax, %rbx
.L1379:
	testq	%r12, %r12
	je	.L1381
	movq	16(%rbp), %rsi
	movq	%r12, %rdi
	subq	%r12, %rsi
	call	_ZdlPvm@PLT
.L1381:
	movq	8(%rsp), %rax
	movq	%rbx, 8(%rbp)
	movq	%rax, 0(%rbp)
	movq	16(%rsp), %rax
	movq	%rax, 16(%rbp)
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1383:
	.cfi_restore_state
	movabsq	$9223372036854775776, %rbx
.L1374:
	movq	%rbx, %rdi
	movq	%rsi, 24(%rsp)
	call	_Znwm@PLT
	movq	24(%rsp), %rsi
	leaq	(%rax,%rbx), %rcx
	movq	%rax, 8(%rsp)
	leaq	48(%rax), %rbx
	movq	%rcx, 16(%rsp)
	jmp	.L1375
	.p2align 4,,10
	.p2align 3
.L1395:
	addq	$1, %rax
	jc	.L1383
	movabsq	$192153584101141162, %rdi
	cmpq	%rdi, %rax
	cmova	%rdi, %rax
	leaq	(%rax,%rax,2), %rax
	salq	$4, %rax
	movq	%rax, %rbx
	jmp	.L1374
.L1396:
	movabsq	$192153584101141162, %rax
	cmpq	%rax, %rdi
	cmova	%rax, %rdi
	leaq	(%rdi,%rdi,2), %rax
	salq	$4, %rax
	movq	%rax, %rbx
	jmp	.L1374
.L1394:
	leaq	.LC0(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE12741:
	.size	_ZNSt6vectorI4TypeSaIS0_EE17_M_realloc_insertIJS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_, .-_ZNSt6vectorI4TypeSaIS0_EE17_M_realloc_insertIJS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_
	.section	.text._ZNSt6vectorISt4pairIiiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,"axG",@progbits,_ZNSt6vectorISt4pairIiiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorISt4pairIiiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.type	_ZNSt6vectorISt4pairIiiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, @function
_ZNSt6vectorISt4pairIiiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_:
.LFB12778:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdx, %rbx
	movabsq	$1152921504606846975, %rdx
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	8(%rdi), %r8
	movq	(%rdi), %r12
	movq	%r8, %rax
	subq	%r12, %rax
	sarq	$3, %rax
	cmpq	%rdx, %rax
	je	.L1419
	movq	%rsi, %rdx
	movq	%rdi, %r13
	movq	%rsi, %r14
	subq	%r12, %rdx
	cmpq	%r8, %r12
	je	.L1420
	leaq	(%rax,%rax), %rcx
	cmpq	%rax, %rcx
	jb	.L1411
	testq	%rcx, %rcx
	jne	.L1421
	movq	(%rbx), %rax
	xorl	%ebp, %ebp
	xorl	%r15d, %r15d
	movl	$8, %ebx
	movq	%rax, (%rdx)
	cmpq	%r12, %rsi
	je	.L1409
.L1404:
	movq	%r14, %rsi
	movq	%r15, %rax
	movq	%r12, %rdx
	subq	%r12, %rsi
	addq	%r15, %rsi
	.p2align 4,,10
	.p2align 3
.L1406:
	movq	(%rdx), %rcx
	addq	$8, %rax
	addq	$8, %rdx
	movq	%rcx, -8(%rax)
	cmpq	%rsi, %rax
	jne	.L1406
	leaq	8(%rax), %rbx
.L1405:
	cmpq	%r8, %r14
	je	.L1407
.L1409:
	subq	%r14, %r8
	movq	%rbx, %rdi
	movq	%r14, %rsi
	movq	%r8, %rdx
	movq	%r8, (%rsp)
	call	memcpy@PLT
	movq	(%rsp), %r8
	addq	%r8, %rbx
.L1407:
	testq	%r12, %r12
	je	.L1408
	movq	16(%r13), %rsi
	movq	%r12, %rdi
	subq	%r12, %rsi
	call	_ZdlPvm@PLT
.L1408:
	movq	%r15, 0(%r13)
	movq	%rbx, 8(%r13)
	movq	%rbp, 16(%r13)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1411:
	.cfi_restore_state
	movabsq	$9223372036854775800, %rbp
.L1402:
	movq	%rbp, %rdi
	movq	%r8, 8(%rsp)
	movq	%rdx, (%rsp)
	call	_Znwm@PLT
	movq	(%rsp), %rdx
	movq	8(%rsp), %r8
	movq	%rax, %r15
	addq	%rax, %rbp
	movq	(%rbx), %rax
	cmpq	%r12, %r14
	leaq	8(%r15), %rbx
	movq	%rax, (%r15,%rdx)
	jne	.L1404
	jmp	.L1405
	.p2align 4,,10
	.p2align 3
.L1420:
	addq	$1, %rax
	jc	.L1411
	movabsq	$1152921504606846975, %rcx
	cmpq	%rcx, %rax
	cmovbe	%rax, %rcx
	movq	%rcx, %rbp
	salq	$3, %rbp
	jmp	.L1402
.L1421:
	movabsq	$1152921504606846975, %rax
	cmpq	%rax, %rcx
	cmova	%rax, %rcx
	leaq	0(,%rcx,8), %rbp
	jmp	.L1402
.L1419:
	leaq	.LC0(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE12778:
	.size	_ZNSt6vectorISt4pairIiiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, .-_ZNSt6vectorISt4pairIiiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.section	.text._ZNK6Packer13forced_blanksERK7Variant,"axG",@progbits,_ZNK6Packer13forced_blanksERK7Variant,comdat
	.align 2
	.p2align 4
	.weak	_ZNK6Packer13forced_blanksERK7Variant
	.type	_ZNK6Packer13forced_blanksERK7Variant, @function
_ZNK6Packer13forced_blanksERK7Variant:
.LFB10013:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA10013
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	movq	%rsi, %r14
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$184, %rsp
	.cfi_def_cfa_offset 240
	movq	%fs:40, %rax
	movq	%rax, 168(%rsp)
	movl	116(%rdi), %eax
	leal	1(%rax), %ebx
	movl	120(%rdi), %eax
	movl	%eax, 40(%rsp)
	cmpl	96(%rdi), %ebx
	jne	.L1423
	addl	$1, 40(%rsp)
	xorl	%ebx, %ebx
.L1423:
	movl	$6, 72(%rsp)
	pxor	%xmm0, %xmm0
	xorl	%r12d, %r12d
	movq	$0, 128(%rsp)
	movq	$0, 8(%rsp)
	movaps	%xmm0, 112(%rsp)
.L1424:
	movl	108(%rbp), %eax
	movl	40(%rsp), %r8d
	movl	%eax, 16(%rsp)
	.p2align 4,,10
	.p2align 3
.L1428:
	cmpl	%r8d, 16(%rsp)
	jle	.L1457
.L1475:
	movl	100(%rbp), %r10d
	movl	%ebx, %edx
	movq	128(%rbp), %r13
	movl	%ebx, %ecx
	sarl	$6, %edx
	movl	116(%rbp), %esi
	movl	%r8d, %edi
	movl	8(%r14), %r11d
	movl	%r10d, %eax
	movl	%ebx, %r9d
	imull	%r8d, %eax
	subl	%esi, %r9d
	addl	%edx, %eax
	cltq
	movq	0(%r13,%rax,8), %rdx
	movslq	120(%rbp), %rax
	shrq	%cl, %rdx
	subl	%eax, %edi
	andl	$1, %edx
	cmpl	%edi, %r11d
	jle	.L1426
	leal	9(%r9), %ecx
	cmpl	$18, %ecx
	ja	.L1426
	movslq	%edi, %r15
	movl	48(%r14,%r15,4), %r15d
	shrl	%cl, %r15d
	orl	%edx, %r15d
	movl	%r15d, %edx
	andl	$1, %edx
.L1426:
	testb	%dl, %dl
	je	.L1427
	addl	$1, %ebx
	cmpl	96(%rbp), %ebx
	jne	.L1428
	addl	$1, %r8d
	xorl	%ebx, %ebx
	cmpl	%r8d, 16(%rsp)
	jg	.L1475
.L1457:
	movl	$6, %ebx
.L1452:
	movq	8(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L1422
	movq	%r12, %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L1422:
	movq	168(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1473
	addq	$184, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1427:
	.cfi_restore_state
	movl	%r9d, 68(%rsp)
	leal	-9(%rbx), %r9d
	subl	%ebx, %esi
	pxor	%xmm0, %xmm0
	movl	%r9d, %ecx
	movl	%r8d, 40(%rsp)
	sarl	$6, %ecx
	movl	%esi, 52(%rsp)
	leal	1(%rcx), %edx
	movl	%ecx, %r8d
	movl	%ecx, 56(%rsp)
	movl	%edx, 76(%rsp)
	movl	$9, %edx
	subl	%ebx, %edx
	movl	%r9d, 28(%rsp)
	andl	$63, %r9d
	movl	%edx, %r15d
	movl	%edx, 60(%rsp)
	movl	$1, %edx
	movl	%r15d, %ecx
	movl	%r11d, 24(%rsp)
	movq	120(%rsp), %r15
	sall	%cl, %edx
	movl	40(%rsp), %ecx
	movq	%r12, 80(%rsp)
	subl	$1, %edx
	movq	%r14, 88(%rsp)
	movl	%edx, 64(%rsp)
	movl	%ecx, %edx
	movl	%ecx, %esi
	imull	%r10d, %edx
	movl	%r9d, 48(%rsp)
	movq	$0, 160(%rsp)
	movl	%r10d, 20(%rsp)
	leal	1(%r8,%rdx), %edx
	movaps	%xmm0, 144(%rsp)
	xorl	%r8d, %r8d
	movl	%edx, 32(%rsp)
	movslq	%ecx, %rdx
	movl	32(%rsp), %r11d
	subq	%rax, %rdx
	movl	52(%rsp), %eax
	movq	%r13, 32(%rsp)
	leaq	48(%r14,%rdx,4), %rcx
	xorl	%edx, %edx
	addl	$18, %eax
	movq	%rcx, %r12
	movq	%rdx, %r14
	movl	%eax, 44(%rsp)
	testl	%esi, %esi
	js	.L1458
	.p2align 4,,10
	.p2align 3
.L1479:
	cmpl	%esi, 16(%rsp)
	jle	.L1458
	xorl	%eax, %eax
	cmpl	%esi, 104(%rbp)
	jle	.L1430
	movl	28(%rsp), %eax
	testl	%eax, %eax
	js	.L1476
	movq	32(%rsp), %r9
	leal	-1(%r11), %eax
	movl	48(%rsp), %r10d
	cltq
	movq	(%r9,%rax,8), %rax
	movl	%r10d, %ecx
	shrq	%cl, %rax
	cmpl	$45, %r10d
	jle	.L1432
	movl	76(%rsp), %edx
	cmpl	%edx, 20(%rsp)
	jg	.L1477
	.p2align 4,,10
	.p2align 3
.L1432:
	movl	96(%rbp), %ecx
	movl	28(%rsp), %edx
	subl	%edx, %ecx
	cmpl	$18, %ecx
	jg	.L1434
	movl	$1, %edx
	sall	%cl, %edx
	subl	$1, %edx
	xorl	$524287, %edx
	orl	%edx, %eax
.L1434:
	andl	$524287, %eax
.L1430:
	cmpl	%edi, 24(%rsp)
	jle	.L1435
	testl	%edi, %edi
	jns	.L1478
.L1435:
	movq	8(%rsp), %rcx
	cmpq	%rcx, %r15
	je	.L1438
	movq	%rcx, %rdx
	movl	%eax, %r9d
	.p2align 4,,10
	.p2align 3
.L1440:
	cmpl	%esi, 4(%rdx)
	jne	.L1439
	movl	(%rdx), %ecx
	movl	$1, %eax
	movl	%r9d, %r10d
	subl	%ebx, %ecx
	addl	$9, %ecx
	sall	%cl, %eax
	orl	%r9d, %eax
	cmpl	$19, %ecx
	cmovb	%eax, %r10d
	movl	%r10d, %r9d
.L1439:
	addq	$8, %rdx
	cmpq	%r15, %rdx
	jne	.L1440
	movl	%r9d, %eax
.L1438:
	andl	$524287, %eax
	movl	%r8d, %r9d
	movl	%r8d, %ecx
	movl	%r8d, %r10d
	movl	%eax, %edx
	sarl	$6, %r9d
	andl	$63, %r10d
	salq	%cl, %rdx
	movslq	%r9d, %r13
	orq	%r14, %rdx
	movq	%rdx, 144(%rsp,%r13,8)
	cmpl	$45, %r10d
	jle	.L1441
	addl	$1, %r9d
	movl	$64, %ecx
	movslq	%r9d, %r9
	subl	%r10d, %ecx
	shrl	%cl, %eax
	orq	%rax, 144(%rsp,%r9,8)
.L1441:
	movl	20(%rsp), %eax
	addl	$19, %r8d
	addl	$1, %esi
	addl	$1, %edi
	addq	$4, %r12
	addl	%eax, %r11d
	cmpl	$190, %r8d
	je	.L1442
	movl	%r8d, %eax
	sarl	$6, %eax
	cltq
	movq	144(%rsp,%rax,8), %r14
	testl	%esi, %esi
	jns	.L1479
.L1458:
	movl	$524287, %eax
	jmp	.L1430
	.p2align 4,,10
	.p2align 3
.L1478:
	cmpl	$36, 44(%rsp)
	ja	.L1435
	movl	(%r12), %edx
	movl	52(%rsp), %r10d
	movl	%edx, %r9d
	movl	%r10d, %ecx
	sall	%cl, %r9d
	movzbl	68(%rsp), %ecx
	shrl	%cl, %edx
	testl	%r10d, %r10d
	cmovns	%r9d, %edx
	orl	%edx, %eax
	jmp	.L1435
	.p2align 4,,10
	.p2align 3
.L1476:
	movl	56(%rsp), %ecx
	movl	%r11d, %eax
	subl	%ecx, %eax
	movq	32(%rsp), %rcx
	subl	$1, %eax
	cltq
	movq	(%rcx,%rax,8), %rax
	movzbl	60(%rsp), %ecx
	salq	%cl, %rax
	movl	64(%rsp), %ecx
	orl	%ecx, %eax
	jmp	.L1432
.L1442:
	movq	24(%rbp), %rdx
	movq	32(%rbp), %rdi
	movq	80(%rsp), %r12
	movq	88(%rsp), %r14
	cmpq	%rdi, %rdx
	je	.L1444
	movq	16(%rbp), %rax
	movslq	(%r14), %r11
	movq	144(%rsp), %r9
	movq	152(%rsp), %r10
	movq	(%rax), %r8
	movq	160(%rsp), %r13
	movq	%r11, %rsi
	jmp	.L1447
	.p2align 4,,10
	.p2align 3
.L1445:
	movq	%r9, %rcx
	andq	24(%rax), %rcx
	jne	.L1446
	movq	%r10, %rcx
	andq	32(%rax), %rcx
	jne	.L1446
	movq	%r13, %rcx
	andq	40(%rax), %rcx
	je	.L1480
.L1446:
	addq	$4, %rdx
	cmpq	%rdx, %rdi
	je	.L1444
.L1447:
	movslq	(%rdx), %rax
	leaq	(%rax,%rax,8), %rax
	salq	$4, %rax
	addq	%r8, %rax
	cmpl	%esi, (%rax)
	jne	.L1445
	movq	48(%rbp), %rcx
	cmpl	$1, (%rcx,%r11,4)
	jg	.L1445
	addq	$4, %rdx
	cmpq	%rdx, %rdi
	jne	.L1447
.L1444:
	movl	40(%rsp), %eax
	movl	%ebx, 104(%rsp)
	movl	%eax, 108(%rsp)
	cmpq	%r12, %r15
	je	.L1448
	movq	104(%rsp), %rax
	movq	%rax, (%r15)
	leaq	8(%r15), %rax
	movq	%rax, 120(%rsp)
.L1449:
	addl	$1, %ebx
	cmpl	96(%rbp), %ebx
	jne	.L1450
	addl	$1, 40(%rsp)
	xorl	%ebx, %ebx
.L1450:
	subl	$1, 72(%rsp)
	jne	.L1424
	movq	120(%rsp), %rbx
	movq	8(%rsp), %rax
	subq	%rax, %rbx
	sarq	$3, %rbx
	jmp	.L1452
.L1477:
	movslq	%r11d, %rdx
	movl	$64, %ecx
	movq	(%r9,%rdx,8), %rdx
	subl	%r10d, %ecx
	salq	%cl, %rdx
	orq	%rdx, %rax
	jmp	.L1432
.L1448:
	leaq	112(%rsp), %r13
	leaq	104(%rsp), %rdx
	movq	%r15, %rsi
	movq	%r13, %rdi
.LEHB23:
	call	_ZNSt6vectorISt4pairIiiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
.LEHE23:
	movq	112(%rsp), %rax
	movq	128(%rsp), %r12
	movq	%rax, 8(%rsp)
	jmp	.L1449
.L1480:
	movq	8(%rsp), %rax
	movq	%r15, %rbx
	subq	%rax, %rbx
	sarq	$3, %rbx
	jmp	.L1452
.L1454:
	movq	%r13, %rdi
	call	_ZNSt6vectorISt4pairIiiESaIS1_EED1Ev
	movq	168(%rsp), %rax
	subq	%fs:40, %rax
	je	.L1455
.L1473:
	call	__stack_chk_fail@PLT
.L1460:
	endbr64
	movq	%rax, %rbx
	jmp	.L1454
.L1455:
	movq	%rbx, %rdi
.LEHB24:
	call	_Unwind_Resume@PLT
.LEHE24:
	.cfi_endproc
.LFE10013:
	.section	.gcc_except_table._ZNK6Packer13forced_blanksERK7Variant,"aG",@progbits,_ZNK6Packer13forced_blanksERK7Variant,comdat
.LLSDA10013:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE10013-.LLSDACSB10013
.LLSDACSB10013:
	.uleb128 .LEHB23-.LFB10013
	.uleb128 .LEHE23-.LEHB23
	.uleb128 .L1460-.LFB10013
	.uleb128 0
	.uleb128 .LEHB24-.LFB10013
	.uleb128 .LEHE24-.LEHB24
	.uleb128 0
	.uleb128 0
.LLSDACSE10013:
	.section	.text._ZNK6Packer13forced_blanksERK7Variant,"axG",@progbits,_ZNK6Packer13forced_blanksERK7Variant,comdat
	.size	_ZNK6Packer13forced_blanksERK7Variant, .-_ZNK6Packer13forced_blanksERK7Variant
	.section	.text._ZNSt6vectorI7VariantSaIS0_EE17_M_realloc_insertIJS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_,"axG",@progbits,_ZNSt6vectorI7VariantSaIS0_EE17_M_realloc_insertIJS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorI7VariantSaIS0_EE17_M_realloc_insertIJS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_
	.type	_ZNSt6vectorI7VariantSaIS0_EE17_M_realloc_insertIJS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_, @function
_ZNSt6vectorI7VariantSaIS0_EE17_M_realloc_insertIJS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_:
.LFB12788:
	.cfi_startproc
	endbr64
	movabsq	$-8198552921648689607, %rcx
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rdx, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	8(%rdi), %r13
	movq	(%rdi), %rdx
	movq	%r13, %rax
	subq	%rdx, %rax
	sarq	$4, %rax
	imulq	%rcx, %rax
	movabsq	$64051194700380387, %rcx
	cmpq	%rcx, %rax
	je	.L1545
	movq	%rsi, %r12
	movq	%rdi, %r15
	subq	%rdx, %rsi
	cmpq	%r13, %rdx
	je	.L1546
	leaq	(%rax,%rax), %rcx
	cmpq	%rax, %rcx
	jb	.L1519
	testq	%rcx, %rcx
	jne	.L1547
	movl	$144, %ebx
	xorl	%r14d, %r14d
	xorl	%ecx, %ecx
.L1487:
	leaq	(%rcx,%rsi), %rax
	movq	16(%rbp), %rsi
	movdqu	0(%rbp), %xmm4
	pxor	%xmm0, %xmm0
	movdqu	24(%rbp), %xmm5
	movdqu	48(%rbp), %xmm6
	leaq	128(%rax), %r9
	movdqu	64(%rbp), %xmm7
	movq	112(%rbp), %r8
	movq	%rsi, 16(%rax)
	movq	40(%rbp), %rsi
	movups	%xmm4, (%rax)
	movdqu	88(%rbp), %xmm4
	movq	%r9, 112(%rax)
	movq	120(%rbp), %rdi
	movq	%rsi, 40(%rax)
	movq	80(%rbp), %rsi
	movups	%xmm5, 24(%rax)
	movq	%rsi, 80(%rax)
	movq	104(%rbp), %rsi
	movups	%xmm6, 48(%rax)
	movq	%rsi, 104(%rax)
	leaq	128(%rbp), %rsi
	movq	$0, 104(%rbp)
	movups	%xmm7, 64(%rax)
	movups	%xmm4, 88(%rax)
	movups	%xmm0, 88(%rbp)
	cmpq	%rsi, %r8
	je	.L1548
	movq	%r8, 112(%rax)
	movq	128(%rbp), %r8
	movq	%r8, 128(%rax)
.L1495:
	movq	%rdi, 120(%rax)
	movq	%rsi, 112(%rbp)
	movq	$0, 120(%rbp)
	movb	$0, 128(%rbp)
	cmpq	%rdx, %r12
	je	.L1496
	movq	%rcx, (%rsp)
	movq	%rdx, %rbp
	movq	%rcx, %rbx
	pxor	%xmm0, %xmm0
	movq	%rdx, 8(%rsp)
	jmp	.L1506
	.p2align 4,,10
	.p2align 3
.L1497:
	movq	%rdx, 112(%rbx)
	movq	128(%rbp), %rdx
	movq	%rdx, 128(%rbx)
.L1544:
	movq	120(%rbp), %rsi
.L1504:
	movq	88(%rbp), %rdi
	movq	%rsi, 120(%rbx)
	testq	%rdi, %rdi
	je	.L1505
	movq	104(%rbp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	pxor	%xmm0, %xmm0
.L1505:
	addq	$144, %rbp
	leaq	144(%rbx), %rdx
	cmpq	%r12, %rbp
	je	.L1549
	movq	%rdx, %rbx
.L1506:
	movq	16(%rbp), %rdx
	movdqu	0(%rbp), %xmm1
	leaq	128(%rbx), %rcx
	leaq	128(%rbp), %rsi
	movdqu	24(%rbp), %xmm2
	movdqu	48(%rbp), %xmm3
	movq	%rdx, 16(%rbx)
	movq	40(%rbp), %rdx
	movdqu	64(%rbp), %xmm4
	movups	%xmm1, (%rbx)
	movq	%rdx, 40(%rbx)
	movq	80(%rbp), %rdx
	movups	%xmm2, 24(%rbx)
	movq	%rdx, 80(%rbx)
	movq	104(%rbp), %rdx
	movups	%xmm3, 48(%rbx)
	movups	%xmm4, 64(%rbx)
	movdqu	88(%rbp), %xmm5
	movq	%rdx, 104(%rbx)
	movq	$0, 104(%rbp)
	movups	%xmm0, 88(%rbp)
	movq	%rcx, 112(%rbx)
	movq	112(%rbp), %rdx
	movups	%xmm5, 88(%rbx)
	cmpq	%rsi, %rdx
	jne	.L1497
	movq	120(%rbp), %rsi
	leaq	1(%rsi), %rdi
	cmpl	$8, %edi
	jnb	.L1498
	testb	$4, %dil
	jne	.L1550
	testl	%edi, %edi
	je	.L1504
	movzbl	(%rdx), %esi
	movb	%sil, (%rcx)
	testb	$2, %dil
	je	.L1544
	movl	%edi, %edi
	movzwl	-2(%rdx,%rdi), %edx
	movw	%dx, -2(%rcx,%rdi)
	movq	120(%rbp), %rsi
	jmp	.L1504
	.p2align 4,,10
	.p2align 3
.L1519:
	movabsq	$9223372036854775728, %r14
.L1486:
	movq	%r14, %rdi
	movq	%rsi, 8(%rsp)
	movq	%rdx, (%rsp)
	call	_Znwm@PLT
	movq	(%rsp), %rdx
	movq	8(%rsp), %rsi
	movq	%rax, %rcx
	addq	%rax, %r14
	leaq	144(%rax), %rbx
	jmp	.L1487
	.p2align 4,,10
	.p2align 3
.L1549:
	movq	(%rsp), %rcx
	movq	8(%rsp), %rdx
	addq	$288, %rbx
.L1496:
	cmpq	%r13, %r12
	je	.L1507
	movq	%r12, %rax
	movq	%rbx, %rsi
	pxor	%xmm0, %xmm0
	jmp	.L1516
	.p2align 4,,10
	.p2align 3
.L1508:
	movq	%rdi, 112(%rsi)
	movq	128(%rax), %rdi
	movq	%rdi, 128(%rsi)
.L1515:
	addq	$144, %rax
	movq	%r8, 120(%rsi)
	addq	$144, %rsi
	cmpq	%r13, %rax
	je	.L1551
.L1516:
	movq	16(%rax), %rdi
	movdqu	(%rax), %xmm6
	leaq	128(%rsi), %r10
	leaq	128(%rax), %r9
	movdqu	88(%rax), %xmm3
	movdqu	24(%rax), %xmm7
	movq	%r10, 112(%rsi)
	movdqu	48(%rax), %xmm1
	movdqu	64(%rax), %xmm2
	movq	%rdi, 16(%rsi)
	movq	40(%rax), %rdi
	movq	120(%rax), %r8
	movups	%xmm6, (%rsi)
	movups	%xmm7, 24(%rsi)
	movq	%rdi, 40(%rsi)
	movq	80(%rax), %rdi
	movups	%xmm1, 48(%rsi)
	movq	%rdi, 80(%rsi)
	movq	104(%rax), %rdi
	movups	%xmm2, 64(%rsi)
	movq	%rdi, 104(%rsi)
	movq	112(%rax), %rdi
	movq	$0, 104(%rax)
	movups	%xmm3, 88(%rsi)
	movups	%xmm0, 88(%rax)
	cmpq	%r9, %rdi
	jne	.L1508
	leaq	1(%r8), %r9
	cmpl	$8, %r9d
	jnb	.L1509
	testb	$4, %r9b
	jne	.L1552
	testl	%r9d, %r9d
	je	.L1515
	movzbl	(%rdi), %r11d
	movb	%r11b, (%r10)
	testb	$2, %r9b
	je	.L1515
	movl	%r9d, %r9d
	movzwl	-2(%rdi,%r9), %edi
	movw	%di, -2(%r10,%r9)
	jmp	.L1515
	.p2align 4,,10
	.p2align 3
.L1551:
	movabsq	$1024819115206086201, %rsi
	subq	%r12, %rax
	subq	$144, %rax
	shrq	$4, %rax
	imulq	%rsi, %rax
	movabsq	$1152921504606846975, %rsi
	andq	%rsi, %rax
	leaq	9(%rax,%rax,8), %rax
	salq	$4, %rax
	addq	%rax, %rbx
.L1507:
	testq	%rdx, %rdx
	je	.L1517
	movq	16(%r15), %rsi
	movq	%rdx, %rdi
	movq	%rcx, (%rsp)
	subq	%rdx, %rsi
	call	_ZdlPvm@PLT
	movq	(%rsp), %rcx
.L1517:
	movq	%rcx, (%r15)
	movq	%rbx, 8(%r15)
	movq	%r14, 16(%r15)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1509:
	.cfi_restore_state
	movq	(%rdi), %r11
	movq	%r11, (%r10)
	movl	%r9d, %r11d
	movq	-8(%rdi,%r11), %rbp
	movq	%rbp, -8(%r10,%r11)
	leaq	136(%rsi), %rbp
	andq	$-8, %rbp
	subq	%rbp, %r10
	addl	%r10d, %r9d
	subq	%r10, %rdi
	andl	$-8, %r9d
	cmpl	$8, %r9d
	jb	.L1515
	movq	%rax, (%rsp)
	andl	$-8, %r9d
	xorl	%r10d, %r10d
.L1513:
	movl	%r10d, %r11d
	addl	$8, %r10d
	movq	(%rdi,%r11), %rax
	movq	%rax, 0(%rbp,%r11)
	cmpl	%r9d, %r10d
	jb	.L1513
	movq	(%rsp), %rax
	jmp	.L1515
	.p2align 4,,10
	.p2align 3
.L1498:
	movq	(%rdx), %rsi
	movq	%rsi, (%rcx)
	movl	%edi, %esi
	movq	-8(%rdx,%rsi), %r9
	movq	%r9, -8(%rcx,%rsi)
	leaq	136(%rbx), %rsi
	andq	$-8, %rsi
	subq	%rsi, %rcx
	addl	%ecx, %edi
	subq	%rcx, %rdx
	andl	$-8, %edi
	cmpl	$8, %edi
	jb	.L1544
	andl	$-8, %edi
	xorl	%ecx, %ecx
.L1502:
	movl	%ecx, %r9d
	addl	$8, %ecx
	movq	(%rdx,%r9), %r10
	movq	%r10, (%rsi,%r9)
	cmpl	%edi, %ecx
	jb	.L1502
	jmp	.L1544
	.p2align 4,,10
	.p2align 3
.L1546:
	addq	$1, %rax
	jc	.L1519
	movabsq	$64051194700380387, %rcx
	cmpq	%rcx, %rax
	cmova	%rcx, %rax
	leaq	(%rax,%rax,8), %r14
	salq	$4, %r14
	jmp	.L1486
	.p2align 4,,10
	.p2align 3
.L1548:
	leaq	1(%rdi), %r8
	cmpl	$8, %r8d
	jnb	.L1489
	testb	$4, %r8b
	jne	.L1553
	testl	%r8d, %r8d
	je	.L1495
	movzbl	128(%rbp), %r10d
	movb	%r10b, 128(%rax)
	testb	$2, %r8b
	je	.L1495
	movl	%r8d, %r8d
	movzwl	-2(%rsi,%r8), %r10d
	movw	%r10w, -2(%r9,%r8)
	jmp	.L1495
	.p2align 4,,10
	.p2align 3
.L1489:
	movq	128(%rbp), %r10
	movq	%r10, 128(%rax)
	movl	%r8d, %r10d
	movq	-8(%rsi,%r10), %r11
	movq	%r11, -8(%r9,%r10)
	leaq	136(%rax), %r10
	movq	%rsi, %r11
	andq	$-8, %r10
	subq	%r10, %r9
	addl	%r9d, %r8d
	subq	%r9, %r11
	andl	$-8, %r8d
	cmpl	$8, %r8d
	jb	.L1495
	movq	%rdx, 8(%rsp)
	andl	$-8, %r8d
	movq	%rax, %r9
	movl	%r8d, (%rsp)
	xorl	%r8d, %r8d
.L1493:
	movl	%r8d, %eax
	addl	$8, %r8d
	movq	(%r11,%rax), %rdx
	movq	%rdx, (%r10,%rax)
	movl	(%rsp), %eax
	cmpl	%eax, %r8d
	jb	.L1493
	movq	8(%rsp), %rdx
	movq	%r9, %rax
	jmp	.L1495
.L1552:
	movl	(%rdi), %r11d
	movl	%r9d, %r9d
	movl	%r11d, (%r10)
	movl	-4(%rdi,%r9), %edi
	movl	%edi, -4(%r10,%r9)
	jmp	.L1515
.L1550:
	movl	(%rdx), %esi
	movl	%edi, %edi
	movl	%esi, (%rcx)
	movl	-4(%rdx,%rdi), %edx
	movl	%edx, -4(%rcx,%rdi)
	movq	120(%rbp), %rsi
	jmp	.L1504
.L1553:
	movl	128(%rbp), %r10d
	movl	%r8d, %r8d
	movl	%r10d, 128(%rax)
	movl	-4(%rsi,%r8), %r10d
	movl	%r10d, -4(%r9,%r8)
	jmp	.L1495
.L1547:
	movabsq	$64051194700380387, %rax
	cmpq	%rax, %rcx
	cmova	%rax, %rcx
	leaq	(%rcx,%rcx,8), %r14
	salq	$4, %r14
	jmp	.L1486
.L1545:
	leaq	.LC0(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE12788:
	.size	_ZNSt6vectorI7VariantSaIS0_EE17_M_realloc_insertIJS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_, .-_ZNSt6vectorI7VariantSaIS0_EE17_M_realloc_insertIJS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_
	.section	.text._ZNSt6vectorISt4pairIiyESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,"axG",@progbits,_ZNSt6vectorISt4pairIiyESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorISt4pairIiyESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.type	_ZNSt6vectorISt4pairIiyESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, @function
_ZNSt6vectorISt4pairIiyESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_:
.LFB12801:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdx, %rbx
	movabsq	$576460752303423487, %rdx
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	8(%rdi), %r15
	movq	(%rdi), %r12
	movq	%r15, %rax
	subq	%r12, %rax
	sarq	$4, %rax
	cmpq	%rdx, %rax
	je	.L1576
	movq	%rsi, %rdx
	movq	%rdi, %r13
	movq	%rsi, %r14
	subq	%r12, %rdx
	cmpq	%r15, %r12
	je	.L1577
	leaq	(%rax,%rax), %rcx
	cmpq	%rax, %rcx
	jb	.L1568
	testq	%rcx, %rcx
	jne	.L1578
	movdqu	(%rbx), %xmm2
	xorl	%ebp, %ebp
	xorl	%r8d, %r8d
	movl	$16, %ebx
	movups	%xmm2, (%rdx)
	cmpq	%r12, %rsi
	je	.L1566
.L1561:
	movq	%r14, %rcx
	movq	%r8, %rax
	movq	%r12, %rdx
	subq	%r12, %rcx
	addq	%r8, %rcx
	.p2align 4,,10
	.p2align 3
.L1563:
	movdqu	(%rdx), %xmm0
	addq	$16, %rax
	addq	$16, %rdx
	movups	%xmm0, -16(%rax)
	cmpq	%rcx, %rax
	jne	.L1563
	leaq	16(%rax), %rbx
.L1562:
	cmpq	%r15, %r14
	je	.L1564
.L1566:
	subq	%r14, %r15
	movq	%rbx, %rdi
	movq	%r14, %rsi
	movq	%r8, 8(%rsp)
	movq	%r15, %rdx
	addq	%r15, %rbx
	call	memcpy@PLT
	movq	8(%rsp), %r8
.L1564:
	testq	%r12, %r12
	je	.L1565
	movq	16(%r13), %rsi
	movq	%r12, %rdi
	movq	%r8, 8(%rsp)
	subq	%r12, %rsi
	call	_ZdlPvm@PLT
	movq	8(%rsp), %r8
.L1565:
	movq	%r8, 0(%r13)
	movq	%rbx, 8(%r13)
	movq	%rbp, 16(%r13)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1568:
	.cfi_restore_state
	movabsq	$9223372036854775792, %rbp
.L1559:
	movq	%rbp, %rdi
	movq	%rdx, 8(%rsp)
	call	_Znwm@PLT
	movdqu	(%rbx), %xmm1
	movq	8(%rsp), %rdx
	movq	%rax, %r8
	addq	%rax, %rbp
	leaq	16(%rax), %rbx
	movups	%xmm1, (%rax,%rdx)
	cmpq	%r12, %r14
	jne	.L1561
	jmp	.L1562
	.p2align 4,,10
	.p2align 3
.L1577:
	addq	$1, %rax
	jc	.L1568
	movabsq	$576460752303423487, %rcx
	cmpq	%rcx, %rax
	cmovbe	%rax, %rcx
	movq	%rcx, %rbp
	salq	$4, %rbp
	jmp	.L1559
.L1578:
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %rcx
	cmova	%rax, %rcx
	salq	$4, %rcx
	movq	%rcx, %rbp
	jmp	.L1559
.L1576:
	leaq	.LC0(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE12801:
	.size	_ZNSt6vectorISt4pairIiyESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, .-_ZNSt6vectorISt4pairIiyESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.section	.text._ZNSt6vectorISt4pairIdiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,"axG",@progbits,_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.type	_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, @function
_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_:
.LFB12814:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdx, %rbx
	movabsq	$576460752303423487, %rdx
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	8(%rdi), %r15
	movq	(%rdi), %r12
	movq	%r15, %rax
	subq	%r12, %rax
	sarq	$4, %rax
	cmpq	%rdx, %rax
	je	.L1601
	movq	%rsi, %rdx
	movq	%rdi, %r13
	movq	%rsi, %r14
	subq	%r12, %rdx
	cmpq	%r15, %r12
	je	.L1602
	leaq	(%rax,%rax), %rcx
	cmpq	%rax, %rcx
	jb	.L1593
	testq	%rcx, %rcx
	jne	.L1603
	movdqu	(%rbx), %xmm2
	xorl	%ebp, %ebp
	xorl	%r8d, %r8d
	movl	$16, %ebx
	movups	%xmm2, (%rdx)
	cmpq	%r12, %rsi
	je	.L1591
.L1586:
	movq	%r14, %rcx
	movq	%r8, %rax
	movq	%r12, %rdx
	subq	%r12, %rcx
	addq	%r8, %rcx
	.p2align 4,,10
	.p2align 3
.L1588:
	movdqu	(%rdx), %xmm0
	addq	$16, %rax
	addq	$16, %rdx
	movups	%xmm0, -16(%rax)
	cmpq	%rcx, %rax
	jne	.L1588
	leaq	16(%rax), %rbx
.L1587:
	cmpq	%r15, %r14
	je	.L1589
.L1591:
	subq	%r14, %r15
	movq	%rbx, %rdi
	movq	%r14, %rsi
	movq	%r8, 8(%rsp)
	movq	%r15, %rdx
	addq	%r15, %rbx
	call	memcpy@PLT
	movq	8(%rsp), %r8
.L1589:
	testq	%r12, %r12
	je	.L1590
	movq	16(%r13), %rsi
	movq	%r12, %rdi
	movq	%r8, 8(%rsp)
	subq	%r12, %rsi
	call	_ZdlPvm@PLT
	movq	8(%rsp), %r8
.L1590:
	movq	%r8, 0(%r13)
	movq	%rbx, 8(%r13)
	movq	%rbp, 16(%r13)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1593:
	.cfi_restore_state
	movabsq	$9223372036854775792, %rbp
.L1584:
	movq	%rbp, %rdi
	movq	%rdx, 8(%rsp)
	call	_Znwm@PLT
	movdqu	(%rbx), %xmm1
	movq	8(%rsp), %rdx
	movq	%rax, %r8
	addq	%rax, %rbp
	leaq	16(%rax), %rbx
	movups	%xmm1, (%rax,%rdx)
	cmpq	%r12, %r14
	jne	.L1586
	jmp	.L1587
	.p2align 4,,10
	.p2align 3
.L1602:
	addq	$1, %rax
	jc	.L1593
	movabsq	$576460752303423487, %rcx
	cmpq	%rcx, %rax
	cmovbe	%rax, %rcx
	movq	%rcx, %rbp
	salq	$4, %rbp
	jmp	.L1584
.L1603:
	movabsq	$576460752303423487, %rax
	cmpq	%rax, %rcx
	cmova	%rax, %rcx
	salq	$4, %rcx
	movq	%rcx, %rbp
	jmp	.L1584
.L1601:
	leaq	.LC0(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE12814:
	.size	_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, .-_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.section	.text._ZN10BeamPacker7optionsERNS_5StateE,"axG",@progbits,_ZN10BeamPacker7optionsERNS_5StateE,comdat
	.align 2
	.p2align 4
	.weak	_ZN10BeamPacker7optionsERNS_5StateE
	.type	_ZN10BeamPacker7optionsERNS_5StateE, @function
_ZN10BeamPacker7optionsERNS_5StateE:
.LFB10124:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA10124
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$392, %rsp
	.cfi_def_cfa_offset 448
	movl	80(%rdx), %r11d
	movq	%rdi, 120(%rsp)
	movl	12(%rsi), %edi
	movq	%rsi, 8(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 376(%rsp)
	xorl	%eax, %eax
	cmpl	%edi, %r11d
	jge	.L1654
	movq	%rdx, %r12
.L1605:
	movslq	%r11d, %rcx
	salq	$3, %rcx
	jmp	.L1610
	.p2align 4,,10
	.p2align 3
.L1691:
	movq	8(%r12), %rbx
	movq	(%r12), %r9
	movl	76(%r12), %eax
	movq	%rbx, %rsi
	subq	%r9, %rsi
	sarq	$3, %rsi
	movl	%esi, %r15d
	cmpl	%r11d, %esi
	jle	.L1608
	movq	(%r9,%rcx), %rdx
	btq	%rax, %rdx
	jnc	.L1608
	movq	8(%rsp), %rbx
	addl	$1, %eax
	movl	%eax, 76(%r12)
	cmpl	8(%rbx), %eax
	je	.L1690
.L1610:
	cmpl	%r11d, %edi
	jg	.L1691
.L1654:
	movq	120(%rsp), %rax
	pxor	%xmm0, %xmm0
	movq	$0, 16(%rax)
	movups	%xmm0, (%rax)
.L1604:
	movq	376(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1689
	movq	120(%rsp), %rax
	addq	$392, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1608:
	.cfi_restore_state
	movq	8(%rsp), %r10
	leal	-9(%rax), %edi
	movl	$9, %edx
	movq	$0, 208(%rsp)
	subl	%eax, %edx
	movl	$1, %eax
	pxor	%xmm0, %xmm0
	movl	%edi, 24(%rsp)
	movl	12(%r10), %ecx
	movl	%edx, 32(%rsp)
	movl	$-19, %r8d
	movaps	%xmm0, 320(%rsp)
	movl	%ecx, 16(%rsp)
	movl	%edx, %ecx
	movl	%eax, %edx
	sall	%cl, %edx
	movaps	%xmm0, 336(%rsp)
	leal	-1(%rdx), %ecx
	movaps	%xmm0, 352(%rsp)
	leal	-1(%r11), %edx
	movq	%rcx, 40(%rsp)
	movl	8(%r10), %ecx
	movaps	%xmm0, 192(%rsp)
	subl	%edi, %ecx
	xorl	%edi, %edi
	sall	%cl, %eax
	movl	%ecx, 48(%rsp)
	subl	$1, %eax
	movl	%eax, %ecx
	movslq	%r11d, %rax
	leaq	(%r9,%rax,8), %rax
	xorl	$524287, %ecx
	movq	%rax, 72(%rsp)
	leaq	320(%rsp), %rax
	movq	%rcx, 64(%rsp)
	movq	%rax, 56(%rsp)
	.p2align 4,,10
	.p2align 3
.L1620:
	cmpl	%edx, 16(%rsp)
	jle	.L1662
.L1693:
	testl	%edx, %edx
	js	.L1662
	xorl	%eax, %eax
	cmpl	%edx, %r15d
	jle	.L1612
	movq	72(%rsp), %rax
	movq	-8(%rax,%rdi,8), %rax
.L1612:
	movzbl	32(%rsp), %ecx
	movq	%rax, %r10
	movl	24(%rsp), %r14d
	salq	%cl, %r10
	movq	40(%rsp), %rcx
	orq	%rcx, %r10
	movl	%r14d, %ecx
	shrq	%cl, %rax
	testl	%r14d, %r14d
	movq	64(%rsp), %rcx
	cmovs	%r10, %rax
	orq	%rax, %rcx
	cmpl	$19, 48(%rsp)
	cmovl	%rcx, %rax
	movq	56(%rsp), %rcx
	andl	$524287, %eax
	movl	%eax, (%rcx,%rdi,4)
	leal	-1(%rdi), %ecx
	cmpl	$9, %ecx
	ja	.L1692
.L1616:
	movl	%r8d, %r10d
	movl	%r8d, %r14d
	movl	%eax, %ebp
	movl	%r8d, %ecx
	sarl	$6, %r10d
	andl	$63, %r14d
	salq	%cl, %rbp
	movslq	%r10d, %r13
	orq	%rbp, 192(%rsp,%r13,8)
	cmpl	$45, %r14d
	jle	.L1619
	addl	$1, %r10d
	movl	$64, %ecx
	addq	$1, %rdi
	addl	$1, %edx
	movslq	%r10d, %r10
	subl	%r14d, %ecx
	addl	$19, %r8d
	shrl	%cl, %eax
	orq	%rax, 192(%rsp,%r10,8)
	cmpl	%edx, 16(%rsp)
	jg	.L1693
	.p2align 4,,10
	.p2align 3
.L1662:
	movq	56(%rsp), %rcx
	movl	$524287, %eax
	movl	%eax, (%rcx,%rdi,4)
	leal	-1(%rdi), %ecx
	cmpl	$9, %ecx
	jbe	.L1616
.L1692:
	addl	$1, %edx
	addl	$19, %r8d
	cmpq	$11, %rdi
	je	.L1694
	movl	$1, %edi
	jmp	.L1620
	.p2align 4,,10
	.p2align 3
.L1619:
	addq	$1, %rdi
	addl	$1, %edx
	addl	$19, %r8d
	jmp	.L1620
.L1694:
	movq	8(%rsp), %rax
	pxor	%xmm0, %xmm0
	movq	$0, 176(%rsp)
	movaps	%xmm0, 160(%rsp)
	movq	56(%rax), %rdi
	movq	64(%rax), %rax
	movq	%rax, %rcx
	movq	%rax, 16(%rsp)
	movq	_ZL12random_state(%rip), %rax
	subq	%rdi, %rcx
	movq	%rax, %rdx
	sarq	$2, %rcx
	salq	$7, %rdx
	movl	%ecx, 48(%rsp)
	movslq	%ecx, %rcx
	xorq	%rax, %rdx
	movq	%rdx, %rax
	shrq	$9, %rax
	xorq	%rdx, %rax
	xorl	%edx, %edx
	movq	%rax, _ZL12random_state(%rip)
	divq	%rcx
	movl	72(%r12), %eax
	movl	%edx, %r14d
	testl	%eax, %eax
	jle	.L1665
	movl	$0, 16(%rsp)
	movq	192(%rsp), %rbp
	movq	$0, 64(%rsp)
	movl	$0, 72(%rsp)
	.p2align 4,,10
	.p2align 3
.L1632:
	movl	%r14d, %eax
	movq	24(%r12), %rsi
	movq	$-1, %rdx
	movl	%r14d, %ecx
	sarl	$6, %eax
	salq	%cl, %rdx
	movslq	%eax, %r8
	andq	(%rsi,%r8,8), %rdx
	jne	.L1622
	movq	32(%r12), %rcx
	subq	%rsi, %rcx
	sarq	$3, %rcx
	jmp	.L1624
	.p2align 4,,10
	.p2align 3
.L1695:
	movslq	%eax, %rdx
	leaq	(%rsi,%rdx,8), %rdx
	movq	(%rdx), %rdx
	testq	%rdx, %rdx
	jne	.L1622
.L1624:
	addl	$1, %eax
	cmpl	%eax, %ecx
	jne	.L1695
	movq	%rsi, %rdx
	xorl	%eax, %eax
	movq	(%rdx), %rdx
	testq	%rdx, %rdx
	je	.L1624
.L1622:
	rep bsfq	%rdx, %rdx
	sall	$6, %eax
	addl	%edx, %eax
	xorl	%edx, %edx
	leal	1(%rax), %r14d
	cltq
	cmpl	%r14d, 48(%rsp)
	movl	(%rdi,%rax,4), %esi
	movq	8(%rsp), %rax
	cmove	%edx, %r14d
	movq	(%rax), %rdx
	movslq	%esi, %rax
	leaq	(%rax,%rax,8), %rax
	salq	$4, %rax
	addq	24(%rdx), %rax
	movq	%rbp, %rdx
	andq	24(%rax), %rdx
	jne	.L1626
	movq	32(%rax), %rdx
	andq	200(%rsp), %rdx
	jne	.L1626
	movq	40(%rax), %rdx
	andq	208(%rsp), %rdx
	movq	%rdx, %r15
	je	.L1696
.L1626:
	addl	$1, 16(%rsp)
	movl	16(%rsp), %eax
	cmpl	%eax, 72(%r12)
	jle	.L1631
	movq	8(%rsp), %rax
	movq	56(%rax), %rdi
	jmp	.L1632
	.p2align 4,,10
	.p2align 3
.L1696:
	movl	8(%rax), %edi
	testl	%edi, %edi
	jle	.L1668
	movl	320(%rsp), %ecx
	movslq	%edi, %r8
	movl	%r14d, 92(%rsp)
	leaq	328(%rsp), %rdx
	leaq	0(,%r8,4), %rbx
	movq	%rdx, 40(%rsp)
	movl	324(%rsp), %r13d
	movq	%rbx, 32(%rsp)
	movl	%ecx, %r14d
	xorl	%ebx, %ebx
	movl	%esi, 80(%rsp)
	movq	%rax, 24(%rsp)
	movl	%edi, 96(%rsp)
	movq	%rbp, 104(%rsp)
	movq	%r12, 112(%rsp)
	jmp	.L1628
	.p2align 4,,10
	.p2align 3
.L1669:
	movl	%r12d, %r13d
.L1628:
	movq	24(%rsp), %rax
	leal	(%r13,%r13), %edi
	movl	48(%rax,%r15), %ebp
	andl	%ebp, %edi
	call	__popcountdi2@PLT
	movl	%r13d, %edi
	shrl	%edi
	addl	%eax, %ebx
	andl	%ebp, %edi
	call	__popcountdi2@PLT
	movl	%r14d, %edi
	movl	%r13d, %r14d
	andl	%ebp, %edi
	addl	%eax, %ebx
	call	__popcountdi2@PLT
	movl	%ebp, %edi
	addl	%eax, %ebx
	movq	40(%rsp), %rax
	movl	(%rax,%r15), %r12d
	addq	$4, %r15
	andl	%r12d, %edi
	call	__popcountdi2@PLT
	addl	%eax, %ebx
	cmpq	%r15, 32(%rsp)
	jne	.L1669
	sall	$4, %ebx
	pxor	%xmm0, %xmm0
	movl	80(%rsp), %esi
	movl	92(%rsp), %r14d
	cvtsi2sdl	%ebx, %xmm0
	movq	24(%rsp), %rax
	movl	96(%rsp), %edi
	movq	104(%rsp), %rbp
	movq	112(%rsp), %r12
.L1627:
	movq	8(%rsp), %rbx
	pxor	%xmm2, %xmm2
	movsd	.LC7(%rip), %xmm1
	movl	%esi, 152(%rsp)
	cvtsi2sdl	12(%rax), %xmm2
	subsd	112(%rbx), %xmm1
	movl	4(%rax), %ebx
	leal	(%rbx,%rbx), %edx
	mulsd	%xmm2, %xmm1
	subsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%edx, %xmm1
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	16(%rax), %xmm1
	mulsd	.LC8(%rip), %xmm1
	movq	64(%rsp), %rax
	subsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%edi, %xmm1
	mulsd	.LC9(%rip), %xmm1
	subsd	%xmm1, %xmm0
	movsd	%xmm0, 144(%rsp)
	cmpq	%rax, 176(%rsp)
	je	.L1629
	movdqa	144(%rsp), %xmm3
	addq	$16, %rax
	movups	%xmm3, -16(%rax)
	movq	%rax, 64(%rsp)
	movq	%rax, 168(%rsp)
.L1630:
	movq	8(%rsp), %rbx
	addl	$1, 72(%rsp)
	movl	72(%rsp), %eax
	cmpl	%eax, 24(%rbx)
	jg	.L1626
.L1631:
	movq	160(%rsp), %r14
	movq	64(%rsp), %rax
	cmpq	%rax, %r14
	jne	.L1697
	movq	8(%r12), %rbx
	movq	(%r12), %r9
	movl	80(%r12), %r11d
	movq	%rbx, %rsi
	subq	%r9, %rsi
	sarq	$3, %rsi
	movl	%esi, %r15d
.L1621:
	cmpl	%r11d, %r15d
	jg	.L1650
	leal	12(%r11), %eax
	cltq
	cmpq	%rax, %rsi
	jb	.L1698
	cmpq	%rsi, %rax
	jnb	.L1650
	leaq	(%r9,%rax,8), %rax
	cmpq	%rbx, %rax
	je	.L1650
	movq	%rax, 8(%r12)
.L1650:
	movl	76(%r12), %ecx
	movq	64(%rsp), %rdi
	movslq	%r11d, %rax
	movl	$1, %edx
	salq	%cl, %rdx
	orq	%rdx, (%r9,%rax,8)
	addl	$1, 88(%r12)
	testq	%rdi, %rdi
	je	.L1653
	movq	176(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	movl	80(%r12), %r11d
.L1653:
	movq	8(%rsp), %rax
	movl	12(%rax), %edi
	cmpl	%r11d, %edi
	jg	.L1605
	jmp	.L1654
	.p2align 4,,10
	.p2align 3
.L1629:
	leaq	160(%rsp), %rbx
	movq	64(%rsp), %rsi
	leaq	144(%rsp), %rdx
	movq	%rbx, %rdi
.LEHB25:
	call	_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	movq	168(%rsp), %rax
	movq	%rax, 64(%rsp)
	jmp	.L1630
.L1690:
	addl	$1, %r11d
	addq	$8, %rcx
	movl	$0, 76(%r12)
	movl	%r11d, 80(%r12)
	jmp	.L1610
.L1668:
	pxor	%xmm0, %xmm0
	jmp	.L1627
.L1698:
	subq	%rsi, %rax
	movq	%r12, %rdi
	leaq	160(%rsp), %rbx
	movq	%rax, %rsi
	call	_ZNSt6vectorImSaImEE17_M_default_appendEm
	movl	80(%r12), %r11d
	movq	(%r12), %r9
	jmp	.L1650
.L1665:
	movq	$0, 64(%rsp)
	jmp	.L1621
.L1697:
	movq	%rax, %rbx
	movq	%rax, %rdi
	movq	%r14, %rsi
	movq	%rax, 136(%rsp)
	movq	%r14, 144(%rsp)
	call	_ZSt4sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEEEvT_SB_.isra.0
	movq	%rbx, %rax
	subq	%r14, %rax
	movq	%rax, %rdx
	cmpq	$192, %rax
	ja	.L1634
.L1687:
	sarq	$4, %rdx
	movq	%rdx, %r8
	movl	%edx, %r9d
.L1660:
	movq	8(%rsp), %rbx
	movl	76(%r12), %r11d
	movl	%r9d, 92(%rsp)
	movq	%r14, %rsi
	movq	%r8, 96(%rsp)
	leaq	272(%rsp), %r13
	leaq	308(%rsp), %r10
	movl	$1, %r15d
	movq	(%rbx), %rax
	movl	8(%rbx), %ecx
	movl	%r11d, 72(%rsp)
	leal	10(%r11), %edx
	movq	%r14, 80(%rsp)
	movq	56(%rsp), %r14
	leaq	224(%rsp), %rbx
	movq	24(%rax), %rax
	movq	%rax, 48(%rsp)
.L1645:
	movslq	8(%rsi), %rax
	pxor	%xmm4, %xmm4
	xorl	%edi, %edi
	movl	72(%rsp), %r8d
	movaps	%xmm4, 240(%rsp)
	leaq	(%rax,%rax,8), %r11
	movq	48(%rsp), %rax
	movaps	%xmm4, 288(%rsp)
	salq	$4, %r11
	movaps	%xmm4, 224(%rsp)
	addq	%rax, %r11
	movups	%xmm4, 252(%rsp)
	movl	4(%r14,%rdi,4), %eax
	movaps	%xmm4, 272(%rsp)
	movups	%xmm4, 300(%rsp)
	cmpq	$10, %rdi
	je	.L1637
	.p2align 4,,10
	.p2align 3
.L1699:
	orl	48(%r11,%rdi,4), %eax
	xorl	%r9d, %r9d
	notl	%eax
	andl	$524287, %eax
	cmpl	$9, %r8d
	setg	%r9b
	cmpl	%edx, %ecx
	jle	.L1688
	orl	$262144, %r9d
.L1688:
	andl	%eax, %r9d
	leaq	1(%rdi), %rbp
	movl	%eax, (%rbx,%rdi,4)
	movl	%r9d, 0(%r13,%rdi,4)
	movq	%rbp, %rdi
	movl	4(%r14,%rdi,4), %eax
	cmpq	$10, %rdi
	jne	.L1699
.L1637:
	notl	%eax
	andl	$524287, %eax
	movl	%eax, 264(%rsp)
	movl	%eax, 312(%rsp)
.L1658:
	movq	%r10, %r8
	movl	$10, %edi
	xorl	%r11d, %r11d
	.p2align 4,,10
	.p2align 3
.L1643:
	movl	4(%r8), %r9d
	movl	%r9d, %ebp
	leal	(%r9,%r9), %eax
	shrl	%ebp
	orl	%ebp, %eax
	orl	%r9d, %eax
	testl	%edi, %edi
	je	.L1640
	orl	(%r8), %eax
	cmpl	$10, %edi
	je	.L1641
.L1640:
	orl	8(%r8), %eax
.L1641:
	andl	(%rbx,%rdi,4), %eax
	cmpl	%eax, %r9d
	movl	%eax, 4(%r8)
	cmovne	%r15d, %r11d
	subq	$1, %rdi
	subq	$4, %r8
	cmpq	$-1, %rdi
	jne	.L1643
	testb	%r11b, %r11b
	jne	.L1658
	movl	%ecx, 16(%rsp)
	xorl	%ebp, %ebp
	xorl	%r12d, %r12d
	movq	%rsi, 24(%rsp)
	movq	%r10, 32(%rsp)
	movl	%edx, 40(%rsp)
	.p2align 4,,10
	.p2align 3
.L1644:
	movl	0(%r13,%rbp), %edi
	notl	%edi
	andl	(%rbx,%rbp), %edi
	addq	$4, %rbp
	call	__popcountdi2@PLT
	addl	%eax, %r12d
	cmpq	$44, %rbp
	jne	.L1644
	imull	$45, %r12d, %r12d
	pxor	%xmm1, %xmm1
	movl	16(%rsp), %ecx
	movl	40(%rsp), %edx
	movq	24(%rsp), %rsi
	movq	32(%rsp), %r10
	cvtsi2sdl	%r12d, %xmm1
	movsd	(%rsi), %xmm0
	addq	$16, %rsi
	subsd	%xmm1, %xmm0
	movsd	%xmm0, -16(%rsi)
	cmpq	%rsi, 64(%rsp)
	jne	.L1645
	movq	64(%rsp), %rax
	movq	80(%rsp), %r14
	movl	92(%rsp), %r9d
	movq	96(%rsp), %r8
	movq	%rax, %rdi
	movq	%r14, %rsi
	movq	%rax, 136(%rsp)
	movl	%r9d, 24(%rsp)
	movq	%r8, 16(%rsp)
	movq	%r14, 144(%rsp)
	call	_ZSt4sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEEEvT_SB_.isra.0
	movq	8(%rsp), %rax
	movl	24(%rsp), %r9d
	movslq	20(%rax), %rax
	cmpl	%r9d, %eax
	jge	.L1646
	movq	16(%rsp), %r8
	cmpq	%rax, %r8
	jb	.L1700
	movq	%rax, %rdx
	salq	$4, %rdx
	addq	%r14, %rdx
	cmpq	%r8, %rax
	cmovnb	64(%rsp), %rdx
	movq	%rdx, 64(%rsp)
.L1646:
	movq	120(%rsp), %rbx
	movq	64(%rsp), %rax
	movq	%rax, 8(%rbx)
	movq	176(%rsp), %rax
	movq	%r14, (%rbx)
	movq	%rax, 16(%rbx)
	jmp	.L1604
.L1634:
	movq	64(%rsp), %rbx
	leaq	192(%r14), %rax
	cmpq	%rbx, %rax
	je	.L1687
	movq	%rax, 168(%rsp)
	movl	$12, %r9d
	movl	$12, %r8d
	movq	%rax, 64(%rsp)
	jmp	.L1660
.L1700:
	subq	%r8, %rax
	leaq	160(%rsp), %rbx
	movq	%rax, %rsi
	movq	%rbx, %rdi
	call	_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_default_appendEm
.LEHE25:
	movq	168(%rsp), %rax
	movq	160(%rsp), %r14
	movq	%rax, 64(%rsp)
	jmp	.L1646
.L1656:
	movq	%rbx, %rdi
	call	_ZNSt6vectorISt4pairIdiESaIS1_EED1Ev
	movq	376(%rsp), %rax
	subq	%fs:40, %rax
	je	.L1657
.L1689:
	call	__stack_chk_fail@PLT
.L1671:
	endbr64
	movq	%rax, %rbp
	jmp	.L1656
.L1657:
	movq	%rbp, %rdi
.LEHB26:
	call	_Unwind_Resume@PLT
.LEHE26:
	.cfi_endproc
.LFE10124:
	.section	.gcc_except_table._ZN10BeamPacker7optionsERNS_5StateE,"aG",@progbits,_ZN10BeamPacker7optionsERNS_5StateE,comdat
.LLSDA10124:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE10124-.LLSDACSB10124
.LLSDACSB10124:
	.uleb128 .LEHB25-.LFB10124
	.uleb128 .LEHE25-.LEHB25
	.uleb128 .L1671-.LFB10124
	.uleb128 0
	.uleb128 .LEHB26-.LFB10124
	.uleb128 .LEHE26-.LEHB26
	.uleb128 0
	.uleb128 0
.LLSDACSE10124:
	.section	.text._ZN10BeamPacker7optionsERNS_5StateE,"axG",@progbits,_ZN10BeamPacker7optionsERNS_5StateE,comdat
	.size	_ZN10BeamPacker7optionsERNS_5StateE, .-_ZN10BeamPacker7optionsERNS_5StateE
	.section	.text._ZNK6Packer12future_scoreERK7Variant,"axG",@progbits,_ZNK6Packer12future_scoreERK7Variant,comdat
	.align 2
	.p2align 4
	.weak	_ZNK6Packer12future_scoreERK7Variant
	.type	_ZNK6Packer12future_scoreERK7Variant, @function
_ZNK6Packer12future_scoreERK7Variant:
.LFB10015:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA10015
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$520, %rsp
	.cfi_def_cfa_offset 576
	movl	116(%rdi), %r14d
	movl	120(%rdi), %ebp
	movq	%rdi, 8(%rsp)
	movl	96(%rdi), %ebx
	movq	%rsi, 40(%rsp)
	leal	1(%r14), %r12d
	movl	%ebp, %r9d
	movq	%fs:40, %rax
	movq	%rax, 504(%rsp)
	xorl	%eax, %eax
	cmpl	%r12d, %ebx
	jne	.L1702
	leal	1(%rbp), %r9d
	xorl	%r12d, %r12d
.L1702:
	movq	8(%rsp), %rcx
	movslq	%ebp, %rax
	movq	40(%rsp), %r13
	movslq	%r9d, %rsi
	negq	%rax
	movl	%r14d, 32(%rsp)
	subl	%ebp, %r9d
	movl	108(%rcx), %edx
	movl	%ebp, 48(%rsp)
	leaq	0(%r13,%rax,4), %r15
	movq	%rcx, %rbp
	movl	%edx, 24(%rsp)
	movl	%edx, %r14d
.L1707:
	movl	32(%rsp), %eax
	movl	%r12d, %edx
	movl	%esi, 16(%rsp)
	subl	%eax, %edx
	addl	$9, %edx
.L1706:
	cmpl	%esi, %r14d
	jle	.L1756
	movl	100(%rbp), %edi
	movl	16(%rsp), %ecx
	movq	128(%rbp), %r10
	movl	8(%r13), %r8d
	movl	%edi, %eax
	imull	%ecx, %eax
	movl	%r12d, %ecx
	sarl	$6, %ecx
	addl	%ecx, %eax
	movl	%r12d, %ecx
	cltq
	movq	(%r10,%rax,8), %rax
	shrq	%cl, %rax
	andl	$1, %eax
	cmpl	%r9d, %r8d
	jle	.L1704
	cmpl	$18, %edx
	ja	.L1704
	movl	48(%r15,%rsi,4), %r11d
	movl	%edx, %ecx
	shrl	%cl, %r11d
	orl	%r11d, %eax
	andl	$1, %eax
.L1704:
	testb	%al, %al
	je	.L1705
	addl	$1, %r12d
	addl	$1, %edx
	cmpl	%r12d, %ebx
	jne	.L1706
	addq	$1, %rsi
	addl	$1, %r9d
	xorl	%r12d, %r12d
	jmp	.L1707
.L1756:
	movsd	.LC13(%rip), %xmm1
.L1701:
	movq	504(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1778
	addq	$520, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movapd	%xmm1, %xmm0
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1705:
	.cfi_restore_state
	leal	-9(%r12), %r15d
	leal	-9(%rdx), %eax
	movl	48(%rsp), %ebp
	pxor	%xmm0, %xmm0
	movl	%r15d, %r13d
	movl	%r15d, 64(%rsp)
	sarl	$6, %r15d
	movslq	16(%rsp), %r11
	movl	%eax, 92(%rsp)
	leal	1(%r15), %eax
	subl	%r13d, %ebx
	movl	32(%rsp), %r14d
	movl	%eax, 96(%rsp)
	movl	$9, %eax
	leal	-1(%r11), %esi
	andl	$63, %r13d
	subl	%r12d, %eax
	movl	%r15d, 88(%rsp)
	movl	%esi, %r9d
	movl	%eax, %ecx
	movl	%eax, 80(%rsp)
	subl	%ebp, %r9d
	movl	$1, %eax
	movl	%eax, %edx
	movl	%ebx, 16(%rsp)
	sall	%cl, %edx
	movl	%r13d, 72(%rsp)
	leal	-1(%rdx), %ecx
	movaps	%xmm0, 304(%rsp)
	xorl	%edx, %edx
	movl	%ecx, 84(%rsp)
	movl	%ebx, %ecx
	sall	%cl, %eax
	movl	%r14d, %ecx
	movq	$0, 192(%rsp)
	subl	$1, %eax
	subl	%r12d, %ecx
	movaps	%xmm0, 320(%rsp)
	xorl	$524287, %eax
	movaps	%xmm0, 336(%rsp)
	movl	%ecx, %r14d
	movl	%eax, 32(%rsp)
	movl	%esi, %eax
	imull	%edi, %eax
	movaps	%xmm0, 176(%rsp)
	leal	1(%r15,%rax), %r15d
	movslq	%ebp, %rax
	subq	%rax, %r11
	movq	40(%rsp), %rax
	leaq	(%rax,%r11,4), %rax
	movq	%rax, 104(%rsp)
	leaq	304(%rsp), %rax
	movq	%rax, 56(%rsp)
	leal	18(%rcx), %eax
	movl	%eax, 48(%rsp)
	.p2align 4,,10
	.p2align 3
.L1720:
	cmpl	%esi, 24(%rsp)
	jle	.L1757
.L1783:
	testl	%esi, %esi
	js	.L1757
	movq	8(%rsp), %rcx
	xorl	%eax, %eax
	cmpl	%esi, 104(%rcx)
	jle	.L1708
	movl	64(%rsp), %ecx
	testl	%ecx, %ecx
	js	.L1780
	leal	-1(%r15), %eax
	movl	72(%rsp), %ebx
	cltq
	movq	(%r10,%rax,8), %rax
	movl	%ebx, %ecx
	shrq	%cl, %rax
	cmpl	$45, %ebx
	jle	.L1710
	movl	96(%rsp), %ecx
	cmpl	%ecx, %edi
	jle	.L1710
	movslq	%r15d, %r11
	movl	$64, %ecx
	movq	(%r10,%r11,8), %r11
	subl	%ebx, %ecx
	salq	%cl, %r11
	orq	%r11, %rax
	.p2align 4,,10
	.p2align 3
.L1710:
	movl	32(%rsp), %ecx
	orl	%eax, %ecx
	cmpl	$19, 16(%rsp)
	cmovl	%ecx, %eax
	andl	$524287, %eax
.L1708:
	cmpl	%r9d, %r8d
	jle	.L1713
	testl	%r9d, %r9d
	jns	.L1781
.L1713:
	movq	56(%rsp), %rcx
	movl	%eax, (%rcx,%rdx,4)
	leal	-1(%rdx), %ecx
	cmpl	$9, %ecx
	ja	.L1782
	leal	(%rdx,%rdx,8), %ecx
	movl	%eax, %ebx
	leal	-19(%rdx,%rcx,2), %ecx
	movl	%ecx, %r11d
	movl	%ecx, %ebp
	salq	%cl, %rbx
	sarl	$6, %r11d
	andl	$63, %ebp
	movslq	%r11d, %r13
	orq	%rbx, 176(%rsp,%r13,8)
	cmpl	$45, %ebp
	jle	.L1719
	addl	$1, %r11d
	movl	$64, %ecx
	addq	$1, %rdx
	addl	$1, %esi
	movslq	%r11d, %r11
	subl	%ebp, %ecx
	addl	$1, %r9d
	addl	%edi, %r15d
	shrl	%cl, %eax
	orq	%rax, 176(%rsp,%r11,8)
	cmpl	%esi, 24(%rsp)
	jg	.L1783
	.p2align 4,,10
	.p2align 3
.L1757:
	movl	$524287, %eax
	jmp	.L1708
	.p2align 4,,10
	.p2align 3
.L1719:
	addq	$1, %rdx
	addl	$1, %esi
	addl	$1, %r9d
	addl	%edi, %r15d
	jmp	.L1720
	.p2align 4,,10
	.p2align 3
.L1782:
	addl	$1, %esi
	addl	$1, %r9d
	addl	%edi, %r15d
	cmpq	$11, %rdx
	je	.L1784
	movl	$1, %edx
	jmp	.L1720
.L1781:
	cmpl	$36, 48(%rsp)
	ja	.L1713
	movq	104(%rsp), %rcx
	movl	44(%rcx,%rdx,4), %r11d
	movl	%r14d, %ecx
	movl	%r11d, %ebx
	sall	%cl, %ebx
	movzbl	92(%rsp), %ecx
	shrl	%cl, %r11d
	testl	%r14d, %r14d
	movl	%ebx, %ecx
	cmovs	%r11d, %ecx
	orl	%ecx, %eax
	andl	$524287, %eax
	jmp	.L1713
.L1780:
	movl	88(%rsp), %ecx
	movl	%r15d, %eax
	subl	%ecx, %eax
	movzbl	80(%rsp), %ecx
	subl	$1, %eax
	cltq
	movq	(%r10,%rax,8), %rax
	salq	%cl, %rax
	movl	84(%rsp), %ecx
	orl	%ecx, %eax
	jmp	.L1710
.L1784:
	movq	8(%rsp), %rax
	pxor	%xmm0, %xmm0
	movq	$0, 160(%rsp)
	movaps	%xmm0, 144(%rsp)
	movq	24(%rax), %rcx
	movq	32(%rax), %rax
	movq	%rax, %rsi
	movq	%rax, 16(%rsp)
	movq	40(%rsp), %rax
	subq	%rcx, %rsi
	movl	20(%rax), %eax
	sarq	$2, %rsi
	movl	%esi, 48(%rsp)
	leal	(%rax,%rax,8), %edx
	leal	(%rax,%rdx,8), %eax
	cltd
	idivl	%esi
	testl	%esi, %esi
	jle	.L1760
	movl	%edx, %r14d
	leal	(%rdx,%rsi), %r13d
	xorl	%r8d, %r8d
	jmp	.L1732
	.p2align 4,,10
	.p2align 3
.L1722:
	movq	24(%rax), %rdx
	andq	176(%rsp), %rdx
	jne	.L1723
	movq	32(%rax), %rdx
	andq	184(%rsp), %rdx
	jne	.L1723
	movq	40(%rax), %rdx
	andq	192(%rsp), %rdx
	movq	%rdx, %rbp
	je	.L1785
.L1723:
	addl	$1, %r14d
	cmpl	%r13d, %r14d
	je	.L1786
.L1729:
	movq	8(%rsp), %rax
	movq	24(%rax), %rcx
.L1732:
	movl	%r14d, %eax
	movq	40(%rsp), %rsi
	cltd
	idivl	48(%rsp)
	movq	8(%rsp), %rax
	movslq	%edx, %rdx
	movl	(%rcx,%rdx,4), %edi
	movq	16(%rax), %rdx
	movslq	%edi, %rax
	leaq	(%rax,%rax,8), %rax
	salq	$4, %rax
	addq	(%rdx), %rax
	movslq	(%rax), %rdx
	cmpl	(%rsi), %edx
	jne	.L1722
	movq	8(%rsp), %rsi
	movq	48(%rsi), %rcx
	cmpl	$1, (%rcx,%rdx,4)
	jg	.L1722
	addl	$1, %r14d
	cmpl	%r13d, %r14d
	jne	.L1729
.L1786:
	movq	144(%rsp), %rbx
	cmpq	%rbx, %r8
	je	.L1730
	movq	%r8, %rdi
	movq	%rbx, %rsi
	movq	%r8, 120(%rsp)
	movq	%r8, 16(%rsp)
	movq	%rbx, 128(%rsp)
	call	_ZSt4sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEEEvT_SB_.isra.0
	movq	16(%rsp), %r8
	movq	%r8, %rax
	subq	%rbx, %rax
	cmpq	$48, %rax
	ja	.L1734
.L1736:
	leaq	480(%rsp), %rax
	pxor	%xmm0, %xmm0
	movl	64(%rsp), %ecx
	movq	56(%rsp), %rdx
	movq	%rax, 464(%rsp)
	movq	8(%rsp), %rax
	leaq	352(%rsp), %rsi
	movups	%xmm0, 376(%rsp)
	movl	96(%rax), %ebp
	movaps	%xmm0, 400(%rsp)
	movaps	%xmm0, 416(%rsp)
	pxor	%xmm0, %xmm0
	movl	%ebp, %edi
	movq	%r8, 16(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 472(%rsp)
	movb	$0, 480(%rsp)
	movups	%xmm0, 440(%rsp)
	call	_ZNK6Packer5holesERK7VariantRKSt5arrayIjLm12EEi.isra.0
	pxor	%xmm3, %xmm3
	movq	16(%rsp), %r8
	imull	$45, %eax, %eax
	cvtsi2sdl	%eax, %xmm3
.L1735:
	movl	64(%rsp), %edx
	xorl	%eax, %eax
	movq	%rbx, 72(%rsp)
	movq	%rbx, %rcx
	movq	%r8, 64(%rsp)
	movsd	.LC11(%rip), %xmm1
	leaq	292(%rsp), %r9
	testl	%edx, %edx
	movq	8(%rsp), %rsi
	setg	%al
	addl	$10, %r12d
	movl	%eax, %edx
	orl	$262144, %edx
	cmpl	%ebp, %r12d
	movl	$1, %r12d
	cmovge	%eax, %edx
	leaq	208(%rsp), %rbp
	movl	%edx, %r15d
	movq	56(%rsp), %rdx
	.p2align 4,,10
	.p2align 3
.L1748:
	movsd	(%rcx), %xmm0
	movapd	%xmm0, %xmm2
	addsd	%xmm3, %xmm2
	comisd	%xmm2, %xmm1
	jnb	.L1737
	movslq	8(%rcx), %rax
	movq	16(%rsi), %rdi
	pxor	%xmm4, %xmm4
	movq	$0, 288(%rsp)
	movaps	%xmm4, 224(%rsp)
	leaq	256(%rsp), %r14
	leaq	(%rax,%rax,8), %r8
	movaps	%xmm4, 208(%rsp)
	salq	$4, %r8
	movups	%xmm4, 236(%rsp)
	addq	(%rdi), %r8
	xorl	%edi, %edi
	movaps	%xmm4, 256(%rsp)
	movaps	%xmm4, 272(%rsp)
	jmp	.L1739
	.p2align 4,,10
	.p2align 3
.L1787:
	movl	48(%r8,%rdi,4), %eax
	orl	4(%rdx,%rdi,4), %eax
	notl	%eax
	andl	$524287, %eax
	movl	%eax, 0(%rbp,%rdi,4)
	andl	%r15d, %eax
	movl	%eax, (%r14,%rdi,4)
	addq	$1, %rdi
.L1739:
	cmpq	$10, %rdi
	jne	.L1787
	movl	348(%rsp), %eax
	notl	%eax
	andl	$524287, %eax
	movl	%eax, 248(%rsp)
	movl	%eax, 296(%rsp)
.L1740:
	movq	%r9, %r8
	movl	$10, %edi
	xorl	%r11d, %r11d
	.p2align 4,,10
	.p2align 3
.L1744:
	movl	4(%r8), %r10d
	movl	%r10d, %ebx
	leal	(%r10,%r10), %eax
	shrl	%ebx
	orl	%ebx, %eax
	orl	%r10d, %eax
	testl	%edi, %edi
	je	.L1741
	orl	(%r8), %eax
	cmpl	$10, %edi
	je	.L1742
.L1741:
	orl	8(%r8), %eax
.L1742:
	andl	0(%rbp,%rdi,4), %eax
	cmpl	%eax, %r10d
	movl	%eax, 4(%r8)
	cmovne	%r12d, %r11d
	subq	$1, %rdi
	subq	$4, %r8
	cmpq	$-1, %rdi
	jne	.L1744
	testb	%r11b, %r11b
	jne	.L1740
	movq	%rcx, 16(%rsp)
	xorl	%ebx, %ebx
	xorl	%r13d, %r13d
	movq	%rsi, 40(%rsp)
	movq	%rdx, 48(%rsp)
	movq	%r9, 56(%rsp)
	movsd	%xmm0, 8(%rsp)
	movsd	%xmm3, 24(%rsp)
	movsd	%xmm1, 32(%rsp)
	.p2align 4,,10
	.p2align 3
.L1745:
	movl	(%r14,%rbx), %edi
	notl	%edi
	andl	0(%rbp,%rbx), %edi
	addq	$4, %rbx
	call	__popcountdi2@PLT
	addl	%eax, %r13d
	cmpq	$44, %rbx
	jne	.L1745
	imull	$45, %r13d, %r13d
	pxor	%xmm2, %xmm2
	movsd	24(%rsp), %xmm3
	movsd	8(%rsp), %xmm0
	movsd	32(%rsp), %xmm1
	movq	16(%rsp), %rcx
	movq	40(%rsp), %rsi
	movq	48(%rsp), %rdx
	cvtsi2sdl	%r13d, %xmm2
	movq	56(%rsp), %r9
	subsd	%xmm3, %xmm2
	subsd	%xmm2, %xmm0
	maxsd	%xmm1, %xmm0
	movapd	%xmm0, %xmm1
.L1737:
	addq	$16, %rcx
	cmpq	%rcx, 64(%rsp)
	jne	.L1748
	movq	72(%rsp), %rbx
	movq	160(%rsp), %rsi
	subq	%rbx, %rsi
.L1733:
	testq	%rbx, %rbx
	je	.L1701
	movq	%rbx, %rdi
	movsd	%xmm1, 8(%rsp)
	call	_ZdlPvm@PLT
	movsd	8(%rsp), %xmm1
	jmp	.L1701
.L1785:
	movl	8(%rax), %r9d
	testl	%r9d, %r9d
	jle	.L1761
	movslq	%r9d, %r10
	movl	304(%rsp), %ecx
	movl	%edi, 72(%rsp)
	xorl	%ebx, %ebx
	leaq	0(,%r10,4), %rsi
	movl	%r14d, 84(%rsp)
	movl	308(%rsp), %r15d
	movq	%rsi, 24(%rsp)
	leaq	312(%rsp), %rsi
	movl	%ecx, %r14d
	movq	%rsi, 32(%rsp)
	movl	%r12d, 80(%rsp)
	movq	%rax, 16(%rsp)
	movl	%r9d, 88(%rsp)
	movl	%r13d, 92(%rsp)
	movq	%r8, 96(%rsp)
	jmp	.L1725
	.p2align 4,,10
	.p2align 3
.L1762:
	movl	%r13d, %r15d
.L1725:
	movq	16(%rsp), %rax
	leal	(%r15,%r15), %edi
	movl	48(%rax,%rbp), %r12d
	andl	%r12d, %edi
	call	__popcountdi2@PLT
	movl	%r15d, %edi
	shrl	%edi
	addl	%eax, %ebx
	andl	%r12d, %edi
	call	__popcountdi2@PLT
	movl	%r14d, %edi
	movl	%r15d, %r14d
	andl	%r12d, %edi
	addl	%eax, %ebx
	call	__popcountdi2@PLT
	movl	%r12d, %edi
	addl	%eax, %ebx
	movq	32(%rsp), %rax
	movl	(%rax,%rbp), %r13d
	addq	$4, %rbp
	andl	%r13d, %edi
	call	__popcountdi2@PLT
	addl	%eax, %ebx
	cmpq	%rbp, 24(%rsp)
	jne	.L1762
	sall	$4, %ebx
	pxor	%xmm0, %xmm0
	movl	72(%rsp), %edi
	movl	80(%rsp), %r12d
	cvtsi2sdl	%ebx, %xmm0
	movq	16(%rsp), %rax
	movl	84(%rsp), %r14d
	movl	88(%rsp), %r9d
	movl	92(%rsp), %r13d
	movq	96(%rsp), %r8
.L1724:
	movq	8(%rsp), %rsi
	pxor	%xmm2, %xmm2
	movsd	.LC7(%rip), %xmm1
	movl	%edi, 136(%rsp)
	cvtsi2sdl	12(%rax), %xmm2
	subsd	184(%rsi), %xmm1
	mulsd	%xmm2, %xmm1
	subsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	4(%rax), %xmm1
	addsd	%xmm1, %xmm1
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	16(%rax), %xmm1
	mulsd	.LC8(%rip), %xmm1
	subsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%r9d, %xmm1
	mulsd	.LC9(%rip), %xmm1
	subsd	%xmm1, %xmm0
	movsd	%xmm0, 128(%rsp)
	cmpq	%r8, 160(%rsp)
	je	.L1726
	movdqa	128(%rsp), %xmm5
	addq	$16, %r8
	movups	%xmm5, -16(%r8)
	movq	%r8, 152(%rsp)
.L1727:
	movq	144(%rsp), %rbx
	movq	%r8, %rax
	subq	%rbx, %rax
	cmpq	$240, %rax
	jbe	.L1723
	cmpq	%r8, %rbx
	je	.L1730
	movq	%r8, %rdi
	movq	%rbx, %rsi
	movq	%r8, 120(%rsp)
	movq	%r8, 16(%rsp)
	movq	%rbx, 128(%rsp)
	call	_ZSt4sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEEEvT_SB_.isra.0
	movq	16(%rsp), %r8
.L1734:
	leaq	48(%rbx), %r14
	cmpq	%r14, %r8
	je	.L1736
	leaq	480(%rsp), %rax
	pxor	%xmm0, %xmm0
	movl	64(%rsp), %ecx
	movq	56(%rsp), %rdx
	movq	%rax, 464(%rsp)
	movq	8(%rsp), %rax
	leaq	352(%rsp), %rsi
	movups	%xmm0, 376(%rsp)
	movl	96(%rax), %ebp
	movaps	%xmm0, 400(%rsp)
	movaps	%xmm0, 416(%rsp)
	pxor	%xmm0, %xmm0
	movl	%ebp, %edi
	movq	%r14, 152(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 472(%rsp)
	movb	$0, 480(%rsp)
	movups	%xmm0, 440(%rsp)
	call	_ZNK6Packer5holesERK7VariantRKSt5arrayIjLm12EEi.isra.0
	pxor	%xmm3, %xmm3
	movq	%r14, %r8
	imull	$45, %eax, %eax
	cvtsi2sdl	%eax, %xmm3
	jmp	.L1735
.L1726:
	leaq	144(%rsp), %rbx
	leaq	128(%rsp), %rdx
	movq	%r8, %rsi
	movq	%rbx, %rdi
.LEHB27:
	call	_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
.LEHE27:
	movq	152(%rsp), %r8
	jmp	.L1727
.L1761:
	pxor	%xmm0, %xmm0
	jmp	.L1724
.L1730:
	movq	160(%rsp), %rsi
	movsd	.LC12(%rip), %xmm1
	subq	%rbx, %rsi
	jmp	.L1733
.L1760:
	movsd	.LC12(%rip), %xmm1
	jmp	.L1701
.L1751:
	movq	%rbx, %rdi
	call	_ZNSt6vectorISt4pairIdiESaIS1_EED1Ev
	movq	504(%rsp), %rax
	subq	%fs:40, %rax
	je	.L1752
.L1778:
	call	__stack_chk_fail@PLT
.L1764:
	endbr64
	movq	%rax, %rbp
	jmp	.L1751
.L1752:
	movq	%rbp, %rdi
.LEHB28:
	call	_Unwind_Resume@PLT
.LEHE28:
	.cfi_endproc
.LFE10015:
	.section	.gcc_except_table._ZNK6Packer12future_scoreERK7Variant,"aG",@progbits,_ZNK6Packer12future_scoreERK7Variant,comdat
.LLSDA10015:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE10015-.LLSDACSB10015
.LLSDACSB10015:
	.uleb128 .LEHB27-.LFB10015
	.uleb128 .LEHE27-.LEHB27
	.uleb128 .L1764-.LFB10015
	.uleb128 0
	.uleb128 .LEHB28-.LFB10015
	.uleb128 .LEHE28-.LEHB28
	.uleb128 0
	.uleb128 0
.LLSDACSE10015:
	.section	.text._ZNK6Packer12future_scoreERK7Variant,"axG",@progbits,_ZNK6Packer12future_scoreERK7Variant,comdat
	.size	_ZNK6Packer12future_scoreERK7Variant, .-_ZNK6Packer12future_scoreERK7Variant
	.section	.text._ZN6Packer4stepEi,"axG",@progbits,_ZN6Packer4stepEi,comdat
	.align 2
	.p2align 4
	.weak	_ZN6Packer4stepEi
	.type	_ZN6Packer4stepEi, @function
_ZN6Packer4stepEi:
.LFB10041:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA10041
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$296, %rsp
	.cfi_def_cfa_offset 352
	movl	120(%rdi), %edx
	movl	108(%rdi), %r15d
	movq	%rdi, 8(%rsp)
	movl	%esi, 96(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 280(%rsp)
	xorl	%eax, %eax
	cmpl	%r15d, %edx
	jge	.L1793
	movq	8(%rsp), %rsi
	movq	128(%rsi), %rdi
	movl	100(%rsi), %r11d
	movq	%rdi, 40(%rsp)
	jmp	.L1791
	.p2align 4,,10
	.p2align 3
.L1794:
	addl	$1, %ecx
	movl	%ecx, 116(%rsi)
	cmpl	96(%rsi), %ecx
	jne	.L1792
	addl	$1, %edx
	movl	$0, 116(%rsi)
	movl	%edx, 120(%rsi)
.L1792:
	cmpl	%edx, %r15d
	jle	.L1793
.L1791:
	movl	116(%rsi), %ecx
	movl	%r11d, %r14d
	imull	%edx, %r14d
	movl	%ecx, %eax
	sarl	$6, %eax
	addl	%eax, %r14d
	movslq	%r14d, %rbp
	salq	$3, %rbp
	leaq	(%rdi,%rbp), %r10
	movq	(%r10), %r9
	movq	%r9, %rax
	shrq	%cl, %rax
	andl	$1, %eax
	jne	.L1794
	leal	-9(%rcx), %r8d
	movl	%ecx, %ebx
	movl	$1, %esi
	subl	$1, %edx
	movl	%r8d, %ecx
	movl	%r8d, 24(%rsp)
	andl	$63, %r8d
	pxor	%xmm0, %xmm0
	sarl	$6, %ecx
	movl	%r8d, 56(%rsp)
	leal	1(%rcx), %edi
	movl	%ecx, 64(%rsp)
	movl	$9, %ecx
	subl	%ebx, %ecx
	movl	%ebx, 100(%rsp)
	sall	%cl, %esi
	movl	%ecx, 72(%rsp)
	movl	%r11d, %ecx
	imull	%edx, %ecx
	subl	$1, %esi
	movl	%edi, 88(%rsp)
	movl	%esi, 84(%rsp)
	movq	$0, 208(%rsp)
	leal	(%rcx,%rdi), %esi
	movaps	%xmm0, 224(%rsp)
	movl	$-19, %edi
	movl	%esi, 16(%rsp)
	leaq	224(%rsp), %rsi
	movq	%rsi, 48(%rsp)
	movaps	%xmm0, 240(%rsp)
	movaps	%xmm0, 256(%rsp)
	movaps	%xmm0, 192(%rsp)
.L1804:
	testl	%edx, %edx
	js	.L1870
.L1904:
	cmpl	%edx, %r15d
	jle	.L1870
	movq	8(%rsp), %rbx
	xorl	%esi, %esi
	cmpl	%edx, 104(%rbx)
	jle	.L1795
	movl	24(%rsp), %ecx
	testl	%ecx, %ecx
	js	.L1903
	movslq	16(%rsp), %r8
	movq	40(%rsp), %r13
	movl	56(%rsp), %ebx
	leal	-1(%r8), %ecx
	movslq	%ecx, %rcx
	movq	0(%r13,%rcx,8), %rsi
	movl	%ebx, %ecx
	shrq	%cl, %rsi
	cmpl	$45, %ebx
	jle	.L1797
	movl	88(%rsp), %ecx
	cmpl	%ecx, %r11d
	jle	.L1797
	movq	0(%r13,%r8,8), %r8
	movl	$64, %ecx
	subl	%ebx, %ecx
	salq	%cl, %r8
	orq	%r8, %rsi
	.p2align 4,,10
	.p2align 3
.L1797:
	movq	8(%rsp), %rbx
	movl	96(%rbx), %ebx
	movl	%ebx, %ecx
	movl	%ebx, 32(%rsp)
	movl	24(%rsp), %ebx
	subl	%ebx, %ecx
	cmpl	$18, %ecx
	jg	.L1799
	movl	$1, %ebx
	sall	%cl, %ebx
	movl	%ebx, %ecx
	subl	$1, %ecx
	xorl	$524287, %ecx
	orl	%ecx, %esi
.L1799:
	andl	$524287, %esi
.L1795:
	movq	48(%rsp), %rbx
	leal	-1(%rax), %ecx
	movl	%esi, (%rbx,%rax,4)
	cmpl	$9, %ecx
	ja	.L1800
.L1905:
	movl	%edi, %r8d
	movl	%edi, %r13d
	movl	%esi, %ebx
	movl	%edi, %ecx
	sarl	$6, %r8d
	andl	$63, %r13d
	salq	%cl, %rbx
	movslq	%r8d, %r12
	orq	%rbx, 192(%rsp,%r12,8)
	cmpl	$45, %r13d
	jle	.L1898
	addl	$1, %r8d
	movl	$64, %ecx
	movslq	%r8d, %r8
	subl	%r13d, %ecx
	shrl	%cl, %esi
	orq	%rsi, 192(%rsp,%r8,8)
.L1898:
	addl	$1, %edx
	addl	%r11d, 16(%rsp)
	addq	$1, %rax
	addl	$19, %edi
	testl	%edx, %edx
	jns	.L1904
.L1870:
	movq	48(%rsp), %rbx
	movl	$524287, %esi
	leal	-1(%rax), %ecx
	movl	%esi, (%rbx,%rax,4)
	cmpl	$9, %ecx
	jbe	.L1905
.L1800:
	addl	$19, %edi
	cmpl	$209, %edi
	je	.L1803
	addl	%r11d, 16(%rsp)
	addq	$1, %rax
	addl	$1, %edx
	jmp	.L1804
	.p2align 4,,10
	.p2align 3
.L1793:
	xorl	%eax, %eax
.L1788:
	movq	280(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L1901
	addq	$296, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1903:
	.cfi_restore_state
	movl	64(%rsp), %esi
	movl	16(%rsp), %ecx
	subl	%esi, %ecx
	movq	40(%rsp), %rsi
	subl	$1, %ecx
	movslq	%ecx, %rcx
	movq	(%rsi,%rcx,8), %rsi
	movzbl	72(%rsp), %ecx
	salq	%cl, %rsi
	movl	84(%rsp), %ecx
	orl	%ecx, %esi
	jmp	.L1797
	.p2align 4,,10
	.p2align 3
.L1803:
	movq	8(%rsp), %rax
	pxor	%xmm0, %xmm0
	movl	100(%rsp), %ebx
	movq	$0, 176(%rsp)
	movaps	%xmm0, 160(%rsp)
	movq	24(%rax), %rcx
	movq	32(%rax), %rax
	movq	%rax, 16(%rsp)
	subq	%rcx, %rax
	sarq	$2, %rax
	movq	%rax, %rsi
	movq	%rax, 120(%rsp)
	movl	%eax, 64(%rsp)
	movq	_ZL12random_state(%rip), %rax
	movslq	%esi, %rdi
	movq	%rax, %rdx
	salq	$7, %rdx
	xorq	%rax, %rdx
	movq	%rdx, %rax
	shrq	$9, %rax
	xorq	%rdx, %rax
	xorl	%edx, %edx
	movq	%rax, _ZL12random_state(%rip)
	divq	%rdi
	movl	$2400, %eax
	cmpl	%eax, %esi
	cmovle	%esi, %eax
	movl	%eax, 56(%rsp)
	movq	%rdx, 72(%rsp)
	testl	%esi, %esi
	jle	.L1805
	movl	96(%rsp), %eax
	movl	$0, 84(%rsp)
	xorl	%r15d, %r15d
	movq	$0, 40(%rsp)
	movq	192(%rsp), %rbp
	movl	%eax, %edx
	sarl	$31, %edx
	shrl	$30, %edx
	addl	%edx, %eax
	andl	$3, %eax
	subl	%edx, %eax
	addl	$1, %eax
	movl	%eax, 116(%rsp)
	jmp	.L1819
	.p2align 4,,10
	.p2align 3
.L1806:
	movl	56(%rsp), %eax
	addl	$1, %r15d
	cmpl	%eax, %r15d
	jge	.L1818
	movq	8(%rsp), %rax
	movq	24(%rax), %rcx
.L1819:
	movl	72(%rsp), %eax
	addl	%r15d, %eax
	cltd
	idivl	64(%rsp)
	movq	8(%rsp), %rax
	movslq	%edx, %rdx
	movl	(%rcx,%rdx,4), %ecx
	movq	16(%rax), %rdx
	movslq	%ecx, %rax
	leaq	(%rax,%rax,8), %rax
	salq	$4, %rax
	addq	(%rdx), %rax
	movq	%rbp, %rdx
	andq	24(%rax), %rdx
	jne	.L1806
	movq	32(%rax), %rdx
	andq	200(%rsp), %rdx
	jne	.L1806
	movq	40(%rax), %rdx
	andq	208(%rsp), %rdx
	movq	%rdx, %r14
	jne	.L1806
	movl	8(%rax), %edi
	testl	%edi, %edi
	jle	.L1872
	movslq	%edi, %rdx
	movl	224(%rsp), %esi
	movl	%r15d, 100(%rsp)
	movq	%r14, %r15
	leaq	0(,%rdx,4), %rbx
	leaq	232(%rsp), %rdx
	movl	%ecx, 88(%rsp)
	movl	228(%rsp), %r12d
	movq	%rbx, 24(%rsp)
	movl	%esi, %r14d
	xorl	%ebx, %ebx
	movq	%rdx, 32(%rsp)
	movq	%rax, 16(%rsp)
	movl	%edi, 112(%rsp)
	movq	%rbp, 104(%rsp)
	jmp	.L1808
	.p2align 4,,10
	.p2align 3
.L1873:
	movl	%r13d, %r12d
.L1808:
	movq	16(%rsp), %rax
	leal	(%r12,%r12), %edi
	movl	48(%rax,%r15), %ebp
	andl	%ebp, %edi
	call	__popcountdi2@PLT
	movl	%r12d, %edi
	shrl	%edi
	addl	%eax, %ebx
	andl	%ebp, %edi
	call	__popcountdi2@PLT
	movl	%r14d, %edi
	movl	%r12d, %r14d
	andl	%ebp, %edi
	addl	%eax, %ebx
	call	__popcountdi2@PLT
	movl	%ebp, %edi
	addl	%eax, %ebx
	movq	32(%rsp), %rax
	movl	(%rax,%r15), %r13d
	addq	$4, %r15
	andl	%r13d, %edi
	call	__popcountdi2@PLT
	addl	%eax, %ebx
	movq	24(%rsp), %rax
	cmpq	%rax, %r15
	jne	.L1873
	sall	$4, %ebx
	pxor	%xmm0, %xmm0
	movl	88(%rsp), %ecx
	movl	100(%rsp), %r15d
	cvtsi2sdl	%ebx, %xmm0
	movq	16(%rsp), %rax
	movl	112(%rsp), %edi
	movq	104(%rsp), %rbp
.L1807:
	movq	8(%rsp), %rsi
	movl	212(%rsi), %edx
	movsd	184(%rsi), %xmm3
	cmpl	$1, %edx
	je	.L1906
	cmpl	$2, %edx
	jne	.L1899
	movq	8(%rsp), %rbx
	pxor	%xmm1, %xmm1
	movq	(%rbx), %rsi
	cvtsi2sdl	112(%rbx), %xmm1
	mulsd	.LC16(%rip), %xmm1
	movq	56(%rsi), %rdx
	subq	48(%rsi), %rdx
	movabsq	$-6148914691236517205, %rsi
	sarq	$6, %rdx
	imulq	%rsi, %rdx
	testq	%rdx, %rdx
	js	.L1813
	pxor	%xmm2, %xmm2
	cvtsi2sdq	%rdx, %xmm2
.L1814:
	divsd	%xmm2, %xmm1
	subsd	.LC17(%rip), %xmm1
	addsd	%xmm1, %xmm3
.L1899:
	movsd	.LC7(%rip), %xmm1
.L1812:
	pxor	%xmm2, %xmm2
	subsd	%xmm3, %xmm1
	movl	96(%rsp), %edx
	cvtsi2sdl	12(%rax), %xmm2
	mulsd	%xmm2, %xmm1
	subsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	4(%rax), %xmm1
	addsd	%xmm1, %xmm1
	addsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	16(%rax), %xmm1
	mulsd	.LC8(%rip), %xmm1
	subsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	%edi, %xmm1
	mulsd	.LC9(%rip), %xmm1
	subsd	%xmm1, %xmm0
	testl	%edx, %edx
	je	.L1815
	movq	_ZL12random_state(%rip), %rdx
	pxor	%xmm1, %xmm1
	movq	%rdx, %rax
	salq	$7, %rax
	xorq	%rdx, %rax
	movq	%rax, %rsi
	shrq	$9, %rsi
	xorq	%rax, %rsi
	movabsq	$2361183241434822607, %rax
	movq	%rsi, %rdx
	movq	%rsi, _ZL12random_state(%rip)
	shrq	$3, %rdx
	mulq	%rdx
	movl	116(%rsp), %eax
	shrq	$4, %rdx
	imulq	$1000, %rdx, %rdx
	subq	%rdx, %rsi
	subl	$500, %esi
	imull	%eax, %esi
	cvtsi2sdl	%esi, %xmm1
	mulsd	.LC18(%rip), %xmm1
	addsd	%xmm1, %xmm0
.L1815:
	movl	%ecx, 152(%rsp)
	movq	40(%rsp), %rax
	movsd	%xmm0, 144(%rsp)
	cmpq	%rax, 176(%rsp)
	je	.L1816
	movdqa	144(%rsp), %xmm3
	addq	$16, %rax
	movups	%xmm3, -16(%rax)
	movq	%rax, 40(%rsp)
	movq	%rax, 168(%rsp)
.L1817:
	movq	8(%rsp), %rcx
	addl	$1, 84(%rsp)
	movl	84(%rsp), %eax
	cmpl	%eax, 208(%rcx)
	jg	.L1806
	.p2align 4,,10
	.p2align 3
.L1818:
	movq	160(%rsp), %r13
	movl	120(%rsp), %esi
	cmpl	%esi, 56(%rsp)
	jge	.L1820
	movq	40(%rsp), %rax
	cmpq	%rax, %r13
	je	.L1907
.L1820:
	cmpq	%r13, 40(%rsp)
	je	.L1908
	movq	40(%rsp), %rbx
	movq	%r13, %rsi
	movq	%r13, 144(%rsp)
	movq	%rbx, %rdi
	movq	%rbx, 128(%rsp)
	call	_ZSt4sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEEEvT_SB_.isra.0
	movq	%rbx, %rax
	subq	%r13, %rax
	cmpq	$192, %rax
	ja	.L1909
.L1831:
	movsd	.LC14(%rip), %xmm3
	movl	96(%rsp), %eax
	movslq	8(%r13), %r12
	movsd	%xmm3, 56(%rsp)
	testl	%eax, %eax
	jne	.L1910
.L1834:
	movq	8(%rsp), %rax
	pxor	%xmm0, %xmm0
	ucomisd	200(%rax), %xmm0
	jp	.L1835
	jne	.L1835
	movq	16(%rax), %rax
	movq	(%rax), %r15
.L1837:
	movq	40(%rsp), %rax
	cmpq	%rax, %r13
	je	.L1841
.L1840:
	movsd	.LC11(%rip), %xmm4
	movq	%r13, %rbx
	movsd	%xmm4, 24(%rsp)
	jmp	.L1851
	.p2align 4,,10
	.p2align 3
.L1912:
	movl	116(%rdx), %eax
	movl	96(%rdx), %edi
	movq	48(%rsp), %rdx
	movl	%eax, 32(%rsp)
	leal	-9(%rax), %ecx
	movslq	%ebp, %rax
	leaq	(%rax,%rax,8), %rsi
	salq	$4, %rsi
	addq	%r15, %rsi
	call	_ZNK6Packer5holesERK7VariantRKSt5arrayIjLm12EEi.isra.0
	pxor	%xmm0, %xmm0
	movsd	16(%rsp), %xmm5
	movsd	24(%rsp), %xmm4
	cvtsi2sdl	%eax, %xmm0
	mulsd	56(%rsp), %xmm0
	subsd	%xmm0, %xmm5
	comisd	%xmm5, %xmm4
	movsd	%xmm5, 16(%rsp)
	jnb	.L1844
	movq	8(%rsp), %rax
	pxor	%xmm6, %xmm6
	movsd	192(%rax), %xmm3
	ucomisd	%xmm6, %xmm3
	movsd	%xmm3, 64(%rsp)
	jp	.L1865
	je	.L1846
.L1865:
	movq	8(%rsp), %r14
	cmpl	$1, 112(%r14)
	jg	.L1911
.L1846:
	movsd	24(%rsp), %xmm4
	movsd	16(%rsp), %xmm6
	comisd	%xmm4, %xmm6
	maxsd	%xmm4, %xmm6
	cmova	%rbp, %r12
	movsd	%xmm6, 24(%rsp)
.L1844:
	addq	$16, %rbx
	cmpq	%rbx, 40(%rsp)
	je	.L1841
.L1851:
	movq	8(%rsp), %rdx
	pxor	%xmm3, %xmm3
	movsd	(%rbx), %xmm5
	movslq	8(%rbx), %rbp
	movsd	200(%rdx), %xmm7
	movsd	%xmm5, 16(%rsp)
	ucomisd	%xmm3, %xmm7
	movsd	%xmm7, 32(%rsp)
	jp	.L1842
	je	.L1912
.L1842:
	movq	8(%rsp), %rax
	pxor	%xmm5, %xmm5
	movsd	192(%rax), %xmm2
	ucomisd	%xmm5, %xmm2
	movsd	%xmm2, 64(%rsp)
	jp	.L1865
	jne	.L1865
.L1867:
	movq	8(%rsp), %rcx
	cmpl	$1, 112(%rcx)
	jle	.L1846
	movslq	%ebp, %rax
	movq	%rcx, %rdi
	leaq	(%rax,%rax,8), %rsi
	leaq	160(%rsp), %rax
	salq	$4, %rsi
	movq	%rax, 88(%rsp)
	addq	%r15, %rsi
	movq	%rcx, %r15
.LEHB29:
	call	_ZNK6Packer12future_scoreERK7Variant
	mulsd	32(%rsp), %xmm0
	movq	16(%r15), %rax
	addsd	16(%rsp), %xmm0
	movq	(%rax), %r15
	movsd	%xmm0, 16(%rsp)
	jmp	.L1846
	.p2align 4,,10
	.p2align 3
.L1906:
	movq	%rsi, %rbx
	movq	(%rsi), %rsi
	pxor	%xmm2, %xmm2
	movsd	.LC7(%rip), %xmm1
	cvtsi2sdl	112(%rbx), %xmm2
	movq	56(%rsi), %rdx
	subq	48(%rsi), %rdx
	movabsq	$-6148914691236517205, %rsi
	sarq	$6, %rdx
	imulq	%rsi, %rdx
	mulsd	%xmm1, %xmm2
	testq	%rdx, %rdx
	js	.L1810
	pxor	%xmm4, %xmm4
	cvtsi2sdq	%rdx, %xmm4
.L1811:
	divsd	%xmm4, %xmm2
	subsd	.LC15(%rip), %xmm2
	addsd	%xmm2, %xmm3
	jmp	.L1812
	.p2align 4,,10
	.p2align 3
.L1910:
	movl	%eax, %edx
	pxor	%xmm6, %xmm6
	sarl	$31, %edx
	shrl	$29, %edx
	addl	%edx, %eax
	andl	$7, %eax
	subl	%edx, %eax
	leal	(%rax,%rax,2), %eax
	leal	30(%rax,%rax), %eax
	cvtsi2sdl	%eax, %xmm6
	movsd	%xmm6, 56(%rsp)
	jmp	.L1834
	.p2align 4,,10
	.p2align 3
.L1835:
	movq	40(%rsp), %rcx
	cmpq	%rcx, %r13
	je	.L1838
	movq	8(%rsp), %rax
	movl	%r12d, 16(%rsp)
	movq	%r13, %r12
	movq	%rcx, %r14
	movq	%r13, 24(%rsp)
	movq	48(%rsp), %r13
	movl	116(%rax), %esi
	leal	-9(%rsi), %ebx
	movq	%rax, %rsi
	movq	16(%rax), %rax
	movl	96(%rsi), %ebp
	movq	(%rax), %r15
	.p2align 4,,10
	.p2align 3
.L1839:
	movslq	8(%r12), %rax
	movl	%ebx, %ecx
	movq	%r13, %rdx
	movl	%ebp, %edi
	addq	$16, %r12
	leaq	(%rax,%rax,8), %rsi
	salq	$4, %rsi
	addq	%r15, %rsi
	call	_ZNK6Packer5holesERK7VariantRKSt5arrayIjLm12EEi.isra.0
	pxor	%xmm1, %xmm1
	movsd	-16(%r12), %xmm0
	cvtsi2sdl	%eax, %xmm1
	mulsd	56(%rsp), %xmm1
	subsd	%xmm1, %xmm0
	movsd	%xmm0, -16(%r12)
	cmpq	%r14, %r12
	jne	.L1839
	movq	24(%rsp), %r13
	movq	40(%rsp), %rbx
	movslq	16(%rsp), %r12
	movq	%r13, %rsi
	movq	%rbx, %rdi
	movq	%r13, 144(%rsp)
	movq	%rbx, 128(%rsp)
	call	_ZSt4sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEEEvT_SB_.isra.0
	movq	%rbx, %rax
	subq	%r13, %rax
	cmpq	$48, %rax
	jbe	.L1840
	movq	40(%rsp), %rcx
	leaq	48(%r13), %rax
	cmpq	%rcx, %rax
	je	.L1840
	movq	%rax, 168(%rsp)
	movq	%rax, 40(%rsp)
	jmp	.L1837
	.p2align 4,,10
	.p2align 3
.L1810:
	movq	%rdx, %rsi
	andl	$1, %edx
	pxor	%xmm4, %xmm4
	shrq	%rsi
	orq	%rdx, %rsi
	cvtsi2sdq	%rsi, %xmm4
	addsd	%xmm4, %xmm4
	jmp	.L1811
	.p2align 4,,10
	.p2align 3
.L1813:
	movq	%rdx, %rsi
	andl	$1, %edx
	pxor	%xmm2, %xmm2
	shrq	%rsi
	orq	%rdx, %rsi
	cvtsi2sdq	%rsi, %xmm2
	addsd	%xmm2, %xmm2
	jmp	.L1814
	.p2align 4,,10
	.p2align 3
.L1909:
	movq	40(%rsp), %rsi
	leaq	192(%r13), %rax
	cmpq	%rsi, %rax
	je	.L1833
	movq	%rax, 168(%rsp)
.L1833:
	movq	%rax, 40(%rsp)
	jmp	.L1831
	.p2align 4,,10
	.p2align 3
.L1911:
	movslq	%ebp, %rax
	movq	%r14, %rdi
	leaq	(%rax,%rax,8), %rsi
	leaq	160(%rsp), %rax
	salq	$4, %rsi
	movq	%rax, 88(%rsp)
	addq	%r15, %rsi
	call	_ZNK6Packer13forced_blanksERK7Variant
	pxor	%xmm0, %xmm0
	movsd	16(%rsp), %xmm5
	pxor	%xmm4, %xmm4
	movsd	200(%r14), %xmm7
	cvtsi2sdl	%eax, %xmm0
	mulsd	64(%rsp), %xmm0
	movq	16(%r14), %rax
	ucomisd	%xmm4, %xmm7
	movsd	%xmm7, 32(%rsp)
	movq	(%rax), %r15
	subsd	%xmm0, %xmm5
	movsd	%xmm5, 16(%rsp)
	jp	.L1867
	je	.L1846
	jmp	.L1867
.L1838:
	movq	%r13, %rsi
	movq	%r13, %rdi
	movq	%r13, 144(%rsp)
	movq	%r13, 128(%rsp)
	call	_ZSt4sortISt16reverse_iteratorIN9__gnu_cxx17__normal_iteratorIPSt4pairIdiESt6vectorIS4_SaIS4_EEEEEEvT_SB_.isra.0
	movq	8(%rsp), %rax
	movq	16(%rax), %rax
	movq	(%rax), %r15
	.p2align 4,,10
	.p2align 3
.L1841:
	leaq	(%r12,%r12,8), %rax
	movq	8(%rsp), %r11
	salq	$4, %rax
	leaq	(%r15,%rax), %rbx
	movq	(%r11), %rdi
	movq	224(%r11), %r9
	movslq	(%rbx), %rax
	movq	%rbx, 16(%rsp)
	leaq	(%rax,%rax,2), %rdx
	salq	$2, %rax
	movq	%rdx, %rcx
	movq	8(%r11), %rdx
	movq	%rax, 24(%rsp)
	salq	$4, %rcx
	addq	48(%r11), %rax
	movq	%rcx, 32(%rsp)
	addq	(%rdx), %rcx
	movq	%rax, %rdx
	movl	(%rax), %eax
	movq	(%rcx), %rcx
	subl	$1, %eax
	movl	%eax, (%rdx)
	cltq
	movl	116(%r11), %ebp
	movslq	(%rcx,%rax,4), %rax
	leaq	(%rax,%rax,2), %rsi
	movslq	20(%rbx), %rax
	movq	%rsi, %rcx
	leaq	(%r9,%rsi,8), %rsi
	leaq	(%rax,%rax,2), %rax
	salq	$6, %rcx
	addq	48(%rdi), %rcx
	movl	120(%r11), %edi
	salq	$3, %rax
	movdqu	(%rcx,%rax), %xmm0
	movq	16(%rcx,%rax), %r8
	movslq	%ebp, %rax
	movq	%rax, %xmm1
	movslq	%edi, %rax
	movq	%rax, %xmm5
	movq	%rbx, %rax
	movq	88(%rbx), %rbx
	movq	%r8, 16(%rsi)
	punpcklqdq	%xmm5, %xmm1
	movq	96(%rax), %r14
	paddq	%xmm1, %xmm0
	movups	%xmm0, (%rsi)
	cmpq	%rbx, %r14
	je	.L1852
	movq	128(%r11), %r8
	movl	$1, %r15d
	jmp	.L1857
	.p2align 4,,10
	.p2align 3
.L1853:
	movq	%r15, %rax
	movl	%ebp, %ecx
	addq	$8, %rbx
	salq	%cl, %rax
	orq	%rax, (%rdx)
	movq	8(%rsp), %rax
	cmpq	%rbx, %r14
	je	.L1913
	movl	116(%rax), %ebp
.L1857:
	movq	8(%rsp), %rsi
	movl	4(%rbx), %eax
	addl	(%rbx), %ebp
	addl	%edi, %eax
	imull	100(%rsi), %eax
	movl	%ebp, %edx
	sarl	$6, %edx
	addl	%edx, %eax
	movslq	%eax, %r12
	salq	$3, %r12
	cmpb	$0, 176(%rsi)
	leaq	(%r8,%r12), %rdx
	movq	(%rdx), %rcx
	je	.L1853
	movl	%eax, 144(%rsp)
	movq	%rsi, %rax
	movq	160(%rsi), %rsi
	movq	%rcx, 152(%rsp)
	cmpq	168(%rax), %rsi
	je	.L1854
	movdqa	144(%rsp), %xmm2
	addq	$16, %rsi
	movups	%xmm2, -16(%rsi)
	movq	%rsi, 160(%rax)
	jmp	.L1853
	.p2align 4,,10
	.p2align 3
.L1913:
	movq	24(%rsp), %rdx
	addq	48(%rax), %rdx
.L1852:
	movq	16(%rsp), %rax
	movq	8(%rsp), %rsi
	addl	8(%rax), %edi
	movl	220(%rsi), %eax
	cmpl	%eax, %edi
	cmovl	%eax, %edi
	movl	%edi, 220(%rsi)
	movl	(%rdx), %eax
	testl	%eax, %eax
	je	.L1858
.L1859:
	movq	8(%rsp), %rax
	subl	$1, 112(%rax)
.L1829:
	movq	176(%rsp), %rsi
	movq	%r13, %rdi
	subq	%r13, %rsi
	call	_ZdlPvm@PLT
.L1830:
	movl	$1, %eax
	jmp	.L1788
	.p2align 4,,10
	.p2align 3
.L1816:
	leaq	160(%rsp), %rax
	movq	40(%rsp), %rsi
	leaq	144(%rsp), %rdx
	movq	%rax, %rdi
	movq	%rax, 88(%rsp)
	call	_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	movq	168(%rsp), %rax
	movq	%rax, 40(%rsp)
	jmp	.L1817
	.p2align 4,,10
	.p2align 3
.L1854:
	movq	8(%rsp), %rax
	leaq	160(%rsp), %rcx
	leaq	144(%rsp), %rdx
	movq	%rcx, 88(%rsp)
	leaq	152(%rax), %rdi
	call	_ZNSt6vectorISt4pairIiyESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	movq	8(%rsp), %rax
	movq	128(%rax), %r8
	movl	120(%rax), %edi
	leaq	(%r8,%r12), %rdx
	jmp	.L1853
	.p2align 4,,10
	.p2align 3
.L1872:
	pxor	%xmm0, %xmm0
	jmp	.L1807
	.p2align 4,,10
	.p2align 3
.L1858:
	movq	8(%rsp), %r11
	movq	32(%rsp), %rsi
	movq	8(%r11), %rax
	addq	(%rax), %rsi
	movq	24(%rsi), %rdx
	movq	32(%rsi), %r9
	cmpq	%r9, %rdx
	je	.L1859
	movq	72(%r11), %rdi
	movq	24(%r11), %r10
	movq	32(%r11), %rcx
	.p2align 4,,10
	.p2align 3
.L1860:
	movslq	(%rdx), %rax
	subq	$4, %rcx
	addq	$4, %rdx
	movslq	(%rdi,%rax,4), %r8
	movslq	(%rcx), %rax
	movl	%eax, (%r10,%r8,4)
	movl	%r8d, (%rdi,%rax,4)
	movq	%rcx, 32(%r11)
	cmpq	%r9, %rdx
	jne	.L1860
	jmp	.L1859
.L1907:
	movq	8(%rsp), %rax
	movq	24(%rax), %rcx
.L1864:
	movq	8(%rsp), %rax
	movq	200(%rsp), %rdi
	movq	208(%rsp), %r8
	movl	64(%rsp), %r10d
	movq	16(%rax), %rax
	movl	56(%rsp), %r9d
	movq	72(%rsp), %r11
	movq	(%rax), %rsi
.L1824:
	leal	(%r9,%r11), %eax
	movq	%rbp, %rbx
	cltd
	idivl	%r10d
	movslq	%edx, %rdx
	movslq	(%rcx,%rdx,4), %rax
	movq	%rax, %rdx
	leaq	(%rax,%rax,8), %rax
	salq	$4, %rax
	addq	%rsi, %rax
	andq	24(%rax), %rbx
	jne	.L1821
	movq	%rdi, %rbx
	andq	32(%rax), %rbx
	jne	.L1821
	movq	%r8, %rbx
	andq	40(%rax), %rbx
	jne	.L1821
	movq	.LC19(%rip), %rax
	movl	%edx, 152(%rsp)
	movq	%rax, 144(%rsp)
	movq	40(%rsp), %rax
	cmpq	176(%rsp), %rax
	je	.L1822
	movdqa	144(%rsp), %xmm3
	addq	$16, %rax
	movups	%xmm3, -16(%rax)
	movq	%rax, 40(%rsp)
	movq	%rax, 168(%rsp)
.L1900:
	movq	160(%rsp), %r13
	jmp	.L1820
	.p2align 4,,10
	.p2align 3
.L1821:
	addl	$1, %r9d
	cmpl	%r9d, %r10d
	jg	.L1824
.L1902:
	movq	168(%rsp), %rax
	movq	%rax, 40(%rsp)
	jmp	.L1900
.L1908:
	movq	8(%rsp), %rcx
	movl	116(%rcx), %ebx
	movl	120(%rcx), %eax
	imull	100(%rcx), %eax
	movq	128(%rcx), %r10
	movl	%ebx, %edx
	sarl	$6, %edx
	leal	(%rax,%rdx), %r14d
	movslq	%r14d, %rbp
	salq	$3, %rbp
	addq	%rbp, %r10
	movq	(%r10), %r9
.L1863:
	movq	8(%rsp), %rax
	cmpb	$0, 176(%rax)
	jne	.L1914
.L1826:
	btsq	%rbx, %r9
	movq	%r9, (%r10)
	testq	%r13, %r13
	je	.L1830
	jmp	.L1829
	.p2align 4,,10
	.p2align 3
.L1914:
	movl	%r14d, 128(%rsp)
	movq	160(%rax), %rsi
	movq	%r9, 136(%rsp)
	cmpq	168(%rax), %rsi
	je	.L1827
	movdqa	128(%rsp), %xmm5
	addq	$16, %rsi
	movups	%xmm5, -16(%rsi)
	movq	%rsi, 160(%rax)
.L1828:
	movq	(%r10), %r9
	jmp	.L1826
.L1805:
	movl	56(%rsp), %eax
	xorl	%r13d, %r13d
	cmpl	%eax, 120(%rsp)
	jle	.L1863
	movq	$0, 40(%rsp)
	movq	192(%rsp), %rbp
	jmp	.L1864
.L1822:
	leaq	160(%rsp), %rax
	movq	40(%rsp), %rsi
	leaq	144(%rsp), %rdx
	movq	%rax, %rdi
	movq	%rax, 88(%rsp)
	call	_ZNSt6vectorISt4pairIdiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	jmp	.L1902
.L1827:
	movq	8(%rsp), %r15
	leaq	160(%rsp), %rax
	leaq	128(%rsp), %rdx
	movq	%rax, 88(%rsp)
	leaq	152(%r15), %rdi
	call	_ZNSt6vectorISt4pairIiyESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
.LEHE29:
	movq	128(%r15), %r10
	addq	%rbp, %r10
	jmp	.L1828
.L1861:
	movq	88(%rsp), %rdi
	call	_ZNSt6vectorISt4pairIdiESaIS1_EED1Ev
	movq	280(%rsp), %rax
	subq	%fs:40, %rax
	je	.L1862
.L1901:
	call	__stack_chk_fail@PLT
.L1876:
	endbr64
	movq	%rax, %rbx
	jmp	.L1861
.L1862:
	movq	%rbx, %rdi
.LEHB30:
	call	_Unwind_Resume@PLT
.LEHE30:
	.cfi_endproc
.LFE10041:
	.section	.gcc_except_table._ZN6Packer4stepEi,"aG",@progbits,_ZN6Packer4stepEi,comdat
.LLSDA10041:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE10041-.LLSDACSB10041
.LLSDACSB10041:
	.uleb128 .LEHB29-.LFB10041
	.uleb128 .LEHE29-.LEHB29
	.uleb128 .L1876-.LFB10041
	.uleb128 0
	.uleb128 .LEHB30-.LFB10041
	.uleb128 .LEHE30-.LEHB30
	.uleb128 0
	.uleb128 0
.LLSDACSE10041:
	.section	.text._ZN6Packer4stepEi,"axG",@progbits,_ZN6Packer4stepEi,comdat
	.size	_ZN6Packer4stepEi, .-_ZN6Packer4stepEi
	.section	.text._ZN6Packer3runEdixddd,"axG",@progbits,_ZN6Packer3runEdixddd,comdat
	.align 2
	.p2align 4
	.weak	_ZN6Packer3runEdixddd
	.type	_ZN6Packer3runEdixddd, @function
_ZN6Packer3runEdixddd:
.LFB10086:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA10086
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	unpcklpd	%xmm3, %xmm2
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movl	%edx, %r12d
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rsi, %rbx
	subq	$136, %rsp
	.cfi_def_cfa_offset 192
	movq	%rcx, 48(%rsp)
	movsd	%xmm0, (%rsp)
	movsd	%xmm1, 8(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 120(%rsp)
	xorl	%eax, %eax
	movups	%xmm2, 184(%rsi)
	cmpl	112(%rsi), %edx
	jge	.L1919
	.p2align 4,,10
	.p2align 3
.L1916:
	xorl	%esi, %esi
	movq	%rbx, %rdi
.LEHB31:
	call	_ZN6Packer4stepEi
	cmpl	%r12d, 112(%rbx)
	jg	.L1916
.L1919:
	call	clock@PLT
	pxor	%xmm0, %xmm0
	cvtsi2sdq	%rax, %xmm0
	divsd	.LC20(%rip), %xmm0
	addsd	8(%rsp), %xmm0
	minsd	(%rsp), %xmm0
	leaq	24(%rbx), %rax
	movq	%rax, 8(%rsp)
	movq	32(%rbx), %rax
	subq	24(%rbx), %rax
	movsd	%xmm0, (%rsp)
	movq	%rax, %r12
	je	.L1989
	movabsq	$9223372036854775804, %rax
	cmpq	%r12, %rax
	jb	.L1990
	movq	%r12, %rdi
	call	_Znwm@PLT
.LEHE31:
	movq	24(%rbx), %rsi
	movq	32(%rbx), %r13
	movq	%rax, 64(%rsp)
	movq	%rax, %rcx
	leaq	(%rax,%r12), %rax
	subq	%rsi, %r13
	movq	%rax, 80(%rsp)
	cmpq	$4, %r13
	jle	.L1924
	movq	%rcx, %rdi
	movq	%r13, %rdx
	call	memmove@PLT
	movq	%rax, %rcx
.L1921:
	movq	48(%rbx), %r8
	movq	56(%rbx), %r12
	addq	%r13, %rcx
	leaq	48(%rbx), %rax
	pxor	%xmm0, %xmm0
	movq	%rcx, 72(%rsp)
	movq	%rax, 24(%rsp)
	movq	$0, 112(%rsp)
	movaps	%xmm0, 96(%rsp)
	subq	%r8, %r12
	je	.L1991
	movabsq	$9223372036854775804, %rax
	cmpq	%r12, %rax
	jb	.L1992
	movq	%r12, %rdi
.LEHB32:
	call	_Znwm@PLT
.LEHE32:
	movq	48(%rbx), %r8
	movq	56(%rbx), %r13
	addq	%rax, %r12
	movq	%rax, 96(%rsp)
	movq	%r12, 112(%rsp)
	movq	%rax, %rcx
	subq	%r8, %r13
	cmpq	$4, %r13
	jle	.L1930
	movq	%r8, %rsi
	movq	%r13, %rdx
	movq	%rax, %rdi
	movq	%r8, 16(%rsp)
	call	memmove@PLT
	movq	16(%rsp), %r8
	movq	%rax, %rcx
.L1927:
	movl	120(%rbx), %eax
	movq	128(%rbx), %r12
	addq	%r13, %rcx
	xorl	%r14d, %r14d
	movq	136(%rbx), %rdx
	movq	112(%rbx), %r15
	movq	%rcx, 104(%rsp)
	movl	%eax, 36(%rsp)
	movl	220(%rbx), %r13d
	cmpq	%rdx, %r12
	je	.L1932
	movq	%r8, 16(%rsp)
	movq	%rbx, 40(%rsp)
	movq	%r12, %rbx
	movq	%rdx, %r12
	.p2align 4,,10
	.p2align 3
.L1933:
	movq	(%rbx), %rdi
	addq	$8, %rbx
	call	__popcountdi2@PLT
	addl	%eax, %r14d
	cmpq	%rbx, %r12
	jne	.L1933
	movq	16(%rsp), %r8
	movq	40(%rsp), %rbx
.L1932:
	movq	8(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rdx
	movabsq	$-6148914691236517205, %rax
	subq	%rcx, %rdx
	sarq	$4, %rdx
	imulq	%rax, %rdx
	testl	%edx, %edx
	jle	.L1934
	movq	16(%rbx), %rax
	subl	$1, %edx
	addq	$24, %rcx
	xorl	%edi, %edi
	movq	(%rax), %r9
	movq	%r8, %rax
	leaq	4(%r8,%rdx,4), %r8
	.p2align 4,,10
	.p2align 3
.L1935:
	movq	(%rcx), %rdx
	addq	$4, %rax
	addq	$48, %rcx
	movslq	(%rdx), %rdx
	leaq	(%rdx,%rdx,8), %rdx
	salq	$4, %rdx
	movl	4(%r9,%rdx), %edx
	imull	-4(%rax), %edx
	addl	%edx, %edi
	cmpq	%rax, %r8
	jne	.L1935
	addl	%edi, %r14d
.L1934:
	movl	96(%rbx), %ecx
	pxor	%xmm0, %xmm0
	movq	$0, 24(%rbp)
	movups	%xmm0, 8(%rbp)
	leal	-1(%rcx,%r14), %eax
	leaq	64(%rsp), %r14
	cltd
	idivl	%ecx
	cmpl	%r13d, %eax
	cmovl	%r13d, %eax
	xorl	%r12d, %r12d
	movl	%eax, 40(%rsp)
	movq	.LC21(%rip), %rax
	movq	%rax, 0(%rbp)
	leaq	8(%rbp), %rax
	movq	%rax, 56(%rsp)
	leaq	96(%rsp), %rax
	movb	$1, 176(%rbx)
	movq	%rax, 16(%rsp)
	.p2align 4,,10
	.p2align 3
.L1936:
	movl	112(%rbx), %eax
	testl	%eax, %eax
	jne	.L1937
.L1941:
	movq	216(%rbx), %xmm0
	movslq	0(%rbp), %rdx
	pshufd	$0xe5, %xmm0, %xmm5
	movd	%xmm0, %eax
	movd	%xmm5, %ecx
	testl	%edx, %edx
	je	.L1938
	movslq	4(%rbp), %rsi
	cltq
	movslq	%ecx, %rcx
	imulq	%rcx, %rax
	imulq	%rsi, %rdx
	cmpq	%rax, %rdx
	jle	.L1942
.L1938:
	movq	56(%rsp), %rdi
	movq	%xmm0, 0(%rbp)
	leaq	224(%rbx), %rsi
.LEHB33:
	call	_ZNSt6vectorI9PlacementSaIS0_EEaSERKS2_.isra.0
.L1942:
	movq	160(%rbx), %rax
	movq	152(%rbx), %rsi
	cmpq	%rsi, %rax
	je	.L1943
	movq	128(%rbx), %rdi
	.p2align 4,,10
	.p2align 3
.L1944:
	movq	-8(%rax), %rcx
	movslq	-16(%rax), %rdx
	subq	$16, %rax
	movq	%rcx, (%rdi,%rdx,8)
	cmpq	%rsi, %rax
	jne	.L1944
	movq	%rax, 160(%rbx)
.L1943:
	movq	8(%rsp), %rdi
	movq	%r14, %rsi
	call	_ZNSt6vectorIiSaIiEEaSERKS1_.isra.0
	movq	16(%rsp), %rsi
	movq	24(%rsp), %rdi
	call	_ZNSt6vectorIiSaIiEEaSERKS1_.isra.0
	movq	24(%rbx), %rcx
	movq	32(%rbx), %rax
	subq	%rcx, %rax
	sarq	$2, %rax
	testl	%eax, %eax
	jle	.L1949
	movq	72(%rbx), %rdi
	leal	-1(%rax), %esi
	xorl	%eax, %eax
	.p2align 4,,10
	.p2align 3
.L1948:
	movslq	(%rcx,%rax,4), %rdx
	movl	%eax, (%rdi,%rdx,4)
	movq	%rax, %rdx
	addq	$1, %rax
	cmpq	%rsi, %rdx
	jne	.L1948
.L1949:
	movl	36(%rsp), %eax
	movq	%r15, 112(%rbx)
	movl	%r13d, 220(%rbx)
	movl	%eax, 120(%rbx)
	testl	%r12d, %r12d
	jne	.L1993
	movslq	4(%rbp), %rcx
	movslq	0(%rbp), %rdx
	pxor	%xmm0, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdq	48(%rsp), %xmm0
	mulsd	.LC22(%rip), %xmm0
	imulq	%rcx, %rdx
	movq	%rcx, %rax
	cvtsi2sdq	%rdx, %xmm1
	comisd	%xmm0, %xmm1
	ja	.L1954
	cmpl	%ecx, 40(%rsp)
	jge	.L1954
	subl	$1, %eax
	movl	$1, %r12d
	movl	%eax, 108(%rbx)
.L1955:
	call	clock@PLT
	movsd	(%rsp), %xmm4
	pxor	%xmm0, %xmm0
	cvtsi2sdq	%rax, %xmm0
	divsd	.LC20(%rip), %xmm0
	comisd	%xmm0, %xmm4
	ja	.L1936
.L1954:
	movq	96(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L1953
	movq	112(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L1953:
	movq	64(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L1915
	movq	80(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L1915:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1988
	addq	$136, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%rbp, %rax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1993:
	.cfi_restore_state
	movl	4(%rbp), %eax
	movl	40(%rsp), %edi
	cmpl	%edi, %eax
	jle	.L1954
	subl	$1, %eax
	addl	$1, %r12d
	movl	%eax, 108(%rbx)
	cmpl	$9999, %r12d
	jle	.L1955
	jmp	.L1954
	.p2align 4,,10
	.p2align 3
.L1937:
	movl	%r12d, %esi
	movq	%rbx, %rdi
	call	_ZN6Packer4stepEi
.LEHE33:
	movl	112(%rbx), %edx
	testb	%al, %al
	jne	.L1936
	testl	%edx, %edx
	jne	.L1942
	jmp	.L1941
	.p2align 4,,10
	.p2align 3
.L1989:
	movq	$0, 64(%rsp)
	xorl	%r13d, %r13d
	xorl	%ecx, %ecx
	movq	$0, 80(%rsp)
	jmp	.L1921
.L1991:
	movq	$0, 96(%rsp)
	xorl	%r13d, %r13d
	xorl	%ecx, %ecx
	movq	$0, 112(%rsp)
	jmp	.L1927
.L1990:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1988
.LEHB34:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE34:
.L1924:
	jne	.L1921
	movl	(%rsi), %eax
	movl	%eax, (%rcx)
	jmp	.L1921
.L1992:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L1988
.LEHB35:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE35:
.L1930:
	jne	.L1927
	movl	(%r8), %eax
	movl	%eax, (%rcx)
	jmp	.L1927
.L1957:
	movq	56(%rsp), %rdi
	call	_ZNSt6vectorI9PlacementSaIS0_EED1Ev
	movq	16(%rsp), %rdi
	call	_ZNSt6vectorIiSaIiEED1Ev
.L1958:
	movq	%r14, %rdi
	call	_ZNSt6vectorIiSaIiEED1Ev
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	je	.L1959
.L1988:
	call	__stack_chk_fail@PLT
.L1963:
	endbr64
	movq	%rax, %rbx
	jmp	.L1957
.L1962:
	endbr64
	movq	%rax, %rbx
	leaq	64(%rsp), %r14
	jmp	.L1958
.L1959:
	movq	%rbx, %rdi
.LEHB36:
	call	_Unwind_Resume@PLT
.LEHE36:
	.cfi_endproc
.LFE10086:
	.section	.gcc_except_table._ZN6Packer3runEdixddd,"aG",@progbits,_ZN6Packer3runEdixddd,comdat
.LLSDA10086:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE10086-.LLSDACSB10086
.LLSDACSB10086:
	.uleb128 .LEHB31-.LFB10086
	.uleb128 .LEHE31-.LEHB31
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB32-.LFB10086
	.uleb128 .LEHE32-.LEHB32
	.uleb128 .L1962-.LFB10086
	.uleb128 0
	.uleb128 .LEHB33-.LFB10086
	.uleb128 .LEHE33-.LEHB33
	.uleb128 .L1963-.LFB10086
	.uleb128 0
	.uleb128 .LEHB34-.LFB10086
	.uleb128 .LEHE34-.LEHB34
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB35-.LFB10086
	.uleb128 .LEHE35-.LEHB35
	.uleb128 .L1962-.LFB10086
	.uleb128 0
	.uleb128 .LEHB36-.LFB10086
	.uleb128 .LEHE36-.LEHB36
	.uleb128 0
	.uleb128 0
.LLSDACSE10086:
	.section	.text._ZN6Packer3runEdixddd,"axG",@progbits,_ZN6Packer3runEdixddd,comdat
	.size	_ZN6Packer3runEdixddd, .-_ZN6Packer3runEdixddd
	.section	.text._ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,"axG",@progbits,_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.type	_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, @function
_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_:
.LFB12924:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdx, %rbx
	movabsq	$-1229782938247303441, %rdx
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	8(%rdi), %r14
	movq	(%rdi), %r13
	movq	%r14, %rax
	subq	%r13, %rax
	sarq	$3, %rax
	imulq	%rdx, %rax
	movabsq	$76861433640456465, %rdx
	cmpq	%rdx, %rax
	je	.L2019
	movq	%rsi, %rdx
	movq	%rdi, %r12
	movq	%rsi, %r15
	subq	%r13, %rdx
	cmpq	%r14, %r13
	je	.L2020
	leaq	(%rax,%rax), %rsi
	cmpq	%rax, %rsi
	jb	.L2008
	testq	%rsi, %rsi
	jne	.L2021
	movq	$0, 16(%rsp)
	movl	$120, %ebp
	movq	$0, 8(%rsp)
.L2000:
	movq	8(%rsp), %rcx
	movdqu	(%rbx), %xmm7
	pxor	%xmm0, %xmm0
	movups	%xmm0, (%rbx)
	leaq	(%rcx,%rdx), %rax
	movq	64(%rbx), %rdx
	movq	$0, 64(%rbx)
	movups	%xmm7, (%rax)
	movdqu	16(%rbx), %xmm7
	movq	%rdx, 64(%rax)
	movq	72(%rbx), %rdx
	movups	%xmm7, 16(%rax)
	movdqu	32(%rbx), %xmm7
	movq	%rdx, 72(%rax)
	movq	96(%rbx), %rdx
	movups	%xmm7, 32(%rax)
	movdqu	48(%rbx), %xmm7
	movq	%rdx, 96(%rax)
	movq	104(%rbx), %rdx
	movups	%xmm7, 48(%rax)
	movdqu	80(%rbx), %xmm7
	movq	%rdx, 104(%rax)
	movl	112(%rbx), %edx
	movq	$0, 96(%rbx)
	movl	%edx, 112(%rax)
	movups	%xmm0, 16(%rbx)
	movups	%xmm0, 32(%rbx)
	movups	%xmm0, 48(%rbx)
	movups	%xmm7, 80(%rax)
	movups	%xmm0, 80(%rbx)
	cmpq	%r13, %r15
	je	.L2001
	movq	%r13, %rbx
	movq	%rcx, %rbp
	jmp	.L2003
	.p2align 4,,10
	.p2align 3
.L2010:
	movq	%rax, %rbp
.L2003:
	movq	(%rbx), %rax
	movdqu	80(%rbx), %xmm1
	movq	%rax, 0(%rbp)
	movq	8(%rbx), %rax
	movups	%xmm0, (%rbx)
	movq	%rax, 8(%rbp)
	movq	16(%rbx), %rax
	movq	$0, 16(%rbx)
	movq	%rax, 16(%rbp)
	movq	24(%rbx), %rax
	movq	%rax, 24(%rbp)
	movq	32(%rbx), %rax
	movq	%rax, 32(%rbp)
	movq	40(%rbx), %rax
	movq	%rax, 40(%rbp)
	movq	48(%rbx), %rax
	movq	(%rbx), %rdi
	movq	%rax, 48(%rbp)
	movq	56(%rbx), %rax
	movq	%rax, 56(%rbp)
	movq	64(%rbx), %rax
	movq	%rax, 64(%rbp)
	movq	72(%rbx), %rax
	movups	%xmm1, 80(%rbp)
	movq	%rax, 72(%rbp)
	movq	96(%rbx), %rax
	movq	%rax, 96(%rbp)
	movq	104(%rbx), %rax
	movq	%rax, 104(%rbp)
	movl	112(%rbx), %eax
	movl	%eax, 112(%rbp)
	testq	%rdi, %rdi
	je	.L2002
	movq	16(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	pxor	%xmm0, %xmm0
.L2002:
	addq	$120, %rbx
	leaq	120(%rbp), %rax
	cmpq	%rbx, %r15
	jne	.L2010
	addq	$240, %rbp
.L2001:
	cmpq	%r14, %r15
	je	.L2004
	movq	%r15, %rax
	movq	%rbp, %rdx
	.p2align 4,,10
	.p2align 3
.L2005:
	movq	64(%rax), %rsi
	movdqu	(%rax), %xmm2
	addq	$120, %rax
	addq	$120, %rdx
	movdqu	-104(%rax), %xmm3
	movdqu	-88(%rax), %xmm4
	movdqu	-72(%rax), %xmm5
	movdqu	-40(%rax), %xmm6
	movq	%rsi, -56(%rdx)
	movq	-48(%rax), %rsi
	movups	%xmm2, -120(%rdx)
	movups	%xmm3, -104(%rdx)
	movq	%rsi, -48(%rdx)
	movq	-24(%rax), %rsi
	movups	%xmm4, -88(%rdx)
	movq	%rsi, -24(%rdx)
	movq	-16(%rax), %rsi
	movups	%xmm5, -72(%rdx)
	movq	%rsi, -16(%rdx)
	movl	-8(%rax), %esi
	movups	%xmm6, -40(%rdx)
	movl	%esi, -8(%rdx)
	cmpq	%rax, %r14
	jne	.L2005
	movabsq	$1076060070966390511, %rdx
	movq	%r14, %r8
	subq	%r15, %r8
	leaq	-120(%r8), %rax
	shrq	$3, %rax
	imulq	%rdx, %rax
	movabsq	$2305843009213693951, %rdx
	andq	%rdx, %rax
	addq	$1, %rax
	movq	%rax, %rdx
	salq	$4, %rdx
	subq	%rax, %rdx
	leaq	0(%rbp,%rdx,8), %rbp
.L2004:
	testq	%r13, %r13
	je	.L2006
	movq	16(%r12), %rsi
	movq	%r13, %rdi
	subq	%r13, %rsi
	call	_ZdlPvm@PLT
.L2006:
	movq	8(%rsp), %rax
	movq	%rbp, 8(%r12)
	movq	%rax, (%r12)
	movq	16(%rsp), %rax
	movq	%rax, 16(%r12)
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2008:
	.cfi_restore_state
	movabsq	$9223372036854775800, %rbp
.L1999:
	movq	%rbp, %rdi
	movq	%rdx, 24(%rsp)
	call	_Znwm@PLT
	movq	24(%rsp), %rdx
	leaq	(%rax,%rbp), %rcx
	movq	%rax, 8(%rsp)
	leaq	120(%rax), %rbp
	movq	%rcx, 16(%rsp)
	jmp	.L2000
	.p2align 4,,10
	.p2align 3
.L2020:
	addq	$1, %rax
	jc	.L2008
	movabsq	$76861433640456465, %rsi
	cmpq	%rsi, %rax
	cmova	%rsi, %rax
	movq	%rax, %rcx
	salq	$4, %rcx
	subq	%rax, %rcx
	leaq	0(,%rcx,8), %rbp
	jmp	.L1999
.L2021:
	movabsq	$76861433640456465, %rax
	cmpq	%rax, %rsi
	cmova	%rax, %rsi
	movq	%rsi, %rax
	salq	$4, %rax
	subq	%rsi, %rax
	leaq	0(,%rax,8), %rbp
	jmp	.L1999
.L2019:
	leaq	.LC0(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE12924:
	.size	_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, .-_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.section	.text._ZNSt6vectorIN10BeamPacker5TrailESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,"axG",@progbits,_ZNSt6vectorIN10BeamPacker5TrailESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorIN10BeamPacker5TrailESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.type	_ZNSt6vectorIN10BeamPacker5TrailESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, @function
_ZNSt6vectorIN10BeamPacker5TrailESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_:
.LFB12953:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdx, %r15
	movabsq	$288230376151711743, %rdx
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	8(%rdi), %r12
	movq	(%rdi), %r13
	movq	%r12, %rax
	subq	%r13, %rax
	sarq	$5, %rax
	cmpq	%rdx, %rax
	je	.L2044
	movq	%rsi, %rdx
	movq	%rdi, %rbp
	movq	%rsi, %r14
	subq	%r13, %rdx
	cmpq	%r12, %r13
	je	.L2045
	leaq	(%rax,%rax), %rcx
	cmpq	%rax, %rcx
	jb	.L2037
	testq	%rcx, %rcx
	jne	.L2046
	xorl	%ebx, %ebx
	xorl	%ecx, %ecx
.L2028:
	movdqu	(%r15), %xmm0
	movdqu	16(%r15), %xmm1
	leaq	32(%rcx,%rdx), %r8
	subq	%r14, %r12
	leaq	(%r8,%r12), %r15
	movups	%xmm0, (%rcx,%rdx)
	movups	%xmm1, 16(%rcx,%rdx)
	testq	%rdx, %rdx
	jg	.L2047
	testq	%r12, %r12
	jle	.L2032
	movq	%r12, %rdx
	movq	%r14, %rsi
	movq	%r8, %rdi
	movq	%rcx, (%rsp)
	call	memcpy@PLT
	movq	(%rsp), %rcx
.L2032:
	testq	%r13, %r13
	jne	.L2031
.L2034:
	movq	%rcx, 0(%rbp)
	movq	%r15, 8(%rbp)
	movq	%rbx, 16(%rbp)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2037:
	.cfi_restore_state
	movabsq	$9223372036854775776, %rbx
.L2027:
	movq	%rbx, %rdi
	movq	%rdx, (%rsp)
	call	_Znwm@PLT
	movq	(%rsp), %rdx
	movq	%rax, %rcx
	addq	%rax, %rbx
	jmp	.L2028
	.p2align 4,,10
	.p2align 3
.L2047:
	movq	%rcx, %rdi
	movq	%r13, %rsi
	movq	%r8, (%rsp)
	call	memmove@PLT
	movq	%rax, %rcx
	testq	%r12, %r12
	jg	.L2048
.L2031:
	movq	16(%rbp), %rsi
	movq	%r13, %rdi
	movq	%rcx, (%rsp)
	subq	%r13, %rsi
	call	_ZdlPvm@PLT
	movq	(%rsp), %rcx
	jmp	.L2034
	.p2align 4,,10
	.p2align 3
.L2045:
	addq	$1, %rax
	jc	.L2037
	movabsq	$288230376151711743, %rcx
	cmpq	%rcx, %rax
	movq	%rcx, %rbx
	cmovbe	%rax, %rbx
	salq	$5, %rbx
	jmp	.L2027
	.p2align 4,,10
	.p2align 3
.L2048:
	movq	(%rsp), %rdi
	movq	%r12, %rdx
	movq	%r14, %rsi
	movq	%rax, 8(%rsp)
	call	memcpy@PLT
	movq	8(%rsp), %rcx
	jmp	.L2031
.L2046:
	movabsq	$288230376151711743, %rax
	cmpq	%rax, %rcx
	cmova	%rax, %rcx
	movq	%rcx, %rbx
	salq	$5, %rbx
	jmp	.L2027
.L2044:
	leaq	.LC0(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE12953:
	.size	_ZNSt6vectorIN10BeamPacker5TrailESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, .-_ZNSt6vectorIN10BeamPacker5TrailESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.section	.text._ZN10BeamPacker5placeERNS_5StateEi,"axG",@progbits,_ZN10BeamPacker5placeERNS_5StateEi,comdat
	.align 2
	.p2align 4
	.weak	_ZN10BeamPacker5placeERNS_5StateEi
	.type	_ZN10BeamPacker5placeERNS_5StateEi, @function
_ZN10BeamPacker5placeERNS_5StateEi:
.LFB10134:
	.cfi_startproc
	endbr64
	movabsq	$-7046029254386353131, %r9
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	movslq	%edx, %rdx
	movabsq	$-4658895280553007687, %r8
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	leaq	(%rdx,%rdx,8), %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	%rsi, %rbx
	salq	$4, %rbp
	subq	$48, %rsp
	.cfi_def_cfa_offset 96
	movq	(%rdi), %rsi
	movq	%fs:40, %rax
	movq	%rax, 40(%rsp)
	xorl	%eax, %eax
	movq	48(%rbx), %rax
	addq	24(%rsi), %rbp
	movslq	0(%rbp), %r14
	leaq	(%r14,%r14), %r13
	movq	%r14, %r10
	addq	%r13, %rax
	salq	$32, %r10
	addq	%r14, %r13
	movzwl	(%rax), %edi
	salq	$4, %r13
	movq	%rdi, %rdx
	orq	%r10, %rdi
	addq	%r9, %rdi
	subl	$1, %edx
	movq	%rdi, %rcx
	shrq	$30, %rcx
	xorq	%rdi, %rcx
	movabsq	$-7723592293110705685, %rdi
	imulq	%r8, %rcx
	movq	%rcx, %r11
	shrq	$27, %r11
	xorq	%rcx, %r11
	movq	120(%rbx), %rcx
	imulq	%rdi, %r11
	xorq	%r11, %rcx
	shrq	$31, %r11
	xorq	%r11, %rcx
	movq	(%rsi), %r11
	movw	%dx, (%rax)
	movzwl	%dx, %eax
	addq	%r13, %r11
	movq	(%r11), %rdx
	movl	(%rdx,%rax,4), %edx
	orq	%r10, %rax
	addq	%r9, %rax
	movq	%rax, %r9
	movd	%edx, %xmm3
	shrq	$30, %r9
	xorq	%r9, %rax
	imulq	%rax, %r8
	movq	%r8, %rax
	shrq	$27, %rax
	xorq	%r8, %rax
	imulq	%rdi, %rax
	movl	80(%rbx), %edi
	xorq	%rax, %rcx
	shrq	$31, %rax
	xorq	%rax, %rcx
	movslq	%edx, %rax
	movq	%rcx, 120(%rbx)
	movslq	20(%rbp), %rcx
	leaq	(%rax,%rax,2), %rax
	salq	$6, %rax
	addq	48(%rsi), %rax
	leaq	(%rcx,%rcx,2), %rcx
	salq	$3, %rcx
	movq	16(%rax,%rcx), %rsi
	movdqu	(%rax,%rcx), %xmm1
	movslq	76(%rbx), %rax
	movq	%rax, %xmm0
	movslq	%edi, %rax
	movq	%rax, %xmm2
	punpcklqdq	%xmm2, %xmm0
	paddq	%xmm0, %xmm1
	movd	100(%rbx), %xmm0
	punpckldq	%xmm3, %xmm0
	movq	%xmm0, (%rsp)
	movq	%rsi, 24(%rsp)
	movq	40(%r12), %rsi
	movups	%xmm1, 8(%rsp)
	cmpq	48(%r12), %rsi
	je	.L2050
	movdqa	(%rsp), %xmm4
	movdqa	16(%rsp), %xmm5
	addq	$32, %rsi
	movups	%xmm4, -32(%rsi)
	movups	%xmm5, -16(%rsi)
	movq	%rsi, 40(%r12)
.L2051:
	movq	8(%rbx), %rdx
	subq	32(%r12), %rsi
	movq	(%rbx), %rcx
	sarq	$5, %rsi
	movq	%rdx, %rax
	subl	$1, %esi
	subq	%rcx, %rax
	movl	%esi, 100(%rbx)
	leal	11(%rdi), %esi
	sarq	$3, %rax
	cmpl	%eax, %esi
	jge	.L2066
.L2053:
	movq	88(%rbp), %rax
	movq	96(%rbp), %r8
	cmpq	%rax, %r8
	je	.L2060
	movq	(%rbx), %rsi
	movl	76(%rbx), %r10d
	movl	$1, %r9d
	.p2align 4,,10
	.p2align 3
.L2059:
	movl	4(%rax), %edx
	movl	(%rax), %ecx
	movq	%r9, %r11
	addq	$8, %rax
	addl	%edi, %edx
	addl	%r10d, %ecx
	movslq	%edx, %rdx
	salq	%cl, %r11
	orq	%r11, (%rsi,%rdx,8)
	cmpq	%r8, %rax
	jne	.L2059
.L2060:
	movl	84(%rbx), %eax
	addl	8(%rbp), %edi
	cmpl	%eax, %edi
	cmovl	%eax, %edi
	movl	%edi, 84(%rbx)
	movl	4(%rbp), %eax
	addl	%eax, 92(%rbx)
	movl	12(%rbp), %eax
	addl	%eax, 96(%rbx)
	movq	48(%rbx), %rax
	cmpw	$0, (%rax,%r14,2)
	jne	.L2049
	movq	(%r12), %rax
	addq	(%rax), %r13
	movq	24(%r13), %rdx
	movq	32(%r13), %r8
	cmpq	%rdx, %r8
	je	.L2049
	movl	72(%rbx), %eax
	movq	24(%rbx), %rdi
	movl	$1, %r9d
	movq	80(%r12), %r10
	leal	-1(%rax), %esi
	.p2align 4,,10
	.p2align 3
.L2061:
	movslq	(%rdx), %rax
	movq	%r9, %r14
	addq	$4, %rdx
	movl	(%r10,%rax,4), %ecx
	movl	%ecx, %eax
	salq	%cl, %r14
	sarl	$6, %eax
	movq	%r14, %rcx
	cltq
	notq	%rcx
	andq	%rcx, (%rdi,%rax,8)
	movl	%esi, 72(%rbx)
	subl	$1, %esi
	cmpq	%r8, %rdx
	jne	.L2061
.L2049:
	movq	40(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2067
	addq	$48, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2066:
	.cfi_restore_state
	leal	12(%rdi), %esi
	movslq	%esi, %rsi
	cmpq	%rsi, %rax
	jb	.L2068
	cmpq	%rax, %rsi
	jnb	.L2053
	leaq	(%rcx,%rsi,8), %rax
	cmpq	%rax, %rdx
	je	.L2053
	movq	%rax, 8(%rbx)
	jmp	.L2053
	.p2align 4,,10
	.p2align 3
.L2050:
	leaq	32(%r12), %rdi
	movq	%rsp, %rdx
	call	_ZNSt6vectorIN10BeamPacker5TrailESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	movq	40(%r12), %rsi
	movl	80(%rbx), %edi
	jmp	.L2051
	.p2align 4,,10
	.p2align 3
.L2068:
	movq	%rbx, %rdi
	subq	%rax, %rsi
	call	_ZNSt6vectorImSaImEE17_M_default_appendEm
	movl	80(%rbx), %edi
	jmp	.L2053
.L2067:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE10134:
	.size	_ZN10BeamPacker5placeERNS_5StateEi, .-_ZN10BeamPacker5placeERNS_5StateEi
	.section	.text._ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_,"axG",@progbits,_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_
	.type	_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_, @function
_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_:
.LFB12979:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdx, %r15
	movabsq	$4611686018427387903, %rdx
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	8(%rdi), %rbp
	movq	(%rdi), %r13
	movq	%rbp, %rcx
	subq	%r13, %rcx
	movq	%rcx, %rax
	sarq	%rax
	cmpq	%rdx, %rax
	je	.L2091
	movq	%rsi, %rdx
	movq	%rdi, %rbx
	movq	%rsi, %r14
	subq	%r13, %rdx
	cmpq	%rbp, %r13
	je	.L2092
	cmpq	%rax, %rcx
	jb	.L2084
	testq	%rcx, %rcx
	jne	.L2093
	xorl	%r12d, %r12d
	xorl	%ecx, %ecx
.L2075:
	movzwl	(%r15), %eax
	leaq	2(%rcx,%rdx), %r8
	subq	%r14, %rbp
	leaq	(%r8,%rbp), %r15
	movw	%ax, (%rcx,%rdx)
	testq	%rdx, %rdx
	jg	.L2094
	testq	%rbp, %rbp
	jle	.L2079
	movq	%rbp, %rdx
	movq	%r14, %rsi
	movq	%r8, %rdi
	movq	%rcx, (%rsp)
	call	memcpy@PLT
	movq	(%rsp), %rcx
.L2079:
	testq	%r13, %r13
	jne	.L2078
.L2081:
	movq	%rcx, (%rbx)
	movq	%r15, 8(%rbx)
	movq	%r12, 16(%rbx)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2084:
	.cfi_restore_state
	movabsq	$9223372036854775806, %r12
.L2074:
	movq	%r12, %rdi
	movq	%rdx, (%rsp)
	call	_Znwm@PLT
	movq	(%rsp), %rdx
	movq	%rax, %rcx
	addq	%rax, %r12
	jmp	.L2075
	.p2align 4,,10
	.p2align 3
.L2094:
	movq	%rcx, %rdi
	movq	%r13, %rsi
	movq	%r8, (%rsp)
	call	memmove@PLT
	movq	%rax, %rcx
	testq	%rbp, %rbp
	jg	.L2095
.L2078:
	movq	16(%rbx), %rsi
	movq	%r13, %rdi
	movq	%rcx, (%rsp)
	subq	%r13, %rsi
	call	_ZdlPvm@PLT
	movq	(%rsp), %rcx
	jmp	.L2081
	.p2align 4,,10
	.p2align 3
.L2092:
	addq	$1, %rax
	jc	.L2084
	movabsq	$4611686018427387903, %rcx
	cmpq	%rcx, %rax
	cmovbe	%rax, %rcx
	movq	%rcx, %r12
	addq	%r12, %r12
	jmp	.L2074
	.p2align 4,,10
	.p2align 3
.L2095:
	movq	(%rsp), %rdi
	movq	%rbp, %rdx
	movq	%r14, %rsi
	movq	%rax, 8(%rsp)
	call	memcpy@PLT
	movq	8(%rsp), %rcx
	jmp	.L2078
.L2093:
	movabsq	$4611686018427387903, %rax
	cmpq	%rax, %rcx
	cmova	%rax, %rcx
	leaq	(%rcx,%rcx), %r12
	jmp	.L2074
.L2091:
	leaq	.LC0(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE12979:
	.size	_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_, .-_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_
	.section	.text._ZNSt6vectorIN10BeamPacker5StateESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,"axG",@progbits,_ZNSt6vectorIN10BeamPacker5StateESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt6vectorIN10BeamPacker5StateESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.type	_ZNSt6vectorIN10BeamPacker5StateESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, @function
_ZNSt6vectorIN10BeamPacker5StateESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_:
.LFB13038:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	movq	%rdi, %r13
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	8(%rdi), %rax
	movq	(%rdi), %r14
	movabsq	$72057594037927935, %rdi
	movq	%rax, (%rsp)
	subq	%r14, %rax
	sarq	$7, %rax
	cmpq	%rdi, %rax
	je	.L2122
	movq	%rdx, %rbp
	movq	(%rsp), %rdx
	movq	%rsi, %r8
	movq	%rsi, %r12
	movq	%rsi, %r15
	subq	%r14, %r8
	cmpq	%rdx, %r14
	je	.L2123
	leaq	(%rax,%rax), %rdi
	cmpq	%rax, %rdi
	jb	.L2110
	testq	%rdi, %rdi
	jne	.L2124
	movq	$0, 16(%rsp)
	movl	$128, %ebx
	movq	$0, 8(%rsp)
.L2102:
	movq	8(%rsp), %rcx
	movdqu	0(%rbp), %xmm6
	pxor	%xmm0, %xmm0
	movdqu	16(%rbp), %xmm7
	movdqu	32(%rbp), %xmm1
	movups	%xmm0, 0(%rbp)
	leaq	(%rcx,%r8), %rax
	movq	64(%rbp), %rdi
	movups	%xmm0, 16(%rbp)
	movups	%xmm6, (%rax)
	movdqu	48(%rbp), %xmm6
	movups	%xmm7, 16(%rax)
	movdqu	72(%rbp), %xmm7
	movups	%xmm1, 32(%rax)
	movdqu	88(%rbp), %xmm1
	movups	%xmm6, 48(%rax)
	movdqu	112(%rbp), %xmm6
	movups	%xmm0, 32(%rbp)
	movups	%xmm0, 48(%rbp)
	movsd	104(%rbp), %xmm0
	movq	%rdi, 64(%rax)
	movq	$0, 64(%rbp)
	movups	%xmm7, 72(%rax)
	movups	%xmm1, 88(%rax)
	movsd	%xmm0, 104(%rax)
	movups	%xmm6, 112(%rax)
	cmpq	%r14, %r12
	je	.L2103
	movq	%r14, %rbp
	movq	%rcx, %rbx
	pxor	%xmm1, %xmm1
	jmp	.L2105
	.p2align 4,,10
	.p2align 3
.L2112:
	movq	%rsi, %rbx
.L2105:
	movq	0(%rbp), %rsi
	movdqu	72(%rbp), %xmm2
	movdqu	88(%rbp), %xmm3
	movsd	104(%rbp), %xmm0
	movq	%rsi, (%rbx)
	movq	8(%rbp), %rsi
	movups	%xmm1, 0(%rbp)
	movdqu	112(%rbp), %xmm4
	movq	%rsi, 8(%rbx)
	movq	16(%rbp), %rsi
	movq	$0, 16(%rbp)
	movq	%rsi, 16(%rbx)
	movq	24(%rbp), %rsi
	movq	%rsi, 24(%rbx)
	movq	32(%rbp), %rsi
	movq	%rsi, 32(%rbx)
	movq	40(%rbp), %rsi
	movq	%rsi, 40(%rbx)
	movq	48(%rbp), %rsi
	movq	0(%rbp), %rdi
	movq	%rsi, 48(%rbx)
	movq	56(%rbp), %rsi
	movq	%rsi, 56(%rbx)
	movq	64(%rbp), %rsi
	movups	%xmm2, 72(%rbx)
	movq	%rsi, 64(%rbx)
	movups	%xmm3, 88(%rbx)
	movsd	%xmm0, 104(%rbx)
	movups	%xmm4, 112(%rbx)
	testq	%rdi, %rdi
	je	.L2104
	movq	16(%rbp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	pxor	%xmm1, %xmm1
.L2104:
	subq	$-128, %rbp
	leaq	128(%rbx), %rsi
	cmpq	%rbp, %r12
	jne	.L2112
	addq	$256, %rbx
.L2103:
	movq	(%rsp), %rax
	cmpq	%rax, %r12
	je	.L2113
	subq	%r12, %rax
	movq	%rax, %rbp
	addq	%rbx, %rbp
	.p2align 4,,10
	.p2align 3
.L2107:
	movdqu	(%r15), %xmm5
	movdqu	16(%r15), %xmm6
	subq	$-128, %rbx
	subq	$-128, %r15
	movdqu	-96(%r15), %xmm7
	movdqu	-80(%r15), %xmm2
	movups	%xmm5, -128(%rbx)
	movq	-64(%r15), %rax
	movdqu	-56(%r15), %xmm3
	movdqu	-40(%r15), %xmm4
	movsd	-24(%r15), %xmm0
	movups	%xmm6, -112(%rbx)
	movdqu	-16(%r15), %xmm5
	movups	%xmm7, -96(%rbx)
	movups	%xmm2, -80(%rbx)
	movq	%rax, -64(%rbx)
	movups	%xmm3, -56(%rbx)
	movups	%xmm4, -40(%rbx)
	movsd	%xmm0, -24(%rbx)
	movups	%xmm5, -16(%rbx)
	cmpq	%rbp, %rbx
	jne	.L2107
.L2106:
	testq	%r14, %r14
	je	.L2108
	movq	16(%r13), %rsi
	movq	%r14, %rdi
	subq	%r14, %rsi
	call	_ZdlPvm@PLT
.L2108:
	movq	8(%rsp), %rax
	movq	%rbp, 8(%r13)
	movq	%rax, 0(%r13)
	movq	16(%rsp), %rax
	movq	%rax, 16(%r13)
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2110:
	.cfi_restore_state
	movabsq	$9223372036854775680, %rbx
.L2101:
	movq	%rbx, %rdi
	movq	%r8, 24(%rsp)
	call	_Znwm@PLT
	movq	24(%rsp), %r8
	leaq	(%rax,%rbx), %rcx
	movq	%rax, 8(%rsp)
	leaq	128(%rax), %rbx
	movq	%rcx, 16(%rsp)
	jmp	.L2102
	.p2align 4,,10
	.p2align 3
.L2123:
	addq	$1, %rax
	jc	.L2110
	movabsq	$72057594037927935, %rdi
	cmpq	%rdi, %rax
	cmova	%rdi, %rax
	salq	$7, %rax
	movq	%rax, %rbx
	jmp	.L2101
	.p2align 4,,10
	.p2align 3
.L2113:
	movq	%rbx, %rbp
	jmp	.L2106
.L2124:
	movabsq	$72057594037927935, %rax
	cmpq	%rax, %rdi
	cmova	%rax, %rdi
	salq	$7, %rdi
	movq	%rdi, %rbx
	jmp	.L2101
.L2122:
	leaq	.LC0(%rip), %rdi
	call	_ZSt20__throw_length_errorPKc@PLT
	.cfi_endproc
.LFE13038:
	.size	_ZNSt6vectorIN10BeamPacker5StateESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_, .-_ZNSt6vectorIN10BeamPacker5StateESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
	.section	.text._ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE24_M_get_insert_unique_posERS7_,"axG",@progbits,_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE24_M_get_insert_unique_posERS7_,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE24_M_get_insert_unique_posERS7_
	.type	_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE24_M_get_insert_unique_posERS7_, @function
_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE24_M_get_insert_unique_posERS7_:
.LFB13267:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	16(%rdi), %r15
	movq	%rdi, 24(%rsp)
	movq	%rsi, 16(%rsp)
	testq	%r15, %r15
	je	.L2152
	movq	16(%rsp), %rax
	movl	$2147483648, %ebp
	movq	(%rax), %rdx
	movq	8(%rax), %r14
	movq	%rdx, 8(%rsp)
	jmp	.L2133
	.p2align 4,,10
	.p2align 3
.L2131:
	movq	16(%r15), %rax
	movl	$1, %esi
	testq	%rax, %rax
	je	.L2153
.L2138:
	movq	%rax, %r15
.L2133:
	movq	40(%r15), %r12
	movq	32(%r15), %r13
	cmpq	%r12, %r14
	movq	%r12, %rbx
	cmovbe	%r14, %rbx
	testq	%rbx, %rbx
	je	.L2128
	movq	8(%rsp), %rdi
	movq	%rbx, %rdx
	movq	%r13, %rsi
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L2129
.L2128:
	movq	%r14, %rax
	subq	%r12, %rax
	cmpq	%rbp, %rax
	jge	.L2130
	movabsq	$-2147483649, %rcx
	cmpq	%rcx, %rax
	jle	.L2131
.L2129:
	testl	%eax, %eax
	js	.L2131
.L2130:
	movq	24(%r15), %rax
	xorl	%esi, %esi
	testq	%rax, %rax
	jne	.L2138
.L2153:
	movq	%r15, %rbp
	testb	%sil, %sil
	jne	.L2127
.L2134:
	testq	%rbx, %rbx
	je	.L2136
	movq	8(%rsp), %rsi
	movq	%rbx, %rdx
	movq	%r13, %rdi
	call	memcmp@PLT
	testl	%eax, %eax
	je	.L2136
.L2137:
	xorl	%edx, %edx
	testl	%eax, %eax
	cmovns	%rdx, %rbp
	cmovs	%rdx, %r15
.L2135:
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%r15, %rax
	popq	%rbx
	.cfi_def_cfa_offset 48
	movq	%rbp, %rdx
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2136:
	.cfi_restore_state
	movq	%r12, %rcx
	subq	%r14, %rcx
	cmpq	$2147483647, %rcx
	jg	.L2141
	cmpq	$-2147483648, %rcx
	jl	.L2142
	movl	%ecx, %eax
	jmp	.L2137
	.p2align 4,,10
	.p2align 3
.L2152:
	leaq	8(%rdi), %r15
.L2127:
	movq	24(%rsp), %rax
	cmpq	%r15, 24(%rax)
	je	.L2140
	movq	%r15, %rdi
	movq	%r15, %rbp
	call	_ZSt18_Rb_tree_decrementPSt18_Rb_tree_node_base@PLT
	movq	16(%rsp), %rdx
	movq	40(%rax), %r12
	movq	32(%rax), %r13
	movq	%rax, %r15
	movq	8(%rdx), %r14
	movq	(%rdx), %rcx
	movq	%r12, %rbx
	cmpq	%r12, %r14
	movq	%rcx, 8(%rsp)
	cmovbe	%r14, %rbx
	jmp	.L2134
	.p2align 4,,10
	.p2align 3
.L2140:
	movq	%r15, %rbp
	xorl	%r15d, %r15d
	jmp	.L2135
	.p2align 4,,10
	.p2align 3
.L2141:
	xorl	%ebp, %ebp
	jmp	.L2135
.L2142:
	xorl	%r15d, %r15d
	jmp	.L2135
	.cfi_endproc
.LFE13267:
	.size	_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE24_M_get_insert_unique_posERS7_, .-_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE24_M_get_insert_unique_posERS7_
	.section	.text._ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_,"axG",@progbits,_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_
	.type	_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_, @function
_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_:
.LFB12725:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	leaq	8(%rdi), %rax
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movq	%rdx, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	cmpq	%rax, %rsi
	je	.L2171
	movq	8(%rdx), %r14
	movq	40(%rsi), %r15
	movq	%rsi, %rbx
	movq	(%rdx), %r13
	movq	32(%rsi), %r8
	cmpq	%r15, %r14
	movq	%r15, %rdx
	cmovbe	%r14, %rdx
	testq	%rdx, %rdx
	je	.L2158
	movq	%r8, %rsi
	movq	%r13, %rdi
	movq	%r8, (%rsp)
	call	memcmp@PLT
	movq	(%rsp), %r8
	testl	%eax, %eax
	jne	.L2159
.L2158:
	movq	%r14, %rax
	subq	%r15, %rax
	cmpq	$2147483647, %rax
	jg	.L2160
	cmpq	$-2147483648, %rax
	jl	.L2161
.L2159:
	testl	%eax, %eax
	jns	.L2160
.L2161:
	movq	%rbx, %r8
	movq	%rbx, %r15
	cmpq	%rbx, 24(%rbp)
	je	.L2157
	movq	%rbx, %rdi
	call	_ZSt18_Rb_tree_decrementPSt18_Rb_tree_node_base@PLT
	movq	%r14, %rcx
	movq	%r13, %rdx
	movq	40(%rax), %rsi
	movq	32(%rax), %rdi
	movq	%rax, %r15
	call	_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareERKS4_.isra.0
	testl	%eax, %eax
	js	.L2172
.L2156:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%r12, %rsi
	movq	%rbp, %rdi
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE24_M_get_insert_unique_posERS7_
	.p2align 4,,10
	.p2align 3
.L2160:
	.cfi_restore_state
	movq	%r15, %rsi
	movq	%r8, %rdi
	movq	%r14, %rcx
	movq	%r13, %rdx
	call	_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareERKS4_.isra.0
	xorl	%r15d, %r15d
	movq	%rbx, %r8
	testl	%eax, %eax
	js	.L2173
.L2157:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%r15, %rdx
	movq	%r8, %rax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2171:
	.cfi_restore_state
	cmpq	$0, 40(%rdi)
	je	.L2156
	movq	32(%rdi), %r15
	movq	8(%rdx), %rcx
	movq	(%rdx), %rdx
	movq	40(%r15), %rsi
	movq	32(%r15), %rdi
	call	_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareERKS4_.isra.0
	xorl	%r8d, %r8d
	testl	%eax, %eax
	jns	.L2156
	jmp	.L2157
	.p2align 4,,10
	.p2align 3
.L2173:
	cmpq	%rbx, 32(%rbp)
	je	.L2174
	movq	%rbx, %rdi
	movq	%rbx, 8(%rsp)
	call	_ZSt18_Rb_tree_incrementPSt18_Rb_tree_node_base@PLT
	movq	%r14, %rsi
	movq	%r13, %rdi
	movq	40(%rax), %rcx
	movq	32(%rax), %rdx
	movq	%rax, (%rsp)
	call	_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareERKS4_.isra.0
	testl	%eax, %eax
	jns	.L2156
	movq	8(%rsp), %r8
	movq	(%rsp), %r9
	cmpq	$0, 24(%r8)
	movq	%r15, %r8
	cmovne	%r9, %r8
	cmpq	$0, 24(%rbx)
	cmovne	%r9, %rbx
	movq	%rbx, %r15
	jmp	.L2157
	.p2align 4,,10
	.p2align 3
.L2172:
	xorl	%r8d, %r8d
	cmpq	$0, 24(%r15)
	cmovne	%rbx, %r8
	cmovne	%rbx, %r15
	jmp	.L2157
	.p2align 4,,10
	.p2align 3
.L2174:
	xorl	%r8d, %r8d
	movq	%rbx, %r15
	jmp	.L2157
	.cfi_endproc
.LFE12725:
	.size	_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_, .-_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_
	.section	.text._ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EE11_M_gen_randEv,"axG",@progbits,_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EE11_M_gen_randEv,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EE11_M_gen_randEv
	.type	_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EE11_M_gen_randEv, @function
_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EE11_M_gen_randEv:
.LFB13503:
	.cfi_startproc
	endbr64
	movq	%rdi, %r8
	movq	(%rdi), %rsi
	leaq	1816(%rdi), %rdi
	movq	%r8, %rdx
	.p2align 4,,10
	.p2align 3
.L2176:
	andq	$-2147483648, %rsi
	addq	$8, %rdx
	movq	%rsi, %rcx
	movq	(%rdx), %rsi
	movq	%rsi, %rax
	andl	$2147483647, %eax
	orq	%rax, %rcx
	andl	$1, %eax
	negq	%rax
	shrq	%rcx
	xorq	3168(%rdx), %rcx
	andl	$2567483615, %eax
	xorq	%rcx, %rax
	movq	%rax, -8(%rdx)
	cmpq	%rdi, %rdx
	jne	.L2176
	movdqa	.LC23(%rip), %xmm7
	movdqa	.LC24(%rip), %xmm6
	leaq	4984(%r8), %rax
	pxor	%xmm3, %xmm3
	movdqa	.LC25(%rip), %xmm5
	movdqa	.LC26(%rip), %xmm4
	.p2align 4,,10
	.p2align 3
.L2177:
	movdqu	(%rdx), %xmm0
	movdqu	8(%rdx), %xmm1
	addq	$16, %rdx
	movdqu	-1832(%rdx), %xmm2
	pand	%xmm6, %xmm1
	pand	%xmm7, %xmm0
	por	%xmm1, %xmm0
	movdqa	%xmm0, %xmm1
	pand	%xmm5, %xmm0
	psrlq	$1, %xmm1
	pxor	%xmm2, %xmm1
	movdqa	%xmm3, %xmm2
	psubq	%xmm0, %xmm2
	pand	%xmm4, %xmm2
	movdqa	%xmm2, %xmm0
	pxor	%xmm1, %xmm0
	movups	%xmm0, -16(%rdx)
	cmpq	%rax, %rdx
	jne	.L2177
	movq	4984(%r8), %rax
	movq	(%r8), %rdx
	movq	$0, 4992(%r8)
	andl	$2147483647, %edx
	andq	$-2147483648, %rax
	orq	%rdx, %rax
	movq	%rax, %rdx
	andl	$1, %eax
	negq	%rax
	shrq	%rdx
	xorq	3168(%r8), %rdx
	andl	$2567483615, %eax
	xorq	%rdx, %rax
	movq	%rax, 4984(%r8)
	ret
	.cfi_endproc
.LFE13503:
	.size	_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EE11_M_gen_randEv, .-_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EE11_M_gen_randEv
	.section	.text._ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEclEv,"axG",@progbits,_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEclEv,comdat
	.align 2
	.p2align 4
	.weak	_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEclEv
	.type	_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEclEv, @function
_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEclEv:
.LFB12994:
	.cfi_startproc
	endbr64
	movq	4992(%rdi), %rax
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdi, %rbx
	cmpq	$623, %rax
	ja	.L2183
.L2181:
	leaq	1(%rax), %rdx
	movq	(%rbx,%rax,8), %rax
	movq	%rdx, 4992(%rbx)
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	movq	%rax, %rdx
	shrq	$11, %rdx
	movl	%edx, %edx
	xorq	%rax, %rdx
	movq	%rdx, %rax
	salq	$7, %rax
	andl	$2636928640, %eax
	xorq	%rdx, %rax
	movq	%rax, %rdx
	salq	$15, %rdx
	andl	$4022730752, %edx
	xorq	%rax, %rdx
	movq	%rdx, %rax
	shrq	$18, %rax
	xorq	%rdx, %rax
	ret
	.p2align 4,,10
	.p2align 3
.L2183:
	.cfi_restore_state
	call	_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EE11_M_gen_randEv
	movq	4992(%rbx), %rax
	jmp	.L2181
	.cfi_endproc
.LFE12994:
	.size	_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEclEv, .-_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEclEv
	.section	.text._ZNSt24uniform_int_distributionImEclISt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEEmRT_RKNS0_10param_typeE.isra.0,"axG",@progbits,_ZSt7shuffleIN9__gnu_cxx17__normal_iteratorIPiSt6vectorIiSaIiEEEESt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEvT_S9_OT0_,comdat
	.align 2
	.p2align 4
	.type	_ZNSt24uniform_int_distributionImEclISt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEEmRT_RKNS0_10param_typeE.isra.0, @function
_ZNSt24uniform_int_distributionImEclISt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEEmRT_RKNS0_10param_typeE.isra.0:
.LFB14717:
	.cfi_startproc
	subq	%rsi, %rdx
	movl	$4294967294, %eax
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	movq	%rdx, %r14
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	%rdi, %rbx
	cmpq	%rdx, %rax
	jnb	.L2196
	movl	$4294967295, %eax
	cmpq	%rax, %rdx
	je	.L2189
	movq	%rdx, %r13
	shrq	$32, %r13
.L2194:
	movq	%r13, %rdx
	xorl	%esi, %esi
	movq	%rbx, %rdi
	call	_ZNSt24uniform_int_distributionImEclISt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEEmRT_RKNS0_10param_typeE.isra.0
	movq	%rbx, %rdi
	movq	%rax, %r12
	call	_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEclEv
	movq	%rax, %rdx
	movq	%r12, %rax
	salq	$32, %rax
	addq	%rdx, %rax
	setc	%dl
	movzbl	%dl, %edx
	cmpq	%rax, %r14
	jb	.L2194
	testq	%rdx, %rdx
	jne	.L2194
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	addq	%rbp, %rax
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2196:
	.cfi_restore_state
	leaq	1(%rdx), %r12
	call	_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEclEv
	imulq	%r12, %rax
	movq	%rax, %rcx
	cmpl	%r12d, %eax
	jnb	.L2186
	movl	%r12d, %eax
	xorl	%edx, %edx
	negl	%eax
	divl	%r12d
	movl	%edx, %r13d
	cmpl	%edx, %ecx
	jnb	.L2186
	.p2align 4,,10
	.p2align 3
.L2187:
	movq	%rbx, %rdi
	call	_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEclEv
	imulq	%r12, %rax
	movq	%rax, %rcx
	cmpl	%r13d, %eax
	jb	.L2187
.L2186:
	movq	%rcx, %rax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	shrq	$32, %rax
	addq	%rbp, %rax
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2189:
	.cfi_restore_state
	call	_ZNSt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEclEv
	popq	%rbx
	.cfi_def_cfa_offset 40
	addq	%rbp, %rax
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE14717:
	.size	_ZNSt24uniform_int_distributionImEclISt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEEmRT_RKNS0_10param_typeE.isra.0, .-_ZNSt24uniform_int_distributionImEclISt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEEmRT_RKNS0_10param_typeE.isra.0
	.section	.text._ZSt7shuffleIN9__gnu_cxx17__normal_iteratorIPiSt6vectorIiSaIiEEEESt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEvT_S9_OT0_,"axG",@progbits,_ZSt7shuffleIN9__gnu_cxx17__normal_iteratorIPiSt6vectorIiSaIiEEEESt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEvT_S9_OT0_,comdat
	.p2align 4
	.weak	_ZSt7shuffleIN9__gnu_cxx17__normal_iteratorIPiSt6vectorIiSaIiEEEESt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEvT_S9_OT0_
	.type	_ZSt7shuffleIN9__gnu_cxx17__normal_iteratorIPiSt6vectorIiSaIiEEEESt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEvT_S9_OT0_, @function
_ZSt7shuffleIN9__gnu_cxx17__normal_iteratorIPiSt6vectorIiSaIiEEEESt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEvT_S9_OT0_:
.LFB11355:
	.cfi_startproc
	endbr64
	cmpq	%rsi, %rdi
	je	.L2209
	movq	%rsi, %rcx
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	movl	$4294967295, %eax
	subq	%rdi, %rcx
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	movq	%rdi, %r13
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	sarq	$2, %rcx
	movq	%rdx, %r12
	xorl	%edx, %edx
	divq	%rcx
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	%rsi, %rbp
	leaq	4(%rdi), %rbx
	cmpq	%rcx, %rax
	jb	.L2212
	jmp	.L2213
	.p2align 4,,10
	.p2align 3
.L2203:
	movq	%rbx, %rdx
	xorl	%esi, %esi
	movq	%r12, %rdi
	addq	$4, %rbx
	subq	%r13, %rdx
	sarq	$2, %rdx
	call	_ZNSt24uniform_int_distributionImEclISt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEEmRT_RKNS0_10param_typeE.isra.0
	movl	-4(%rbx), %edx
	leaq	0(%r13,%rax,4), %rax
	movl	(%rax), %ecx
	movl	%ecx, -4(%rbx)
	movl	%edx, (%rax)
.L2212:
	cmpq	%rbx, %rbp
	jne	.L2203
.L2197:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2213:
	.cfi_restore_state
	andl	$1, %ecx
	je	.L2214
.L2200:
	cmpq	%rbx, %rbp
	je	.L2197
	.p2align 4,,10
	.p2align 3
.L2201:
	movq	%rbx, %rdx
	xorl	%esi, %esi
	movq	%r12, %rdi
	addq	$8, %rbx
	subq	%r13, %rdx
	sarq	$2, %rdx
	leaq	2(%rdx), %r14
	addq	$1, %rdx
	imulq	%r14, %rdx
	subq	$1, %rdx
	call	_ZNSt24uniform_int_distributionImEclISt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEEmRT_RKNS0_10param_typeE.isra.0
	xorl	%edx, %edx
	movl	-8(%rbx), %ecx
	divq	%r14
	leaq	0(%r13,%rax,4), %rax
	movl	(%rax), %esi
	movl	%esi, -8(%rbx)
	movl	%ecx, (%rax)
	leaq	0(%r13,%rdx,4), %rax
	movl	-4(%rbx), %edx
	movl	(%rax), %ecx
	movl	%ecx, -4(%rbx)
	movl	%edx, (%rax)
	cmpq	%rbx, %rbp
	jne	.L2201
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2214:
	.cfi_restore_state
	movl	$1, %edx
	xorl	%esi, %esi
	leaq	8(%r13), %rbx
	movq	%r12, %rdi
	call	_ZNSt24uniform_int_distributionImEclISt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEEmRT_RKNS0_10param_typeE.isra.0
	movl	4(%r13), %edx
	leaq	0(%r13,%rax,4), %rax
	movl	(%rax), %ecx
	movl	%ecx, 4(%r13)
	movl	%edx, (%rax)
	jmp	.L2200
	.p2align 4,,10
	.p2align 3
.L2209:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	ret
	.cfi_endproc
.LFE11355:
	.size	_ZSt7shuffleIN9__gnu_cxx17__normal_iteratorIPiSt6vectorIiSaIiEEEESt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEvT_S9_OT0_, .-_ZSt7shuffleIN9__gnu_cxx17__normal_iteratorIPiSt6vectorIiSaIiEEEESt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEvT_S9_OT0_
	.section	.text._ZSt13__heap_selectIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops15_Iter_less_iterEEvT_SF_SF_T0_,"axG",@progbits,_ZSt13__heap_selectIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops15_Iter_less_iterEEvT_SF_SF_T0_,comdat
	.p2align 4
	.weak	_ZSt13__heap_selectIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops15_Iter_less_iterEEvT_SF_SF_T0_
	.type	_ZSt13__heap_selectIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops15_Iter_less_iterEEvT_SF_SF_T0_, @function
_ZSt13__heap_selectIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops15_Iter_less_iterEEvT_SF_SF_T0_:
.LFB13721:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rsi, %r8
	movq	%rsi, %r9
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	subq	%rdi, %r8
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$136, %rsp
	.cfi_def_cfa_offset 192
	movq	%rdx, 8(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 120(%rsp)
	xorl	%eax, %eax
	cmpq	$32, %r8
	jle	.L2216
	movq	%r8, %rax
	movq	%r8, 32(%rsp)
	leaq	64(%rsp), %r14
	xorl	%r12d, %r12d
	sarq	$5, %rax
	movq	%rsi, 40(%rsp)
	leaq	96(%rsp), %r13
	leaq	-2(%rax), %rdx
	movq	%rax, 16(%rsp)
	movq	%rdx, %rax
	shrq	$63, %rax
	addq	%rdx, %rax
	sarq	%rax
	movq	%rax, %rdx
	movq	%rax, %r15
	leaq	80(%rsp), %rax
	salq	$5, %rdx
	movq	%rax, 24(%rsp)
	leaq	16(%rdi,%rdx), %rbx
	jmp	.L2237
	.p2align 4,,10
	.p2align 3
.L2217:
	movq	(%rbx), %xmm1
	movdqa	%xmm0, %xmm2
	movq	%rbx, -16(%rbx)
	movq	%rdx, 48(%rsp)
	punpcklqdq	%xmm1, %xmm2
	movq	$0, -8(%rbx)
	movb	$0, (%rbx)
	movups	%xmm2, 56(%rsp)
	cmpq	%r14, %rdx
	je	.L2310
	movq	%rdx, 80(%rsp)
	movq	%xmm1, 96(%rsp)
.L2226:
	movq	24(%rsp), %rcx
	movq	16(%rsp), %rdx
	movq	%rbp, %rdi
	movq	%r15, %rsi
	movq	%r14, 48(%rsp)
	movq	%r12, 56(%rsp)
	movb	$0, 64(%rsp)
	movq	%xmm0, 88(%rsp)
	call	_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEElS7_NS0_5__ops15_Iter_less_iterEEvT_T0_SG_T1_T2_.isra.0
	movq	80(%rsp), %rdi
	cmpq	%r13, %rdi
	je	.L2233
	movq	96(%rsp), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L2233:
	movq	48(%rsp), %rdi
	testq	%r15, %r15
	je	.L2311
	subq	$1, %r15
	cmpq	%r14, %rdi
	je	.L2236
	movq	64(%rsp), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L2236:
	subq	$32, %rbx
.L2237:
	movq	-16(%rbx), %rdx
	movq	-8(%rbx), %xmm0
	cmpq	%rbx, %rdx
	jne	.L2217
	movq	%xmm0, %rax
	movq	%r14, %r8
	movq	%rbx, %rdx
	leaq	1(%rax), %rcx
	movl	%ecx, %edi
	cmpl	$8, %ecx
	jnb	.L2312
	xorl	%esi, %esi
	testb	$4, %dil
	jne	.L2313
.L2221:
	testb	$2, %dil
	jne	.L2314
.L2222:
	andl	$1, %edi
	jne	.L2315
.L2223:
	movq	$0, -8(%rbx)
	movl	%ecx, %esi
	movq	%r13, %rdi
	movq	%r14, %rdx
	movb	$0, (%rbx)
	movq	%r13, 80(%rsp)
	cmpl	$8, %ecx
	jnb	.L2316
.L2227:
	xorl	%ecx, %ecx
	testb	$4, %sil
	jne	.L2317
.L2230:
	testb	$2, %sil
	jne	.L2318
.L2231:
	andl	$1, %esi
	je	.L2226
.L2321:
	movzbl	(%rdx,%rcx), %edx
	movb	%dl, (%rdi,%rcx)
	jmp	.L2226
	.p2align 4,,10
	.p2align 3
.L2311:
	movq	32(%rsp), %r8
	movq	40(%rsp), %r9
	cmpq	%r14, %rdi
	je	.L2216
	movq	64(%rsp), %rax
	movq	%r9, 24(%rsp)
	movq	%r8, 16(%rsp)
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
	movq	16(%rsp), %r8
	movq	24(%rsp), %r9
.L2216:
	movq	8(%rsp), %rax
	sarq	$5, %r8
	movq	%r9, %rbx
	leaq	64(%rsp), %r15
	movq	%r8, 24(%rsp)
	leaq	96(%rsp), %r9
	cmpq	%rax, %rbx
	jnb	.L2215
	movq	%r9, 16(%rsp)
	jmp	.L2261
	.p2align 4,,10
	.p2align 3
.L2241:
	movq	8(%rsp), %rax
	addq	$32, %rbx
	cmpq	%rax, %rbx
	jnb	.L2215
.L2261:
	movq	8(%rbx), %r14
	movq	8(%rbp), %r12
	movq	(%rbx), %r13
	movq	0(%rbp), %rsi
	cmpq	%r12, %r14
	movq	%r12, %rdx
	cmovbe	%r14, %rdx
	testq	%rdx, %rdx
	je	.L2239
	movq	%r13, %rdi
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L2240
.L2239:
	movq	%r14, %rax
	movl	$2147483648, %ecx
	subq	%r12, %rax
	cmpq	%rcx, %rax
	jge	.L2241
	movabsq	$-2147483649, %rcx
	cmpq	%rcx, %rax
	jle	.L2242
.L2240:
	testl	%eax, %eax
	jns	.L2241
.L2242:
	leaq	16(%rbx), %rax
	movq	%r15, 48(%rsp)
	cmpq	%rax, %r13
	je	.L2243
	movq	16(%rbx), %rdx
	movq	%r13, 48(%rsp)
	movq	%rdx, 64(%rsp)
.L2244:
	movq	%rax, (%rbx)
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	movq	$0, 8(%rbx)
	movb	$0, 16(%rbx)
	movq	%r14, 56(%rsp)
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEaSEOS4_.isra.0
	movq	16(%rsp), %rax
	movq	%rax, 80(%rsp)
	movq	48(%rsp), %rax
	cmpq	%r15, %rax
	je	.L2319
	movq	%rax, 80(%rsp)
	movq	64(%rsp), %rax
	movq	%rax, 96(%rsp)
	movq	56(%rsp), %rax
.L2258:
	movq	24(%rsp), %rdx
	movq	%rbp, %rdi
	leaq	80(%rsp), %rcx
	xorl	%esi, %esi
	movq	%rax, 88(%rsp)
	movq	%r15, 48(%rsp)
	movq	$0, 56(%rsp)
	movb	$0, 64(%rsp)
	call	_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEElS7_NS0_5__ops15_Iter_less_iterEEvT_T0_SG_T1_T2_.isra.0
	movq	80(%rsp), %rdi
	movq	16(%rsp), %rax
	cmpq	%rax, %rdi
	je	.L2259
	movq	96(%rsp), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L2259:
	movq	48(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.L2241
	movq	64(%rsp), %rax
	addq	$32, %rbx
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
	movq	8(%rsp), %rax
	cmpq	%rax, %rbx
	jb	.L2261
	.p2align 4,,10
	.p2align 3
.L2215:
	movq	120(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2320
	addq	$136, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2310:
	.cfi_restore_state
	movq	%xmm0, %rax
	movq	%r13, 80(%rsp)
	movq	%r13, %rdi
	movq	%r14, %rdx
	leaq	1(%rax), %rcx
	movl	%ecx, %esi
	cmpl	$8, %ecx
	jb	.L2227
.L2316:
	andl	$-8, %ecx
	xorl	%edx, %edx
.L2228:
	movl	%edx, %eax
	addl	$8, %edx
	movq	(%r14,%rax), %rdi
	movq	%rdi, 0(%r13,%rax)
	cmpl	%ecx, %edx
	jb	.L2228
	leaq	0(%r13,%rdx), %rdi
	xorl	%ecx, %ecx
	addq	%r14, %rdx
	testb	$4, %sil
	je	.L2230
	jmp	.L2317
	.p2align 4,,10
	.p2align 3
.L2318:
	movzwl	(%rdx,%rcx), %r8d
	movw	%r8w, (%rdi,%rcx)
	addq	$2, %rcx
	andl	$1, %esi
	je	.L2226
	jmp	.L2321
	.p2align 4,,10
	.p2align 3
.L2317:
	movl	(%rdx), %ecx
	movl	%ecx, (%rdi)
	movl	$4, %ecx
	testb	$2, %sil
	je	.L2231
	jmp	.L2318
	.p2align 4,,10
	.p2align 3
.L2315:
	movzbl	(%rdx,%rsi), %edx
	movb	%dl, (%r8,%rsi)
	jmp	.L2223
	.p2align 4,,10
	.p2align 3
.L2314:
	movzwl	(%rdx,%rsi), %r9d
	movw	%r9w, (%r8,%rsi)
	addq	$2, %rsi
	andl	$1, %edi
	je	.L2223
	jmp	.L2315
	.p2align 4,,10
	.p2align 3
.L2313:
	movl	(%rdx), %esi
	movl	%esi, (%r8)
	movl	$4, %esi
	testb	$2, %dil
	je	.L2222
	jmp	.L2314
	.p2align 4,,10
	.p2align 3
.L2312:
	movl	%ecx, %r9d
	xorl	%edx, %edx
	andl	$-8, %r9d
.L2219:
	movl	%edx, %eax
	addl	$8, %edx
	movq	(%rbx,%rax), %rsi
	movq	%rsi, (%r14,%rax)
	cmpl	%r9d, %edx
	jb	.L2219
	leaq	(%r14,%rdx), %r8
	xorl	%esi, %esi
	addq	%rbx, %rdx
	testb	$4, %dil
	je	.L2221
	jmp	.L2313
	.p2align 4,,10
	.p2align 3
.L2319:
	movq	56(%rsp), %rax
	movq	16(%rsp), %rdi
	movq	%r15, %rdx
	leaq	1(%rax), %rcx
	cmpl	$8, %ecx
	jnb	.L2322
.L2252:
	xorl	%esi, %esi
	testb	$4, %cl
	jne	.L2323
	testb	$2, %cl
	jne	.L2324
.L2256:
	andl	$1, %ecx
	je	.L2258
.L2329:
	movzbl	(%rdx,%rsi), %edx
	movb	%dl, (%rdi,%rsi)
	jmp	.L2258
	.p2align 4,,10
	.p2align 3
.L2243:
	leaq	1(%r14), %rsi
	movq	%r15, %r8
	movq	%rax, %rdx
	cmpl	$8, %esi
	jnb	.L2325
.L2245:
	xorl	%edi, %edi
	testb	$4, %sil
	jne	.L2326
	testb	$2, %sil
	jne	.L2327
.L2249:
	andl	$1, %esi
	je	.L2244
.L2328:
	movzbl	(%rdx,%rdi), %edx
	movb	%dl, (%r8,%rdi)
	jmp	.L2244
	.p2align 4,,10
	.p2align 3
.L2327:
	movzwl	(%rdx,%rdi), %r9d
	movw	%r9w, (%r8,%rdi)
	addq	$2, %rdi
	andl	$1, %esi
	je	.L2244
	jmp	.L2328
	.p2align 4,,10
	.p2align 3
.L2326:
	movl	(%rdx), %edi
	movl	%edi, (%r8)
	movl	$4, %edi
	testb	$2, %sil
	je	.L2249
	jmp	.L2327
	.p2align 4,,10
	.p2align 3
.L2324:
	movzwl	(%rdx,%rsi), %r8d
	movw	%r8w, (%rdi,%rsi)
	addq	$2, %rsi
	andl	$1, %ecx
	je	.L2258
	jmp	.L2329
	.p2align 4,,10
	.p2align 3
.L2323:
	movl	(%rdx), %esi
	movl	%esi, (%rdi)
	movl	$4, %esi
	testb	$2, %cl
	je	.L2256
	jmp	.L2324
	.p2align 4,,10
	.p2align 3
.L2322:
	movl	%ecx, %r8d
	xorl	%edx, %edx
	andl	$-8, %r8d
.L2253:
	movl	%edx, %esi
	movq	16(%rsp), %r10
	addl	$8, %edx
	movq	(%r15,%rsi), %rdi
	movq	%rdi, (%r10,%rsi)
	cmpl	%r8d, %edx
	jb	.L2253
	leaq	(%r10,%rdx), %rdi
	addq	%r15, %rdx
	jmp	.L2252
	.p2align 4,,10
	.p2align 3
.L2325:
	movl	%esi, %r9d
	xorl	%edx, %edx
	andl	$-8, %r9d
.L2246:
	movl	%edx, %edi
	addl	$8, %edx
	movq	(%rax,%rdi), %r8
	movq	%r8, (%r15,%rdi)
	cmpl	%r9d, %edx
	jb	.L2246
	leaq	(%r15,%rdx), %r8
	addq	%rax, %rdx
	jmp	.L2245
.L2320:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE13721:
	.size	_ZSt13__heap_selectIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops15_Iter_less_iterEEvT_SF_SF_T0_, .-_ZSt13__heap_selectIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops15_Iter_less_iterEEvT_SF_SF_T0_
	.section	.text._ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEElNS0_5__ops15_Iter_less_iterEEvT_SF_T0_T1_.isra.0,"axG",@progbits,_ZN9CatalogueC5ERKSt6vectorI5PieceSaIS1_EE,comdat
	.p2align 4
	.type	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEElNS0_5__ops15_Iter_less_iterEEvT_SF_T0_T1_.isra.0, @function
_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEElNS0_5__ops15_Iter_less_iterEEvT_SF_T0_T1_.isra.0:
.LFB14720:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdi, %rax
	movq	%rdx, %rdi
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movq	%rsi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	subq	%rax, %r12
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$152, %rsp
	.cfi_def_cfa_offset 208
	movq	%fs:40, %rdx
	movq	%rdx, 136(%rsp)
	xorl	%edx, %edx
	cmpq	$512, %r12
	jle	.L2330
	movq	%rsi, %r13
	testq	%rdi, %rdi
	je	.L2386
	movq	%rax, 24(%rsp)
	leaq	32(%rax), %rbx
	movq	%rsi, %r15
	movq	%rdi, %rbp
	movq	%rbx, 56(%rsp)
	movl	$2147483648, %ebx
.L2333:
	movq	24(%rsp), %rax
	sarq	$6, %r12
	leaq	-32(%r15), %rcx
	subq	$1, %rbp
	salq	$5, %r12
	movq	%rcx, 32(%rsp)
	addq	%rax, %r12
	movq	32(%rax), %rdi
	movq	40(%rax), %r13
	movq	(%r12), %r14
	movq	8(%r12), %rax
	movq	%r13, %rsi
	movq	%rdi, 8(%rsp)
	movq	%rax, %rcx
	movq	%r14, %rdx
	movq	%rax, 16(%rsp)
	call	_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareERKS4_.isra.0
	movq	-32(%r15), %rdx
	movq	-24(%r15), %rcx
	movq	%rdx, 40(%rsp)
	movq	%rcx, 48(%rsp)
	testl	%eax, %eax
	js	.L2435
	movq	8(%rsp), %rdi
	movq	%r13, %rsi
	call	_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareERKS4_.isra.0
	movq	40(%rsp), %rdx
	movq	48(%rsp), %rcx
	testl	%eax, %eax
	js	.L2434
	movq	16(%rsp), %rsi
	movq	%r14, %rdi
	call	_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareERKS4_.isra.0
	testl	%eax, %eax
	js	.L2433
.L2372:
	movq	24(%rsp), %rdi
	movq	%r12, %rsi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_@PLT
.L2369:
	movq	%r15, 8(%rsp)
	movq	56(%rsp), %rcx
	movq	%r15, 40(%rsp)
	movq	%rbp, 48(%rsp)
	.p2align 4,,10
	.p2align 3
.L2385:
	movq	24(%rsp), %rax
	movq	8(%rax), %r15
	movq	(%rax), %r12
	movq	%r15, %r14
	movq	%rcx, %r15
	jmp	.L2373
	.p2align 4,,10
	.p2align 3
.L2436:
	movabsq	$-2147483649, %rax
	cmpq	%rax, %r13
	jle	.L2377
	movl	%r13d, %eax
.L2375:
	testl	%eax, %eax
	jns	.L2376
.L2377:
	addq	$32, %r15
.L2373:
	movq	8(%r15), %r13
	movq	%r14, %rdx
	movq	%r15, %rbp
	cmpq	%r14, %r13
	cmovbe	%r13, %rdx
	testq	%rdx, %rdx
	je	.L2374
	movq	(%r15), %rdi
	movq	%r12, %rsi
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L2375
.L2374:
	subq	%r14, %r13
	cmpq	%rbx, %r13
	jl	.L2436
.L2376:
	movq	8(%rsp), %r13
	movq	%r15, %rax
	movq	%rbp, 32(%rsp)
	movq	%r12, %r15
	movq	%rax, 16(%rsp)
	movq	%r14, %rbp
	subq	$32, %r13
	jmp	.L2378
	.p2align 4,,10
	.p2align 3
.L2437:
	movabsq	$-2147483649, %rcx
	cmpq	%rcx, %rax
	jle	.L2382
.L2380:
	testl	%eax, %eax
	jns	.L2381
.L2382:
	subq	$32, %r13
.L2378:
	movq	8(%r13), %r14
	movq	0(%r13), %rsi
	movq	%r13, %r12
	cmpq	%r14, %rbp
	movq	%r14, %rdx
	cmovbe	%rbp, %rdx
	testq	%rdx, %rdx
	je	.L2379
	movq	%r15, %rdi
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L2380
.L2379:
	movq	%rbp, %rax
	subq	%r14, %rax
	cmpq	%rbx, %rax
	jl	.L2437
.L2381:
	movq	16(%rsp), %r14
	movq	%r12, 8(%rsp)
	cmpq	%r13, %r14
	jnb	.L2438
	movq	%r13, %rsi
	movq	%r14, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_@PLT
	leaq	32(%r14), %rcx
	jmp	.L2385
	.p2align 4,,10
	.p2align 3
.L2438:
	movq	40(%rsp), %r15
	movq	48(%rsp), %rbp
	movq	%r14, %rdi
	movq	%r14, %r12
	movq	%rbp, %rdx
	movq	%r15, %rsi
	call	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEElNS0_5__ops15_Iter_less_iterEEvT_SF_T0_T1_.isra.0
	movq	24(%rsp), %rax
	subq	%rax, %r12
	cmpq	$512, %r12
	jle	.L2330
	testq	%rbp, %rbp
	je	.L2439
	movq	%r14, %r15
	jmp	.L2333
.L2435:
	movq	16(%rsp), %rsi
	movq	%r14, %rdi
	call	_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareERKS4_.isra.0
	movq	40(%rsp), %rdx
	movq	48(%rsp), %rcx
	testl	%eax, %eax
	js	.L2372
	movq	8(%rsp), %rdi
	movq	%r13, %rsi
	call	_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareERKS4_.isra.0
	testl	%eax, %eax
	js	.L2433
.L2434:
	movq	56(%rsp), %rsi
	movq	24(%rsp), %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_@PLT
	jmp	.L2369
.L2433:
	movq	32(%rsp), %rsi
	movq	24(%rsp), %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_@PLT
	jmp	.L2369
.L2330:
	movq	136(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2440
	addq	$152, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L2439:
	.cfi_restore_state
	movq	32(%rsp), %r13
	movq	24(%rsp), %rax
.L2386:
	movq	%r13, %rdx
	movq	%r13, %rsi
	movq	%rax, %rdi
	movq	%rax, 8(%rsp)
	call	_ZSt13__heap_selectIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops15_Iter_less_iterEEvT_SF_SF_T0_
	movq	8(%rsp), %rax
	leaq	80(%rsp), %r14
	leaq	96(%rsp), %r15
	leaq	112(%rsp), %r12
	movq	%r15, 8(%rsp)
	subq	$32, %r13
	movq	%r14, %r15
	leaq	16(%rax), %rbx
	movq	%rax, %rbp
	movq	%r12, %r14
	jmp	.L2334
.L2336:
	movq	%rcx, 64(%rsp)
	movq	16(%r13), %rcx
	movq	%rcx, 80(%rsp)
.L2343:
	movq	8(%r13), %rcx
	movq	%rdx, 0(%r13)
	movq	%rbx, %rsi
	movb	$0, 16(%r13)
	movq	%rcx, 72(%rsp)
	movq	0(%rbp), %rcx
	movq	$0, 8(%r13)
	cmpq	%rbx, %rcx
	je	.L2441
	movq	8(%rbp), %rdx
	movq	%rcx, 0(%r13)
	movq	%rdx, 8(%r13)
	movq	16(%rbp), %rdx
	movq	%rdx, 16(%r13)
	movq	%rbx, 0(%rbp)
.L2346:
	movq	$0, 8(%rbp)
	movb	$0, (%rsi)
	movq	64(%rsp), %rdx
	movq	%r14, 96(%rsp)
	cmpq	%r15, %rdx
	je	.L2442
	movq	%rdx, 96(%rsp)
	movq	80(%rsp), %rdx
	movq	%rdx, 112(%rsp)
	movq	72(%rsp), %rdx
.L2363:
	movq	%r13, %r12
	movq	%rdx, 104(%rsp)
	movq	8(%rsp), %rcx
	movq	%rbp, %rdi
	subq	%rbp, %r12
	xorl	%esi, %esi
	movq	%r15, 64(%rsp)
	movq	%r12, %rdx
	movb	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	sarq	$5, %rdx
	call	_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEElS7_NS0_5__ops15_Iter_less_iterEEvT_T0_SG_T1_T2_.isra.0
	movq	96(%rsp), %rdi
	cmpq	%r14, %rdi
	je	.L2364
	movq	112(%rsp), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L2364:
	movq	64(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.L2365
	movq	80(%rsp), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L2365:
	subq	$32, %r13
	cmpq	$32, %r12
	jle	.L2330
.L2334:
	movq	0(%r13), %rcx
	leaq	16(%r13), %rdx
	movq	%r15, 64(%rsp)
	cmpq	%rdx, %rcx
	jne	.L2336
	movq	8(%r13), %rax
	movq	%r15, %r8
	movq	%rdx, %rcx
	leaq	1(%rax), %rsi
	cmpl	$8, %esi
	jnb	.L2443
.L2337:
	xorl	%edi, %edi
	testb	$4, %sil
	je	.L2340
	movl	(%rcx), %edi
	movl	%edi, (%r8)
	movl	$4, %edi
.L2340:
	testb	$2, %sil
	je	.L2341
	movzwl	(%rcx,%rdi), %r9d
	movw	%r9w, (%r8,%rdi)
	addq	$2, %rdi
.L2341:
	andl	$1, %esi
	je	.L2343
	movzbl	(%rcx,%rdi), %ecx
	movb	%cl, (%r8,%rdi)
	jmp	.L2343
.L2442:
	movq	72(%rsp), %rdx
	movq	%r14, %r8
	movq	%r15, %rcx
	leaq	1(%rdx), %rdi
	cmpl	$8, %edi
	jnb	.L2444
.L2357:
	xorl	%esi, %esi
	testb	$4, %dil
	je	.L2360
	movl	(%rcx), %esi
	movl	%esi, (%r8)
	movl	$4, %esi
.L2360:
	testb	$2, %dil
	je	.L2361
	movzwl	(%rcx,%rsi), %r9d
	movw	%r9w, (%r8,%rsi)
	addq	$2, %rsi
.L2361:
	andl	$1, %edi
	je	.L2363
	movzbl	(%rcx,%rsi), %ecx
	movb	%cl, (%r8,%rsi)
	jmp	.L2363
.L2441:
	movq	8(%rbp), %rcx
	movq	%rcx, %rdi
	cmpq	%rbp, %r13
	je	.L2346
	testq	%rcx, %rcx
	je	.L2347
	cmpq	$1, %rcx
	je	.L2445
	movl	%ecx, %ecx
	cmpl	$8, %edi
	jb	.L2446
	movq	(%rbx), %rcx
	movq	%rbx, %r8
	movq	%rcx, (%rdx)
	movl	%edi, %ecx
	movq	-8(%rbx,%rcx), %rsi
	movq	%rsi, -8(%rdx,%rcx)
	leaq	8(%rdx), %rsi
	andq	$-8, %rsi
	subq	%rsi, %rdx
	leal	(%rdi,%rdx), %ecx
	subq	%rdx, %r8
	andl	$-8, %ecx
	cmpl	$8, %ecx
	jb	.L2432
	andl	$-8, %ecx
	xorl	%edx, %edx
.L2353:
	movl	%edx, %edi
	addl	$8, %edx
	movq	(%r8,%rdi), %r9
	movq	%r9, (%rsi,%rdi)
	cmpl	%ecx, %edx
	jb	.L2353
.L2432:
	movq	8(%rbp), %rdi
.L2350:
	movq	%rdi, %rcx
.L2347:
	movq	0(%r13), %rdx
	movq	%rcx, 8(%r13)
	movb	$0, (%rdx,%rcx)
	movq	0(%rbp), %rsi
	jmp	.L2346
.L2444:
	movl	%edi, %r9d
	xorl	%ecx, %ecx
	andl	$-8, %r9d
.L2358:
	movl	%ecx, %esi
	addl	$8, %ecx
	movq	(%r15,%rsi), %r8
	movq	%r8, (%r14,%rsi)
	cmpl	%r9d, %ecx
	jb	.L2358
	leaq	(%r14,%rcx), %r8
	addq	%r15, %rcx
	jmp	.L2357
.L2443:
	movl	%esi, %r9d
	xorl	%ecx, %ecx
	andl	$-8, %r9d
.L2338:
	movl	%ecx, %edi
	addl	$8, %ecx
	movq	(%rdx,%rdi), %r8
	movq	%r8, (%r15,%rdi)
	cmpl	%r9d, %ecx
	jb	.L2338
	leaq	(%r15,%rcx), %r8
	addq	%rdx, %rcx
	jmp	.L2337
.L2446:
	testb	$4, %dil
	jne	.L2447
	testl	%ecx, %ecx
	je	.L2350
	movzbl	(%rbx), %esi
	movb	%sil, (%rdx)
	testb	$2, %cl
	je	.L2432
	movzwl	-2(%rbx,%rcx), %esi
	movw	%si, -2(%rdx,%rcx)
	movq	8(%rbp), %rdi
	jmp	.L2350
	.p2align 4,,10
	.p2align 3
.L2445:
	movzbl	16(%rbp), %edx
	movb	%dl, 16(%r13)
	movq	0(%r13), %rdx
	movq	8(%rbp), %rcx
	movq	%rcx, 8(%r13)
	movb	$0, (%rdx,%rcx)
	movq	0(%rbp), %rsi
	jmp	.L2346
.L2447:
	movl	(%rbx), %esi
	movl	%esi, (%rdx)
	movl	-4(%rbx,%rcx), %esi
	movl	%esi, -4(%rdx,%rcx)
	movq	8(%rbp), %rdi
	jmp	.L2350
.L2440:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14720:
	.size	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEElNS0_5__ops15_Iter_less_iterEEvT_SF_T0_T1_.isra.0, .-_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEElNS0_5__ops15_Iter_less_iterEEvT_SF_T0_T1_.isra.0
	.section	.text._ZSt16__do_uninit_copyIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES6_ET0_T_S8_S7_,"axG",@progbits,_ZSt16__do_uninit_copyIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES6_ET0_T_S8_S7_,comdat
	.p2align 4
	.weak	_ZSt16__do_uninit_copyIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES6_ET0_T_S8_S7_
	.type	_ZSt16__do_uninit_copyIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES6_ET0_T_S8_S7_, @function
_ZSt16__do_uninit_copyIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES6_ET0_T_S8_S7_:
.LFB14012:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA14012
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdx, 8(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	xorl	%eax, %eax
	cmpq	%rsi, %rdi
	je	.L2463
	movq	%rdi, %r12
	movq	%rsi, %r14
	leaq	16(%rsp), %r15
	movq	%rdx, %rbx
	jmp	.L2455
	.p2align 4,,10
	.p2align 3
.L2450:
	cmpq	$1, %rbp
	jne	.L2452
	movzbl	0(%r13), %eax
	movb	%al, 16(%rbx)
.L2453:
	addq	$32, %r12
	movq	%rbp, 8(%rbx)
	addq	$32, %rbx
	movb	$0, (%rdi,%rbp)
	cmpq	%r12, %r14
	je	.L2448
.L2455:
	movq	8(%r12), %rbp
	leaq	16(%rbx), %rdi
	movq	%rdi, (%rbx)
	movq	(%r12), %r13
	movq	%rbp, 16(%rsp)
	cmpq	$15, %rbp
	jbe	.L2450
	xorl	%edx, %edx
	movq	%r15, %rsi
	movq	%rbx, %rdi
.LEHB37:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@PLT
.LEHE37:
	movq	%rax, (%rbx)
	movq	%rax, %rdi
	movq	16(%rsp), %rax
	movq	%rax, 16(%rbx)
.L2451:
	movq	%rbp, %rdx
	movq	%r13, %rsi
	call	memcpy@PLT
	movq	16(%rsp), %rbp
	movq	(%rbx), %rdi
	jmp	.L2453
	.p2align 4,,10
	.p2align 3
.L2452:
	testq	%rbp, %rbp
	je	.L2453
	jmp	.L2451
	.p2align 4,,10
	.p2align 3
.L2463:
	movq	8(%rsp), %rbx
	.p2align 4,,10
	.p2align 3
.L2448:
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2472
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L2460:
	.cfi_restore_state
	call	__cxa_end_catch@PLT
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	je	.L2461
.L2472:
	call	__stack_chk_fail@PLT
.L2464:
	endbr64
	movq	%rax, %rdi
.L2456:
	call	__cxa_begin_catch@PLT
.L2457:
	cmpq	%rbx, 8(%rsp)
	je	.L2473
	movq	8(%rsp), %r15
	movq	%r15, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_disposeEv@PLT
	movq	%r15, %rax
	addq	$32, %rax
	movq	%rax, 8(%rsp)
	jmp	.L2457
.L2473:
	movq	24(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2472
.LEHB38:
	call	__cxa_rethrow@PLT
.LEHE38:
.L2465:
	endbr64
	movq	%rax, %rbx
	jmp	.L2460
.L2461:
	movq	%rbx, %rdi
.LEHB39:
	call	_Unwind_Resume@PLT
.LEHE39:
	.cfi_endproc
.LFE14012:
	.section	.gcc_except_table._ZSt16__do_uninit_copyIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES6_ET0_T_S8_S7_,"aG",@progbits,_ZSt16__do_uninit_copyIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES6_ET0_T_S8_S7_,comdat
	.align 4
.LLSDA14012:
	.byte	0xff
	.byte	0x9b
	.uleb128 .LLSDATT14012-.LLSDATTD14012
.LLSDATTD14012:
	.byte	0x1
	.uleb128 .LLSDACSE14012-.LLSDACSB14012
.LLSDACSB14012:
	.uleb128 .LEHB37-.LFB14012
	.uleb128 .LEHE37-.LEHB37
	.uleb128 .L2464-.LFB14012
	.uleb128 0x1
	.uleb128 .LEHB38-.LFB14012
	.uleb128 .LEHE38-.LEHB38
	.uleb128 .L2465-.LFB14012
	.uleb128 0
	.uleb128 .LEHB39-.LFB14012
	.uleb128 .LEHE39-.LEHB39
	.uleb128 0
	.uleb128 0
.LLSDACSE14012:
	.byte	0x1
	.byte	0
	.align 4
	.long	0

.LLSDATT14012:
	.section	.text._ZSt16__do_uninit_copyIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES6_ET0_T_S8_S7_,"axG",@progbits,_ZSt16__do_uninit_copyIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES6_ET0_T_S8_S7_,comdat
	.size	_ZSt16__do_uninit_copyIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES6_ET0_T_S8_S7_, .-_ZSt16__do_uninit_copyIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES6_ET0_T_S8_S7_
	.section	.text._ZN9CatalogueC2ERKSt6vectorI5PieceSaIS1_EE,"axG",@progbits,_ZN9CatalogueC5ERKSt6vectorI5PieceSaIS1_EE,comdat
	.align 2
	.p2align 4
	.weak	_ZN9CatalogueC2ERKSt6vectorI5PieceSaIS1_EE
	.type	_ZN9CatalogueC2ERKSt6vectorI5PieceSaIS1_EE, @function
_ZN9CatalogueC2ERKSt6vectorI5PieceSaIS1_EE:
.LFB10001:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA10001
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pxor	%xmm0, %xmm0
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$984, %rsp
	.cfi_def_cfa_offset 1040
	movq	%rsi, 136(%rsp)
	movq	%rdi, 64(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 968(%rsp)
	xorl	%eax, %eax
	movups	%xmm0, (%rdi)
	leaq	248(%rsp), %rax
	movups	%xmm0, 16(%rdi)
	movups	%xmm0, 32(%rdi)
	movups	%xmm0, 48(%rdi)
	movq	8(%rsi), %rcx
	movq	(%rsi), %rdx
	movq	%rax, 152(%rsp)
	movq	%rcx, %rsi
	movq	%rax, 264(%rsp)
	subq	%rdx, %rsi
	movq	%rax, 272(%rsp)
	movabsq	$-6148914691236517205, %rax
	sarq	$3, %rsi
	movq	$0, 64(%rdi)
	imulq	%rax, %rsi
	movl	$0, 72(%rdi)
	movl	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 280(%rsp)
	movq	%rsi, %rax
	cmpq	%rdx, %rcx
	jne	.L2768
.L2475:
	movl	$0, 220(%rsp)
	testl	%eax, %eax
	jle	.L2625
	leaq	704(%rsp), %rax
	movq	$0, 160(%rsp)
	movq	%rax, 112(%rsp)
	leaq	960(%rsp), %rax
	movq	%rax, 120(%rsp)
	leaq	720(%rsp), %rax
	movq	%rax, 200(%rsp)
	leaq	512(%rsp), %rax
	movq	%rax, 176(%rsp)
.L2476:
	movq	160(%rsp), %rax
	movq	120(%rsp), %rsi
	leaq	(%rax,%rax), %rdi
	movl	%eax, 188(%rsp)
	movl	%eax, 184(%rsp)
	addq	%rdi, %rax
	salq	$3, %rax
	movq	%rdi, 192(%rsp)
	movq	64(%rsp), %rdi
	addq	%rax, %rdx
	movq	%rax, 144(%rsp)
	movq	8(%rdx), %rax
	subq	(%rdx), %rax
	sarq	$4, %rax
	addl	%eax, 72(%rdi)
	movq	112(%rsp), %rax
	.p2align 4,,10
	.p2align 3
.L2477:
	leaq	16(%rax), %rcx
	movq	$0, 8(%rax)
	addq	$32, %rax
	movq	%rcx, -32(%rax)
	movb	$0, -16(%rax)
	cmpq	%rsi, %rax
	jne	.L2477
	movq	200(%rsp), %rax
	movq	$0, 48(%rsp)
	movq	%rax, 168(%rsp)
	leaq	384(%rsp), %rax
	movq	%rax, 32(%rsp)
.L2478:
	movq	48(%rsp), %rax
	movq	176(%rsp), %rdi
	movl	$0, 16(%rsp)
	movl	%eax, 128(%rsp)
	negq	%rax
	andl	$96, %eax
	addq	%rdi, %rax
	movq	%rax, 96(%rsp)
	movq	168(%rsp), %rax
	movq	%rax, 72(%rsp)
	leaq	224(%rsp), %rax
	movq	%rax, 104(%rsp)
.L2522:
	movq	(%rdx), %rbx
	movq	8(%rdx), %r12
	pxor	%xmm4, %xmm4
	movq	$0, 304(%rsp)
	movaps	%xmm4, 288(%rsp)
	cmpq	%r12, %rbx
	je	.L2769
	movabsq	$9223372036854775807, %r15
	movl	16(%rsp), %eax
	xorl	%ebp, %ebp
	movq	$0, 24(%rsp)
	movq	%r15, 8(%rsp)
	leal	-1(%rax), %r13d
	.p2align 4,,10
	.p2align 3
.L2486:
	movq	(%rbx), %rdx
	movdqu	(%rbx), %xmm1
	movl	16(%rsp), %esi
	movq	%rdx, %rax
	movaps	%xmm1, 224(%rsp)
	movq	232(%rsp), %rcx
	negq	%rax
	cmpq	$0, 48(%rsp)
	cmovne	%rax, %rdx
	movl	%r13d, %eax
	testl	%esi, %esi
	je	.L2748
	.p2align 4,,10
	.p2align 3
.L2482:
	movq	%rcx, %rsi
	subl	$1, %eax
	movq	%rdx, %rcx
	negq	%rcx
	movq	%rsi, %rdx
	cmpl	$-1, %eax
	jne	.L2482
.L2483:
	movq	8(%rsp), %rax
	movq	%rsi, 224(%rsp)
	movq	%rcx, 232(%rsp)
	cmpq	%rsi, %rax
	cmovle	%rax, %rsi
	movq	24(%rsp), %rax
	cmpq	%rcx, %r15
	cmovg	%rcx, %r15
	movq	%rsi, 8(%rsp)
	cmpq	%rax, %rbp
	je	.L2484
	movdqa	224(%rsp), %xmm2
	addq	$16, %rbp
	movups	%xmm2, -16(%rbp)
	movq	%rbp, 296(%rsp)
.L2485:
	addq	$16, %rbx
	cmpq	%rbx, %r12
	jne	.L2486
	movq	32(%rsp), %rdx
	movq	288(%rsp), %r12
	movq	$0, 376(%rsp)
	movb	$0, 384(%rsp)
	movq	%r12, 80(%rsp)
	movq	%rdx, 56(%rsp)
	movq	%rdx, 368(%rsp)
	cmpq	%rbp, %r12
	je	.L2488
	movzbl	8(%rsp), %eax
	xorl	%r14d, %r14d
	movb	%al, 40(%rsp)
	jmp	.L2492
	.p2align 4,,10
	.p2align 3
.L2490:
	movb	%bl, (%rdx,%r14)
	movq	368(%rsp), %rax
	addq	$16, %r12
	movq	%r13, 376(%rsp)
	movb	$0, (%rax,%r13)
	cmpq	%r12, %rbp
	je	.L2491
	movq	376(%rsp), %r14
	movq	368(%rsp), %rdx
.L2492:
	movq	8(%r12), %rbx
	movzbl	(%r12), %eax
	leaq	1(%r14), %r13
	subb	40(%rsp), %al
	subq	%r15, %rbx
	leal	(%rbx,%rbx,4), %ebx
	leal	(%rax,%rbx,2), %ebx
	movq	32(%rsp), %rax
	cmpq	%rax, %rdx
	je	.L2639
	movq	384(%rsp), %rax
.L2489:
	cmpq	%r13, %rax
	jnb	.L2490
	leaq	368(%rsp), %rax
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	movq	%r14, %rsi
	movl	$1, %r8d
	movq	%rax, %rdi
	movq	%rax, 88(%rsp)
.LEHB40:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm@PLT
.LEHE40:
	movq	368(%rsp), %rdx
	jmp	.L2490
	.p2align 4,,10
	.p2align 3
.L2639:
	movl	$15, %eax
	jmp	.L2489
	.p2align 4,,10
	.p2align 3
.L2484:
	leaq	288(%rsp), %rax
	movq	104(%rsp), %rdx
	movq	%rbp, %rsi
	movq	%rax, %rdi
.LEHB41:
	call	_ZNSt6vectorI5PointSaIS0_EE17_M_realloc_insertIJRKS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_
.LEHE41:
	movq	304(%rsp), %rax
	movq	296(%rsp), %rbp
	movq	%rax, 24(%rsp)
	jmp	.L2485
	.p2align 4,,10
	.p2align 3
.L2748:
	movq	%rdx, %rsi
	jmp	.L2483
.L2494:
	movq	%r12, %rsi
	movq	%r13, %rdi
	call	_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEENS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_SI_T0_.isra.0
.L2496:
	movq	80(%rsp), %rbp
.L2488:
	testq	%rbp, %rbp
	je	.L2480
	movq	80(%rsp), %rax
	movq	24(%rsp), %rsi
	movq	%rbp, %rdi
	subq	%rax, %rsi
	call	_ZdlPvm@PLT
	movq	72(%rsp), %rdi
	movq	-16(%rdi), %rax
	cmpq	%rax, %rdi
	je	.L2500
.L2501:
	movq	368(%rsp), %rdx
	movq	56(%rsp), %rdi
	movq	376(%rsp), %xmm0
	cmpq	%rdi, %rdx
	je	.L2506
	movq	72(%rsp), %rdi
	movhps	384(%rsp), %xmm0
	movq	(%rdi), %rcx
	movq	%rdx, -16(%rdi)
	movups	%xmm0, -8(%rdi)
	testq	%rax, %rax
	je	.L2518
	movq	%rax, 368(%rsp)
	movq	%rcx, 384(%rsp)
.L2517:
	movq	$0, 376(%rsp)
	movb	$0, (%rax)
	movq	56(%rsp), %rax
	movq	368(%rsp), %rdi
	cmpq	%rax, %rdi
	je	.L2519
	movq	384(%rsp), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L2519:
	movq	8(%rsp), %rax
	movq	96(%rsp), %rdi
	movl	128(%rsp), %ebx
	addq	$32, 72(%rsp)
	negq	%rax
	movq	%rax, (%rdi)
	movq	%r15, %rax
	negq	%rax
	movq	%rax, 8(%rdi)
	movq	%rdi, %rax
	movl	16(%rsp), %edi
	movl	%ebx, 20(%rax)
	addq	$24, %rax
	movl	%edi, -8(%rax)
	addl	$1, %edi
	movl	%edi, 16(%rsp)
	movq	%rax, 96(%rsp)
	cmpl	$4, %edi
	je	.L2770
	movq	136(%rsp), %rax
	movq	144(%rsp), %rdx
	addq	(%rax), %rdx
	jmp	.L2522
	.p2align 4,,10
	.p2align 3
.L2491:
	movq	368(%rsp), %r13
	movq	376(%rsp), %rbx
	movq	80(%rsp), %rbp
	leaq	0(%r13,%rbx), %r12
	cmpq	%r12, %r13
	je	.L2488
	bsrq	%rbx, %rdx
	movq	%r12, %rsi
	movq	%r13, %rdi
	movslq	%edx, %rdx
	addq	%rdx, %rdx
	call	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEElNS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_SI_T0_T1_
	cmpq	$16, %rbx
	jle	.L2494
	leaq	16(%r13), %rbx
	movq	%r13, %rdi
	movq	%rbx, %rsi
	call	_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPcNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEENS0_5__ops15_Iter_comp_iterIZL9normalizeRK5PieceiiRxSF_EUlccE_EEEvT_SI_T0_.isra.0
	cmpq	%rbx, %r12
	je	.L2496
	movzbl	(%rbx), %ecx
	movzbl	-1(%rbx), %edx
	leaq	-1(%rbx), %rax
	cmpb	%dl, %cl
	jnb	.L2641
	.p2align 4,,10
	.p2align 3
.L2498:
	movb	%dl, 1(%rax)
	movq	%rax, %rsi
	movzbl	-1(%rax), %edx
	subq	$1, %rax
	cmpb	%dl, %cl
	jb	.L2498
	addq	$1, %rbx
	movb	%cl, (%rsi)
	cmpq	%rbx, %r12
	je	.L2496
.L2766:
	movzbl	(%rbx), %ecx
	movzbl	-1(%rbx), %edx
	leaq	-1(%rbx), %rax
	cmpb	%dl, %cl
	jb	.L2498
.L2641:
	movq	%rbx, %rsi
	addq	$1, %rbx
	movb	%cl, (%rsi)
	cmpq	%rbx, %r12
	jne	.L2766
	jmp	.L2496
.L2769:
	leaq	384(%rsp), %rax
	movb	$0, 384(%rsp)
	movq	%rax, 56(%rsp)
	movq	%rax, 368(%rsp)
	movabsq	$9223372036854775807, %rax
	movq	$0, 376(%rsp)
	movq	%rax, %r15
	movq	%rax, 8(%rsp)
.L2480:
	movq	72(%rsp), %rdi
	movq	-16(%rdi), %rax
	cmpq	%rax, %rdi
	jne	.L2501
.L2500:
	movq	368(%rsp), %rdx
	movq	56(%rsp), %rdi
	movq	376(%rsp), %xmm0
	cmpq	%rdi, %rdx
	je	.L2506
	movq	72(%rsp), %rax
	movhps	384(%rsp), %xmm0
	movq	%rdx, -16(%rax)
	movups	%xmm0, -8(%rax)
.L2518:
	movq	56(%rsp), %rax
	movq	%rax, 368(%rsp)
	movq	32(%rsp), %rax
	movq	%rax, 56(%rsp)
	jmp	.L2517
.L2770:
	cmpq	$0, 48(%rsp)
	jne	.L2521
	movq	136(%rsp), %rax
	movq	144(%rsp), %rdx
	movq	$1, 48(%rsp)
	subq	$-128, 168(%rsp)
	addq	(%rax), %rdx
	jmp	.L2478
.L2506:
	movq	%xmm0, %rdx
	testq	%rdx, %rdx
	je	.L2509
	cmpq	$1, %rdx
	je	.L2771
	movd	%xmm0, %edi
	movd	%xmm0, %edx
	cmpl	$8, %edi
	jnb	.L2511
	movq	%xmm0, %rdi
	andl	$4, %edi
	jne	.L2772
	testl	%edx, %edx
	je	.L2512
	movq	56(%rsp), %rdi
	movzbl	(%rdi), %ecx
	movb	%cl, (%rax)
	movq	376(%rsp), %xmm0
	testb	$2, %dl
	jne	.L2773
.L2512:
	movq	%xmm0, %rdx
.L2509:
	movq	72(%rsp), %rax
	movq	%rdx, -8(%rax)
	movq	-16(%rax), %rax
	movb	$0, (%rax,%rdx)
	movq	368(%rsp), %rax
	jmp	.L2517
.L2521:
	movq	704(%rsp), %r14
	movq	712(%rsp), %r12
	leaq	736(%rsp), %rbp
	movabsq	$-2147483649, %rbx
	movq	%r14, %r13
	.p2align 4,,10
	.p2align 3
.L2526:
	movq	8(%rbp), %r15
	movq	%r12, %rdx
	movq	0(%rbp), %r14
	cmpq	%r12, %r15
	cmovbe	%r15, %rdx
	testq	%rdx, %rdx
	je	.L2523
	movq	%r13, %rsi
	movq	%r14, %rdi
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L2524
.L2523:
	movq	%r15, %rax
	movl	$2147483648, %edi
	subq	%r12, %rax
	cmpq	%rdi, %rax
	jge	.L2525
	cmpq	%rbx, %rax
	jle	.L2642
.L2524:
	testl	%eax, %eax
	cmovs	%r15, %r12
	cmovs	%r14, %r13
.L2525:
	movq	120(%rsp), %rax
	addq	$32, %rbp
	cmpq	%rax, %rbp
	jne	.L2526
	leaq	352(%rsp), %rax
	leaq	336(%rsp), %rdi
	movq	%r13, %rsi
	leaq	0(%r13,%r12), %rdx
	movq	%rdi, 128(%rsp)
	movq	%rax, 144(%rsp)
	movq	%rax, 336(%rsp)
.LEHB42:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.isra.0
.LEHE42:
	movq	256(%rsp), %r12
	testq	%r12, %r12
	je	.L2527
	movq	344(%rsp), %r14
	movq	336(%rsp), %rbp
	movq	%r12, 8(%rsp)
	movabsq	$-2147483649, %rbx
	movq	152(%rsp), %r15
	movq	%r14, %rax
	movq	%r12, %r14
	movq	%rbp, %r12
	movq	%rax, %r13
	jmp	.L2533
.L2531:
	movq	24(%r14), %r14
	testq	%r14, %r14
	je	.L2774
.L2533:
	movq	40(%r14), %rbp
	movq	%r13, %rdx
	movq	32(%r14), %rdi
	cmpq	%r13, %rbp
	cmovbe	%rbp, %rdx
	testq	%rdx, %rdx
	je	.L2528
	movq	%r12, %rsi
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L2529
.L2528:
	subq	%r13, %rbp
	movl	$2147483648, %eax
	cmpq	%rax, %rbp
	jge	.L2530
	cmpq	%rbx, %rbp
	jle	.L2531
	movl	%ebp, %eax
.L2529:
	testl	%eax, %eax
	js	.L2531
.L2530:
	movq	%r14, %r15
	movq	16(%r14), %r14
	testq	%r14, %r14
	jne	.L2533
.L2774:
	movq	152(%rsp), %rax
	movq	%r12, %rbp
	movq	%r13, %r14
	movq	8(%rsp), %r12
	cmpq	%rax, %r15
	je	.L2645
	movq	40(%r15), %rbx
	movq	%r13, %rdx
	movq	32(%r15), %rsi
	cmpq	%r13, %rbx
	cmovbe	%rbx, %rdx
	testq	%rdx, %rdx
	je	.L2535
	movq	%rbp, %rdi
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L2536
.L2535:
	movq	%r14, %rax
	movl	$2147483648, %edi
	subq	%rbx, %rax
	cmpq	%rdi, %rax
	jge	.L2537
	cmpq	$-2147483648, %rax
	jl	.L2645
.L2536:
	testl	%eax, %eax
	jns	.L2537
.L2645:
	movq	152(%rsp), %rbx
	jmp	.L2543
.L2541:
	movq	24(%r12), %r12
	testq	%r12, %r12
	je	.L2775
.L2543:
	movq	40(%r12), %r13
	movq	32(%r12), %rdi
	cmpq	%r13, %r14
	movq	%r13, %rdx
	cmovbe	%r14, %rdx
	testq	%rdx, %rdx
	je	.L2538
	movq	%rbp, %rsi
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L2539
.L2538:
	movq	%r13, %rax
	movl	$2147483648, %edi
	subq	%r14, %rax
	cmpq	%rdi, %rax
	jge	.L2540
	cmpq	$-2147483648, %rax
	jl	.L2541
.L2539:
	testl	%eax, %eax
	js	.L2541
.L2540:
	movq	%r12, %rbx
	movq	16(%r12), %r12
	testq	%r12, %r12
	jne	.L2543
.L2775:
	movq	64(%rsp), %rax
	movq	8(%rax), %r12
	movq	(%rax), %r13
	movq	152(%rsp), %rax
	cmpq	%rax, %rbx
	je	.L2544
	movq	32(%rbx), %rdx
	movq	40(%rbx), %rcx
	movq	%r14, %rsi
	movq	%rbp, %rdi
	call	_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareERKS4_.isra.0
	movl	%eax, %edx
	movq	%r12, %rax
	testl	%edx, %edx
	js	.L2544
.L2545:
	subq	%r13, %rax
	movq	64(%rsp), %rdi
	pxor	%xmm0, %xmm0
	movabsq	$-6148914691236517205, %rdx
	sarq	$4, %rax
	movaps	%xmm0, 288(%rsp)
	imulq	%rdx, %rax
	movaps	%xmm0, 304(%rsp)
	movaps	%xmm0, 320(%rsp)
	movl	%eax, 104(%rsp)
	movq	%rax, %rbp
	movl	%eax, 64(%rbx)
	cmpq	16(%rdi), %r12
	je	.L2555
	leaq	48(%r12), %rax
	movups	%xmm0, (%r12)
	movups	%xmm0, 16(%r12)
	movups	%xmm0, 32(%r12)
	movq	%rax, 8(%rdi)
.L2556:
	movl	$256, %edi
.LEHB43:
	call	_Znwm@PLT
.LEHE43:
	movq	120(%rsp), %rsi
	movq	112(%rsp), %rdi
	movq	%rax, %rdx
	movq	%rax, %rbx
	movq	%rax, 16(%rsp)
.LEHB44:
	call	_ZSt16__do_uninit_copyIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES6_ET0_T_S8_S7_
.LEHE44:
	movq	%rax, %r12
	movq	%rax, 8(%rsp)
	movq	%rax, %rdi
	movq	%rbx, %rsi
	subq	%rbx, %r12
	movq	%r12, %rax
	sarq	$5, %rax
	movq	%rax, %rbx
	cmpq	%rsi, %rdi
	je	.L2776
	movq	$-2, %rdx
	testq	%rax, %rax
	je	.L2562
	bsrq	%rax, %rdx
	movslq	%edx, %rdx
	addq	%rdx, %rdx
.L2562:
	movq	8(%rsp), %r15
	movq	16(%rsp), %r14
	movq	%r15, %rsi
	movq	%r14, %rdi
	call	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEElNS0_5__ops15_Iter_less_iterEEvT_SF_T0_T1_.isra.0
	cmpq	$512, %r12
	jg	.L2777
	movq	8(%rsp), %rsi
	movq	16(%rsp), %rdi
	call	_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops15_Iter_less_iterEEvT_SF_T0_.isra.0
.L2565:
	movq	16(%rsp), %rax
	leaq	32(%rax), %r12
	cmpq	%r12, 8(%rsp)
	je	.L2579
	movq	8(%rax), %r13
	jmp	.L2572
.L2569:
	addq	$32, %r12
	cmpq	%r12, 8(%rsp)
	je	.L2579
.L2572:
	movq	%r13, %r14
	movq	8(%r12), %r13
	cmpq	%r14, %r13
	jne	.L2569
	movq	(%r12), %rsi
	movq	-32(%r12), %rdi
	testq	%r13, %r13
	je	.L2570
	movq	%r13, %rdx
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L2569
.L2570:
	movq	8(%rsp), %rax
	leaq	-32(%r12), %r13
	cmpq	%rax, %r13
	je	.L2579
	addq	$32, %r12
	cmpq	%r12, 8(%rsp)
	je	.L2573
	movq	%r14, %rdx
	jmp	.L2576
.L2574:
	addq	$32, %r13
	movq	%r12, %rsi
	movq	%r13, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEaSEOS4_.isra.0
.L2575:
	addq	$32, %r12
	cmpq	%r12, 8(%rsp)
	je	.L2573
.L2778:
	movq	8(%r13), %rdx
.L2576:
	cmpq	8(%r12), %rdx
	jne	.L2574
	testq	%rdx, %rdx
	je	.L2575
	movq	(%r12), %rsi
	movq	0(%r13), %rdi
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L2574
	addq	$32, %r12
	cmpq	%r12, 8(%rsp)
	jne	.L2778
.L2573:
	addq	$32, %r13
	cmpq	%r13, 8(%rsp)
	je	.L2579
	movq	%r13, %rbx
.L2578:
	movq	(%rbx), %rdi
	leaq	16(%rbx), %rax
	cmpq	%rax, %rdi
	je	.L2577
	movq	16(%rbx), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L2577:
	addq	$32, %rbx
	cmpq	%rbx, 8(%rsp)
	jne	.L2578
	movq	16(%rsp), %rdi
	movq	%r13, %rax
	movq	%r13, 8(%rsp)
	subq	%rdi, %rax
	sarq	$5, %rax
	movq	%rax, %rbx
.L2579:
	movslq	%ebp, %rax
	movl	%ebx, 88(%rsp)
	leaq	(%rax,%rax,2), %rax
	salq	$4, %rax
	movq	%rax, 40(%rsp)
	testl	%ebx, %ebx
	jle	.L2609
.L2608:
	movq	16(%rsp), %rax
	movl	$0, 56(%rsp)
	leaq	496(%rsp), %r14
	movq	%rax, 80(%rsp)
	leaq	480(%rsp), %rax
	movq	%rax, 96(%rsp)
.L2605:
	movl	104(%rsp), %eax
	movq	80(%rsp), %rbx
	pxor	%xmm0, %xmm0
	movq	$0, 408(%rsp)
	movq	96(%rsp), %rdi
	movups	%xmm0, 392(%rsp)
	movl	%eax, 368(%rsp)
	movl	56(%rsp), %eax
	movq	%rbx, %rsi
	movaps	%xmm0, 416(%rsp)
	movl	%eax, 388(%rsp)
	leaq	456(%rsp), %rax
	movq	%rax, 72(%rsp)
	movq	64(%rsp), %rax
	movaps	%xmm0, 432(%rsp)
	pxor	%xmm0, %xmm0
	movq	$0, 448(%rsp)
	leaq	24(%rax), %r15
	movq	$0, 472(%rsp)
	movq	%r14, 480(%rsp)
	movq	$0, 488(%rsp)
	movb	$0, 496(%rsp)
	movups	%xmm0, 456(%rsp)
.LEHB45:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_assignERKS4_@PLT
	movq	8(%rbx), %rsi
	movq	(%rbx), %r13
	movl	$0, 384(%rsp)
	movl	$-51, %eax
	movl	$0, 376(%rsp)
	movl	%esi, 372(%rsp)
	movzbl	0(%r13), %ecx
	mulb	%cl
	shrw	$11, %ax
	leal	(%rax,%rax,4), %eax
	addl	%eax, %eax
	subl	%eax, %ecx
	movzbl	%cl, %eax
	movl	%eax, 24(%rsp)
	leaq	0(%r13,%rsi), %rax
	movq	%rax, 32(%rsp)
	cmpq	%r13, %rax
	je	.L2649
	leaq	288(%rsp), %rax
	movq	%rax, 48(%rsp)
	jmp	.L2583
.L2780:
	movq	288(%rsp), %rax
	addq	$8, %rsi
	movq	%rax, -8(%rsi)
	movq	%rsi, 464(%rsp)
.L2582:
	leal	9(%rbx), %ecx
	movzbl	%bpl, %ebp
	movl	$1, %eax
	movl	$1, %edx
	sall	%cl, %eax
	orl	%eax, 416(%rsp,%rbp,4)
	leal	(%r12,%r12,8), %eax
	leal	(%r12,%rax,2), %eax
	leal	9(%rbx,%rax), %ecx
	movl	%ecx, %eax
	salq	%cl, %rdx
	sarl	$6, %eax
	cltq
	orq	%rdx, 392(%rsp,%rax,8)
	movl	376(%rsp), %edx
	leal	1(%r12), %eax
	cmpl	%edx, %eax
	cmovl	%edx, %eax
	addl	%r12d, 384(%rsp)
	addq	$1, %r13
	movl	%eax, 376(%rsp)
	cmpq	%r13, 32(%rsp)
	je	.L2779
.L2583:
	movzbl	0(%r13), %edx
	movl	$-51, %eax
	movq	464(%rsp), %rsi
	mulb	%dl
	shrw	$11, %ax
	movl	%eax, %ebp
	leal	0(%rbp,%rbp,4), %eax
	movzbl	%bpl, %r12d
	addl	%eax, %eax
	movl	%r12d, 292(%rsp)
	subl	%eax, %edx
	movl	24(%rsp), %eax
	movzbl	%dl, %ebx
	subl	%eax, %ebx
	movl	%ebx, 288(%rsp)
	cmpq	472(%rsp), %rsi
	jne	.L2780
	movq	64(%rsp), %rax
	movq	48(%rsp), %rdx
	leaq	456(%rsp), %rdi
	movq	%rdi, 72(%rsp)
	leaq	24(%rax), %r15
	call	_ZNSt6vectorISt4pairIiiESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
.LEHE45:
	jmp	.L2582
.L2537:
	movslq	64(%r15), %rax
	leaq	(%rax,%rax,2), %rax
	salq	$4, %rax
	movq	%rax, 40(%rsp)
.L2610:
	movq	64(%rsp), %rax
	movq	40(%rsp), %rdi
	addq	(%rax), %rdi
	movq	8(%rdi), %rsi
	cmpq	16(%rdi), %rsi
	je	.L2612
	movl	184(%rsp), %eax
	addq	$4, %rsi
	movl	%eax, -4(%rsi)
	movq	%rsi, 8(%rdi)
.L2613:
	movq	32(%rdi), %rax
	movq	24(%rdi), %rcx
	movq	%rax, 16(%rsp)
	cmpq	%rcx, %rax
	je	.L2622
	movq	64(%rsp), %rax
	movq	192(%rsp), %rbx
	movq	%rcx, %r13
	movq	24(%rax), %rax
	movq	%rax, 24(%rsp)
	movq	160(%rsp), %rax
	addq	%rax, %rbx
	salq	$6, %rbx
	movq	%rbx, 8(%rsp)
	.p2align 4,,10
	.p2align 3
.L2621:
	movslq	0(%r13), %rax
	movq	112(%rsp), %rbp
	xorl	%ebx, %ebx
	leaq	(%rax,%rax,8), %r9
	movq	24(%rsp), %rax
	salq	$4, %r9
	leaq	(%rax,%r9), %r15
	movq	120(%r15), %r12
	jmp	.L2620
	.p2align 4,,10
	.p2align 3
.L2617:
	addq	$1, %rbx
	addq	$32, %rbp
	cmpq	$8, %rbx
	je	.L2619
.L2620:
	cmpq	%r12, 8(%rbp)
	jne	.L2617
	movq	112(%r15), %r14
	movq	0(%rbp), %rdi
	testq	%r12, %r12
	je	.L2618
	movq	%r12, %rdx
	movq	%r14, %rsi
	call	memcmp@PLT
	testl	%eax, %eax
	jne	.L2617
.L2618:
	movq	64(%rsp), %rax
	movq	8(%rsp), %rsi
	addq	48(%rax), %rsi
	movslq	20(%r15), %rax
	leaq	(%rax,%rax,2), %rax
	leaq	(%rsi,%rax,8), %rdx
	leaq	(%rbx,%rbx,2), %rax
	salq	$3, %rax
	movdqu	512(%rsp,%rax), %xmm3
	movq	528(%rsp,%rax), %rax
	movups	%xmm3, (%rdx)
	movq	%rax, 16(%rdx)
	movslq	20(%r15), %rax
	movzbl	(%r14), %ecx
	leaq	(%rax,%rax,2), %rdi
	movl	$-51, %eax
	mulb	%cl
	shrw	$11, %ax
	leal	(%rax,%rax,4), %eax
	leal	(%rax,%rax), %edx
	subl	%edx, %ecx
	movzbl	%cl, %ecx
	subq	%rcx, (%rsi,%rdi,8)
.L2619:
	movq	16(%rsp), %rax
	addq	$4, %r13
	cmpq	%rax, %r13
	jne	.L2621
.L2622:
	movq	336(%rsp), %rdi
	movq	144(%rsp), %rax
	cmpq	%rax, %rdi
	je	.L2615
	movq	352(%rsp), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L2615:
	movq	112(%rsp), %rbp
	leaq	928(%rsp), %rbx
	jmp	.L2624
	.p2align 4,,10
	.p2align 3
.L2653:
	movq	%rax, %rbx
.L2624:
	movq	(%rbx), %rdi
	leaq	16(%rbx), %rax
	cmpq	%rax, %rdi
	je	.L2623
	movq	16(%rbx), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L2623:
	leaq	-32(%rbx), %rax
	cmpq	%rbx, %rbp
	jne	.L2653
	addq	$1, 160(%rsp)
	movl	188(%rsp), %eax
	movq	160(%rsp), %rdi
	addl	$1, %eax
	movl	%eax, 220(%rsp)
	movq	136(%rsp), %rax
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rax, 8(%rsp)
	subq	%rdx, %rax
	sarq	$3, %rax
	imull	$-1431655765, %eax, %eax
	cmpl	%edi, %eax
	jg	.L2476
.L2625:
	movq	256(%rsp), %rdi
	call	_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E.isra.0
	movq	968(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2747
	addq	$984, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L2511:
	.cfi_restore_state
	movq	56(%rsp), %rdi
	movq	(%rdi), %rdx
	movq	%rdx, (%rax)
	movd	%xmm0, %edx
	movq	-8(%rdi,%rdx), %rcx
	movq	%rcx, -8(%rax,%rdx)
	leaq	8(%rax), %rcx
	andq	$-8, %rcx
	subq	%rcx, %rax
	movq	%rax, %rdx
	subq	%rax, %rdi
	movd	%xmm0, %eax
	addl	%edx, %eax
	movl	%eax, %edx
	andl	$-8, %edx
	cmpl	$8, %edx
	jb	.L2762
	andl	$-8, %edx
	xorl	%eax, %eax
.L2515:
	movl	%eax, %esi
	addl	$8, %eax
	movq	(%rdi,%rsi), %r8
	movq	%r8, (%rcx,%rsi)
	cmpl	%edx, %eax
	jb	.L2515
.L2762:
	movq	376(%rsp), %xmm0
	jmp	.L2512
.L2771:
	movzbl	384(%rsp), %edx
	movb	%dl, (%rax)
	movq	376(%rsp), %rdx
	jmp	.L2509
.L2612:
	leaq	220(%rsp), %rdx
.LEHB46:
	call	_ZNSt6vectorIiSaIiEE17_M_realloc_insertIJRKiEEEvN9__gnu_cxx17__normal_iteratorIPiS1_EEDpOT_
	movq	64(%rsp), %rax
	movq	40(%rsp), %rdi
	addq	(%rax), %rdi
	jmp	.L2613
.L2527:
	movq	64(%rsp), %rax
	movq	152(%rsp), %rbx
	movq	8(%rax), %r12
	movq	(%rax), %r13
.L2544:
	movl	$72, %edi
	movq	%rbx, %r15
	call	_Znwm@PLT
.LEHE46:
	leaq	48(%rax), %rbp
	movq	336(%rsp), %rsi
	leaq	32(%rax), %r14
	movq	%rax, %rbx
	movq	344(%rsp), %rdx
	movq	%rbp, 32(%rax)
	movq	%r14, %rdi
	addq	%rsi, %rdx
.LEHB47:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.isra.0
.LEHE47:
	movl	$0, 64(%rbx)
	movq	%r14, %rdx
	movq	%r15, %rsi
	leaq	240(%rsp), %rdi
	call	_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_
	movq	%rax, %r14
	movq	%rdx, %r15
	testq	%rdx, %rdx
	je	.L2781
	cmpq	%rdx, 152(%rsp)
	je	.L2647
	testq	%rax, %rax
	je	.L2782
.L2647:
	movl	$1, %edi
.L2552:
	movq	152(%rsp), %rcx
	movq	%r15, %rdx
	movq	%rbx, %rsi
	call	_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_@PLT
	addq	$1, 280(%rsp)
	jmp	.L2553
.L2642:
	movq	%r15, %r12
	movq	%r14, %r13
	jmp	.L2525
.L2768:
	leaq	48(%rdi), %rdi
.LEHB48:
	call	_ZNSt6vectorISt5arrayI9PlacementLm8EESaIS2_EE17_M_default_appendEm
.LEHE48:
	movq	136(%rsp), %rax
	movabsq	$-6148914691236517205, %rcx
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rax, 8(%rsp)
	subq	%rdx, %rax
	sarq	$3, %rax
	imulq	%rcx, %rax
	jmp	.L2475
.L2555:
	leaq	288(%rsp), %rax
	movq	64(%rsp), %rdi
	movq	%r12, %rsi
	movq	%rax, %rdx
	movq	%rax, 48(%rsp)
.LEHB49:
	call	_ZNSt6vectorI4TypeSaIS0_EE17_M_realloc_insertIJS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_
.LEHE49:
	movq	312(%rsp), %rdi
	movq	328(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L2763
	call	_ZdlPvm@PLT
.L2763:
	movq	288(%rsp), %rdi
	movq	304(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L2556
	call	_ZdlPvm@PLT
	jmp	.L2556
.L2772:
	movq	56(%rsp), %rdi
	movl	(%rdi), %ecx
	movl	%ecx, (%rax)
	movl	-4(%rdi,%rdx), %ecx
	movl	%ecx, -4(%rax,%rdx)
	movq	376(%rsp), %xmm0
	jmp	.L2512
.L2773:
	movq	56(%rsp), %rdi
	movzwl	-2(%rdi,%rdx), %ecx
	movw	%cx, -2(%rax,%rdx)
	movq	376(%rsp), %xmm0
	jmp	.L2512
.L2781:
	movq	32(%rbx), %rdi
	cmpq	%rdi, %rbp
	je	.L2554
	movq	48(%rbx), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L2554:
	movq	%rbx, %rdi
	movl	$72, %esi
	movq	%r14, %rbx
	call	_ZdlPvm@PLT
.L2553:
	movq	64(%rsp), %rdi
	movq	%r12, %rax
	movq	8(%rdi), %r12
	jmp	.L2545
	.p2align 4,,10
	.p2align 3
.L2779:
	movl	372(%rsp), %eax
.L2580:
	movq	456(%rsp), %r11
	movq	464(%rsp), %rdi
	sall	$2, %eax
	movl	%eax, 380(%rsp)
	movq	%r11, %rdx
	cmpq	%r11, %rdi
	je	.L2592
.L2591:
	movl	(%rdx), %r9d
	movl	4(%rdx), %r10d
	movq	%r11, %rax
	leal	1(%r9), %r8d
	leal	1(%r10), %ebx
	jmp	.L2590
	.p2align 4,,10
	.p2align 3
.L2755:
	cmpl	%r9d, %ecx
	jne	.L2588
	cmpl	%esi, %ebx
	je	.L2589
.L2588:
	leaq	8(%rax), %rcx
	cmpq	%rcx, %rdi
	je	.L2783
.L2650:
	movq	%rcx, %rax
.L2590:
	movl	(%rax), %ecx
	movl	4(%rax), %esi
	cmpl	%r8d, %ecx
	jne	.L2755
	cmpl	%r10d, %esi
	jne	.L2588
.L2589:
	leaq	8(%rax), %rcx
	subl	$2, 380(%rsp)
	cmpq	%rcx, %rdi
	jne	.L2650
.L2783:
	leaq	8(%rdx), %rcx
	cmpq	%rax, %rdx
	je	.L2592
	movq	%rcx, %rdx
	jmp	.L2591
.L2592:
	movq	64(%rsp), %rbx
	movq	40(%rsp), %rdi
	movabsq	$-8198552921648689607, %rsi
	movq	32(%rbx), %rax
	subq	24(%rbx), %rax
	leaq	24(%rbx), %r15
	sarq	$4, %rax
	addq	(%rbx), %rdi
	imulq	%rsi, %rax
	movq	48(%rsp), %rsi
	addq	$24, %rdi
	movl	%eax, 288(%rsp)
	leaq	456(%rsp), %rax
	movq	%rax, 72(%rsp)
.LEHB50:
	call	_ZNSt6vectorIiSaIiEE12emplace_backIJiEEERiDpOT_.isra.0
	movq	64(%rsp), %rax
	movq	32(%rax), %rsi
	cmpq	40(%rax), %rsi
	je	.L2593
	movdqa	368(%rsp), %xmm5
	pxor	%xmm0, %xmm0
	movdqu	392(%rsp), %xmm6
	leaq	128(%rsi), %rdx
	movups	%xmm5, (%rsi)
	movq	384(%rsp), %rax
	movups	%xmm6, 24(%rsi)
	movq	%rax, 16(%rsi)
	movq	408(%rsp), %rax
	movdqa	416(%rsp), %xmm7
	movq	%rax, 40(%rsi)
	movups	%xmm7, 48(%rsi)
	movdqa	432(%rsp), %xmm5
	movups	%xmm5, 64(%rsi)
	movq	448(%rsp), %rax
	movq	%rax, 80(%rsi)
	movdqu	456(%rsp), %xmm6
	movups	%xmm6, 88(%rsi)
	movq	472(%rsp), %rax
	movq	%rax, 104(%rsi)
	movq	$0, 472(%rsp)
	movups	%xmm0, 456(%rsp)
	movq	%rdx, 112(%rsi)
	movq	480(%rsp), %rax
	cmpq	%r14, %rax
	je	.L2784
	movq	%rax, 112(%rsi)
	movq	496(%rsp), %rax
	movq	%rax, 128(%rsi)
	movq	488(%rsp), %rdi
.L2601:
	movq	64(%rsp), %rax
	movq	%rdi, 120(%rsi)
	addq	$144, 32(%rax)
.L2602:
	addl	$1, 56(%rsp)
	movl	88(%rsp), %edi
	movl	56(%rsp), %eax
	addq	$32, 80(%rsp)
	cmpl	%edi, %eax
	jne	.L2605
.L2609:
	movq	16(%rsp), %rax
	movq	8(%rsp), %rdi
	movq	%rax, %rbx
	cmpq	%rdi, %rax
	je	.L2635
.L2606:
	movq	(%rbx), %rdi
	leaq	16(%rbx), %rax
	cmpq	%rax, %rdi
	je	.L2611
	movq	16(%rbx), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L2611:
	movq	8(%rsp), %rax
	addq	$32, %rbx
	cmpq	%rax, %rbx
	jne	.L2606
.L2635:
	movq	16(%rsp), %rdi
	movl	$256, %esi
	call	_ZdlPvm@PLT
	jmp	.L2610
.L2593:
	movq	64(%rsp), %rax
	leaq	368(%rsp), %rdx
	leaq	24(%rax), %r15
	leaq	456(%rsp), %rax
	movq	%r15, %rdi
	movq	%rax, 72(%rsp)
	call	_ZNSt6vectorI7VariantSaIS0_EE17_M_realloc_insertIJS0_EEEvN9__gnu_cxx17__normal_iteratorIPS0_S2_EEDpOT_
.LEHE50:
	movq	480(%rsp), %rdi
	cmpq	%r14, %rdi
	je	.L2764
	movq	496(%rsp), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L2764:
	movq	456(%rsp), %rdi
	movq	472(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L2602
	call	_ZdlPvm@PLT
	jmp	.L2602
.L2784:
	movq	488(%rsp), %rdi
	leaq	1(%rdi), %rax
	cmpl	$8, %eax
	jnb	.L2595
	testb	$4, %al
	jne	.L2785
	testl	%eax, %eax
	je	.L2601
	movzbl	(%r14), %ecx
	movb	%cl, 128(%rsi)
	testb	$2, %al
	je	.L2601
	movl	%eax, %eax
	movzwl	-2(%r14,%rax), %ecx
	movw	%cx, -2(%rdx,%rax)
	jmp	.L2601
	.p2align 4,,10
	.p2align 3
.L2649:
	leaq	288(%rsp), %rdi
	xorl	%eax, %eax
	movq	%rdi, 48(%rsp)
	jmp	.L2580
.L2595:
	movq	(%r14), %rcx
	movq	%rcx, 128(%rsi)
	movl	%eax, %ecx
	movq	-8(%r14,%rcx), %r8
	movq	%r8, -8(%rdx,%rcx)
	leaq	136(%rsi), %rcx
	movq	%r14, %r8
	andq	$-8, %rcx
	subq	%rcx, %rdx
	addl	%edx, %eax
	subq	%rdx, %r8
	andl	$-8, %eax
	cmpl	$8, %eax
	jb	.L2601
	andl	$-8, %eax
	xorl	%edx, %edx
.L2599:
	movl	%edx, %r9d
	addl	$8, %edx
	movq	(%r8,%r9), %r10
	movq	%r10, (%rcx,%r9)
	cmpl	%eax, %edx
	jb	.L2599
	jmp	.L2601
.L2777:
	leaq	512(%r14), %r12
	movq	%r14, %rdi
	movq	%r12, %rsi
	call	_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops15_Iter_less_iterEEvT_SF_T0_.isra.0
	cmpq	%r12, %r15
	je	.L2565
.L2566:
	movq	%r12, %rdi
	addq	$32, %r12
	call	_ZSt25__unguarded_linear_insertIN9__gnu_cxx17__normal_iteratorIPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt6vectorIS7_SaIS7_EEEENS0_5__ops14_Val_less_iterEEvT_T0_.isra.0
	cmpq	%r12, 8(%rsp)
	jne	.L2566
	jmp	.L2565
.L2776:
	movslq	%ebp, %rbp
	movl	%eax, 88(%rsp)
	leaq	0(%rbp,%rbp,2), %rdx
	salq	$4, %rdx
	movq	%rdx, 40(%rsp)
	testl	%eax, %eax
	jg	.L2608
	jmp	.L2635
.L2502:
	movq	88(%rsp), %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_disposeEv@PLT
.L2503:
	movq	288(%rsp), %rdi
	movq	304(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	jne	.L2786
.L2504:
	movq	64(%rsp), %rax
	leaq	24(%rax), %r15
.L2505:
	movq	120(%rsp), %rbp
.L2631:
	subq	$32, %rbp
	movq	%rbp, %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_disposeEv@PLT
	movq	112(%rsp), %rax
	cmpq	%rax, %rbp
	jne	.L2631
.L2632:
	movq	256(%rsp), %rdi
	call	_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_iESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E.isra.0
	movq	64(%rsp), %rax
	movq	48(%rax), %rdi
	movq	64(%rax), %rax
	movq	%rax, %rsi
	movq	%rax, 8(%rsp)
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	jne	.L2787
.L2633:
	movq	%r15, %rdi
	call	_ZNSt6vectorI7VariantSaIS0_EED1Ev
	movq	64(%rsp), %rdi
	call	_ZNSt6vectorI4TypeSaIS0_EED1Ev
	movq	968(%rsp), %rax
	subq	%fs:40, %rax
	je	.L2634
.L2747:
	call	__stack_chk_fail@PLT
	.p2align 4,,10
	.p2align 3
.L2785:
	movl	(%r14), %ecx
	movl	%eax, %eax
	movl	%ecx, 128(%rsi)
	movl	-4(%r14,%rax), %ecx
	movl	%ecx, -4(%rdx,%rax)
	jmp	.L2601
.L2782:
	movq	40(%rdx), %rcx
	movq	32(%rbx), %rdi
	movq	32(%rdx), %rdx
	movq	40(%rbx), %rsi
	call	_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareERKS4_.isra.0
	shrl	$31, %eax
	movl	%eax, %edi
	jmp	.L2552
.L2657:
	endbr64
	movq	%rax, %rbx
	jmp	.L2627
.L2656:
	endbr64
	movq	%rax, %rbx
	jmp	.L2626
.L2654:
	endbr64
	movq	%rax, %rbx
	movq	64(%rsp), %rax
	leaq	24(%rax), %r15
	jmp	.L2632
.L2658:
	endbr64
	movq	%rax, %rbx
	movq	64(%rsp), %rax
	leaq	24(%rax), %r15
	jmp	.L2505
.L2660:
	endbr64
	movq	%rax, %rbx
	jmp	.L2502
.L2661:
	endbr64
	movq	%rax, %rdi
	jmp	.L2548
.L2659:
	endbr64
	movq	%rax, %rbx
	jmp	.L2503
.L2655:
	endbr64
	movq	%rax, %rbx
	movq	64(%rsp), %rax
	leaq	24(%rax), %r15
	jmp	.L2551
.L2663:
	endbr64
	movq	%rax, %rbx
	jmp	.L2560
.L2627:
	movq	96(%rsp), %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_disposeEv@PLT
	movq	72(%rsp), %rdi
	call	_ZNSt6vectorISt4pairIiiESaIS1_EED1Ev
	movq	16(%rsp), %rbp
.L2628:
	cmpq	%rbp, 8(%rsp)
	je	.L2788
	movq	0(%rbp), %rdi
	leaq	16(%rbp), %rax
	cmpq	%rax, %rdi
	je	.L2629
	movq	16(%rbp), %rax
	leaq	1(%rax), %rsi
	call	_ZdlPvm@PLT
.L2629:
	addq	$32, %rbp
	jmp	.L2628
.L2626:
	leaq	312(%rsp), %rdi
	call	_ZNSt6vectorIiSaIiEED1Ev
	movq	48(%rsp), %rdi
	call	_ZNSt6vectorIiSaIiEED1Ev
	movq	64(%rsp), %rax
	leaq	24(%rax), %r15
.L2551:
	movq	128(%rsp), %rdi
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_disposeEv@PLT
	jmp	.L2505
.L2787:
	call	_ZdlPvm@PLT
	jmp	.L2633
.L2634:
	movq	%rbx, %rdi
.LEHB51:
	call	_Unwind_Resume@PLT
.LEHE51:
.L2548:
	call	__cxa_begin_catch@PLT
	movl	$72, %esi
	movq	%rbx, %rdi
	call	_ZdlPvm@PLT
	movq	968(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2747
.LEHB52:
	call	__cxa_rethrow@PLT
.LEHE52:
.L2788:
	movq	16(%rsp), %rdi
	movl	$256, %esi
	call	_ZdlPvm@PLT
	jmp	.L2551
.L2662:
	endbr64
	movq	%rax, %rbx
.L2550:
	call	__cxa_end_catch@PLT
	movq	64(%rsp), %rax
	leaq	24(%rax), %r15
	jmp	.L2551
.L2560:
	movq	16(%rsp), %rdi
	movl	$256, %esi
	call	_ZdlPvm@PLT
	movq	64(%rsp), %rax
	leaq	24(%rax), %r15
	jmp	.L2551
.L2786:
	call	_ZdlPvm@PLT
	jmp	.L2504
	.cfi_endproc
.LFE10001:
	.section	.gcc_except_table._ZN9CatalogueC2ERKSt6vectorI5PieceSaIS1_EE,"aG",@progbits,_ZN9CatalogueC5ERKSt6vectorI5PieceSaIS1_EE,comdat
	.align 4
.LLSDA10001:
	.byte	0xff
	.byte	0x9b
	.uleb128 .LLSDATT10001-.LLSDATTD10001
.LLSDATTD10001:
	.byte	0x1
	.uleb128 .LLSDACSE10001-.LLSDACSB10001
.LLSDACSB10001:
	.uleb128 .LEHB40-.LFB10001
	.uleb128 .LEHE40-.LEHB40
	.uleb128 .L2660-.LFB10001
	.uleb128 0
	.uleb128 .LEHB41-.LFB10001
	.uleb128 .LEHE41-.LEHB41
	.uleb128 .L2659-.LFB10001
	.uleb128 0
	.uleb128 .LEHB42-.LFB10001
	.uleb128 .LEHE42-.LEHB42
	.uleb128 .L2658-.LFB10001
	.uleb128 0
	.uleb128 .LEHB43-.LFB10001
	.uleb128 .LEHE43-.LEHB43
	.uleb128 .L2655-.LFB10001
	.uleb128 0
	.uleb128 .LEHB44-.LFB10001
	.uleb128 .LEHE44-.LEHB44
	.uleb128 .L2663-.LFB10001
	.uleb128 0
	.uleb128 .LEHB45-.LFB10001
	.uleb128 .LEHE45-.LEHB45
	.uleb128 .L2657-.LFB10001
	.uleb128 0
	.uleb128 .LEHB46-.LFB10001
	.uleb128 .LEHE46-.LEHB46
	.uleb128 .L2655-.LFB10001
	.uleb128 0
	.uleb128 .LEHB47-.LFB10001
	.uleb128 .LEHE47-.LEHB47
	.uleb128 .L2661-.LFB10001
	.uleb128 0x1
	.uleb128 .LEHB48-.LFB10001
	.uleb128 .LEHE48-.LEHB48
	.uleb128 .L2654-.LFB10001
	.uleb128 0
	.uleb128 .LEHB49-.LFB10001
	.uleb128 .LEHE49-.LEHB49
	.uleb128 .L2656-.LFB10001
	.uleb128 0
	.uleb128 .LEHB50-.LFB10001
	.uleb128 .LEHE50-.LEHB50
	.uleb128 .L2657-.LFB10001
	.uleb128 0
	.uleb128 .LEHB51-.LFB10001
	.uleb128 .LEHE51-.LEHB51
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB52-.LFB10001
	.uleb128 .LEHE52-.LEHB52
	.uleb128 .L2662-.LFB10001
	.uleb128 0
.LLSDACSE10001:
	.byte	0x1
	.byte	0
	.align 4
	.long	0

.LLSDATT10001:
	.section	.text._ZN9CatalogueC2ERKSt6vectorI5PieceSaIS1_EE,"axG",@progbits,_ZN9CatalogueC5ERKSt6vectorI5PieceSaIS1_EE,comdat
	.size	_ZN9CatalogueC2ERKSt6vectorI5PieceSaIS1_EE, .-_ZN9CatalogueC2ERKSt6vectorI5PieceSaIS1_EE
	.weak	_ZN9CatalogueC1ERKSt6vectorI5PieceSaIS1_EE
	.set	_ZN9CatalogueC1ERKSt6vectorI5PieceSaIS1_EE,_ZN9CatalogueC2ERKSt6vectorI5PieceSaIS1_EE
	.section	.text._ZNSt11__copy_moveILb0ELb1ESt26random_access_iterator_tagE8__copy_mIKiiEEPT0_PT_S7_S5_,"axG",@progbits,_ZNSt11__copy_moveILb0ELb1ESt26random_access_iterator_tagE8__copy_mIKiiEEPT0_PT_S7_S5_,comdat
	.p2align 4
	.weak	_ZNSt11__copy_moveILb0ELb1ESt26random_access_iterator_tagE8__copy_mIKiiEEPT0_PT_S7_S5_
	.type	_ZNSt11__copy_moveILb0ELb1ESt26random_access_iterator_tagE8__copy_mIKiiEEPT0_PT_S7_S5_, @function
_ZNSt11__copy_moveILb0ELb1ESt26random_access_iterator_tagE8__copy_mIKiiEEPT0_PT_S7_S5_:
.LFB14078:
	.cfi_startproc
	endbr64
	subq	%rdi, %rsi
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rdx, %rcx
	movq	%rsi, %rbx
	cmpq	$4, %rsi
	jle	.L2790
	movq	%rsi, %rdx
	movq	%rdi, %rsi
	movq	%rcx, %rdi
	call	memmove@PLT
	movq	%rax, %rcx
.L2791:
	leaq	(%rcx,%rbx), %rax
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2790:
	.cfi_restore_state
	jne	.L2791
	movl	(%rdi), %eax
	movl	%eax, (%rdx)
	jmp	.L2791
	.cfi_endproc
.LFE14078:
	.size	_ZNSt11__copy_moveILb0ELb1ESt26random_access_iterator_tagE8__copy_mIKiiEEPT0_PT_S7_S5_, .-_ZNSt11__copy_moveILb0ELb1ESt26random_access_iterator_tagE8__copy_mIKiiEEPT0_PT_S7_S5_
	.section	.text._ZSt16__do_uninit_copyIN9__gnu_cxx17__normal_iteratorIPZN6Packer6nestedEdxdddE8SnapshotSt6vectorIS3_SaIS3_EEEES4_ET0_T_SA_S9_,"axG",@progbits,_ZSt16__do_uninit_copyIN9__gnu_cxx17__normal_iteratorIPZN6Packer6nestedEdxdddE8SnapshotSt6vectorIS3_SaIS3_EEEES4_ET0_T_SA_S9_,comdat
	.p2align 4
	.weak	_ZSt16__do_uninit_copyIN9__gnu_cxx17__normal_iteratorIPZN6Packer6nestedEdxdddE8SnapshotSt6vectorIS3_SaIS3_EEEES4_ET0_T_SA_S9_
	.type	_ZSt16__do_uninit_copyIN9__gnu_cxx17__normal_iteratorIPZN6Packer6nestedEdxdddE8SnapshotSt6vectorIS3_SaIS3_EEEES4_ET0_T_SA_S9_, @function
_ZSt16__do_uninit_copyIN9__gnu_cxx17__normal_iteratorIPZN6Packer6nestedEdxdddE8SnapshotSt6vectorIS3_SaIS3_EEEES4_ET0_T_SA_S9_:
.LFB14093:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA14093
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	%rdx, 8(%rsp)
	cmpq	%rsi, %rdi
	je	.L2831
	movq	%rdi, %rbp
	movq	%rsi, %r13
	movq	%rdx, %rbx
	movabsq	$9223372036854775804, %r14
	movabsq	$9223372036854775800, %r15
.L2823:
	movq	8(%rbp), %rax
	pxor	%xmm1, %xmm1
	subq	0(%rbp), %rax
	movq	$0, 16(%rbx)
	movups	%xmm1, (%rbx)
	je	.L2832
	movq	%rax, %r12
	cmpq	%rax, %r14
	jb	.L2843
	movq	%rax, %rdi
.LEHB53:
	call	_Znwm@PLT
.LEHE53:
	movq	%rax, %rcx
.L2795:
	movq	%rcx, %xmm0
	addq	%rcx, %r12
	punpcklqdq	%xmm0, %xmm0
	movq	%r12, 16(%rbx)
	movups	%xmm0, (%rbx)
	movq	0(%rbp), %rsi
	movq	8(%rbp), %r12
	subq	%rsi, %r12
	cmpq	$4, %r12
	jle	.L2798
	movq	%rcx, %rdi
	movq	%r12, %rdx
	call	memmove@PLT
	movq	%rax, %rcx
.L2799:
	addq	%r12, %rcx
	pxor	%xmm2, %xmm2
	movq	%rcx, 8(%rbx)
	movq	32(%rbp), %rax
	subq	24(%rbp), %rax
	movq	$0, 40(%rbx)
	movups	%xmm2, 24(%rbx)
	je	.L2833
	movq	%rax, %r12
	cmpq	%rax, %r14
	jb	.L2844
	movq	%rax, %rdi
.LEHB54:
	call	_Znwm@PLT
.LEHE54:
	movq	%rax, %rcx
.L2802:
	movq	%rcx, %xmm0
	addq	%rcx, %r12
	punpcklqdq	%xmm0, %xmm0
	movq	%r12, 40(%rbx)
	movups	%xmm0, 24(%rbx)
	movq	24(%rbp), %rsi
	movq	32(%rbp), %r12
	subq	%rsi, %r12
	cmpq	$4, %r12
	jle	.L2805
	movq	%rcx, %rdi
	movq	%r12, %rdx
	call	memmove@PLT
	movq	%rax, %rcx
.L2806:
	addq	%r12, %rcx
	pxor	%xmm3, %xmm3
	movq	56(%rbp), %r12
	subq	48(%rbp), %r12
	movq	%rcx, 32(%rbx)
	movq	$0, 64(%rbx)
	movups	%xmm3, 48(%rbx)
	je	.L2834
	cmpq	%r12, %r15
	jb	.L2845
	movq	%r12, %rdi
.LEHB55:
	call	_Znwm@PLT
.LEHE55:
	movq	%rax, %rcx
.L2809:
	movq	%rcx, %xmm0
	addq	%rcx, %r12
	punpcklqdq	%xmm0, %xmm0
	movq	%r12, 64(%rbx)
	movups	%xmm0, 48(%rbx)
	movq	48(%rbp), %rsi
	movq	56(%rbp), %r12
	subq	%rsi, %r12
	cmpq	$8, %r12
	jle	.L2812
	movq	%rcx, %rdi
	movq	%r12, %rdx
	call	memmove@PLT
	movq	%rax, %rcx
.L2813:
	movq	72(%rbp), %rax
	addq	%r12, %rcx
	pxor	%xmm4, %xmm4
	movq	%rcx, 56(%rbx)
	movq	%rax, 72(%rbx)
	movq	88(%rbp), %rax
	subq	80(%rbp), %rax
	movq	$0, 96(%rbx)
	movups	%xmm4, 80(%rbx)
	je	.L2835
	movq	%rax, %r12
	cmpq	%rax, %r15
	jb	.L2846
	movq	%rax, %rdi
.LEHB56:
	call	_Znwm@PLT
.LEHE56:
	movq	%rax, %rcx
.L2816:
	movq	%rcx, %xmm0
	addq	%rcx, %r12
	punpcklqdq	%xmm0, %xmm0
	movq	%r12, 96(%rbx)
	movups	%xmm0, 80(%rbx)
	movq	80(%rbp), %rsi
	movq	88(%rbp), %r12
	subq	%rsi, %r12
	cmpq	$24, %r12
	jle	.L2819
	movq	%rcx, %rdi
	movq	%r12, %rdx
	call	memmove@PLT
	movq	%rax, %rcx
.L2820:
	movq	104(%rbp), %rax
	addq	%r12, %rcx
	addq	$120, %rbp
	addq	$120, %rbx
	movq	%rcx, -32(%rbx)
	movq	%rax, -16(%rbx)
	movl	-8(%rbp), %eax
	movl	%eax, -8(%rbx)
	cmpq	%rbp, %r13
	jne	.L2823
.L2793:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2832:
	.cfi_restore_state
	xorl	%r12d, %r12d
	xorl	%ecx, %ecx
	jmp	.L2795
	.p2align 4,,10
	.p2align 3
.L2833:
	xorl	%r12d, %r12d
	xorl	%ecx, %ecx
	jmp	.L2802
	.p2align 4,,10
	.p2align 3
.L2834:
	xorl	%ecx, %ecx
	jmp	.L2809
	.p2align 4,,10
	.p2align 3
.L2835:
	xorl	%r12d, %r12d
	xorl	%ecx, %ecx
	jmp	.L2816
	.p2align 4,,10
	.p2align 3
.L2798:
	jne	.L2799
	movl	(%rsi), %eax
	movl	%eax, (%rcx)
	jmp	.L2799
	.p2align 4,,10
	.p2align 3
.L2805:
	jne	.L2806
	movl	(%rsi), %eax
	movl	%eax, (%rcx)
	jmp	.L2806
	.p2align 4,,10
	.p2align 3
.L2812:
	jne	.L2813
	movq	(%rsi), %rax
	movq	%rax, (%rcx)
	jmp	.L2813
	.p2align 4,,10
	.p2align 3
.L2819:
	jne	.L2820
	movdqu	(%rsi), %xmm5
	movups	%xmm5, (%rcx)
	movq	16(%rsi), %rax
	movq	%rax, 16(%rcx)
	jmp	.L2820
	.p2align 4,,10
	.p2align 3
.L2843:
	testq	%rax, %rax
	jns	.L2797
.LEHB57:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE57:
	.p2align 4,,10
	.p2align 3
.L2844:
	testq	%rax, %rax
	jns	.L2804
.LEHB58:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE58:
	.p2align 4,,10
	.p2align 3
.L2845:
	testq	%r12, %r12
	jns	.L2811
.LEHB59:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE59:
	.p2align 4,,10
	.p2align 3
.L2846:
	testq	%rax, %rax
	jns	.L2818
.LEHB60:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE60:
	.p2align 4,,10
	.p2align 3
.L2831:
	movq	8(%rsp), %rbx
	jmp	.L2793
	.p2align 4,,10
	.p2align 3
.L2797:
.LEHB61:
	call	_ZSt17__throw_bad_allocv@PLT
.LEHE61:
	.p2align 4,,10
	.p2align 3
.L2804:
.LEHB62:
	call	_ZSt17__throw_bad_allocv@PLT
.LEHE62:
	.p2align 4,,10
	.p2align 3
.L2811:
.LEHB63:
	call	_ZSt17__throw_bad_allocv@PLT
.LEHE63:
	.p2align 4,,10
	.p2align 3
.L2818:
.LEHB64:
	call	_ZSt17__throw_bad_allocv@PLT
.LEHE64:
.L2839:
	endbr64
	movq	%rax, %rbp
	jmp	.L2825
.L2840:
	endbr64
	movq	%rax, %rbp
.L2824:
	leaq	48(%rbx), %rdi
	call	_ZNSt6vectorIySaIyEED1Ev
.L2825:
	leaq	24(%rbx), %rdi
	call	_ZNSt6vectorIiSaIiEED1Ev
.L2826:
	movq	%rbx, %rdi
	call	_ZNSt6vectorIiSaIiEED1Ev
.L2827:
	movq	%rbp, %rdi
	call	__cxa_begin_catch@PLT
.L2828:
	cmpq	%rbx, 8(%rsp)
	je	.L2847
	movq	8(%rsp), %r15
	movq	%r15, %rdi
	call	_ZZN6Packer6nestedEdxdddEN8SnapshotD1Ev
	movq	%r15, %rax
	addq	$120, %rax
	movq	%rax, 8(%rsp)
	jmp	.L2828
.L2847:
.LEHB65:
	call	__cxa_rethrow@PLT
.LEHE65:
.L2837:
	endbr64
	movq	%rax, %rbx
	jmp	.L2830
.L2836:
	endbr64
	movq	%rax, %rbp
	jmp	.L2827
.L2838:
	endbr64
	movq	%rax, %rbp
	jmp	.L2826
.L2830:
	call	__cxa_end_catch@PLT
	movq	%rbx, %rdi
.LEHB66:
	call	_Unwind_Resume@PLT
.LEHE66:
	.cfi_endproc
.LFE14093:
	.section	.gcc_except_table._ZSt16__do_uninit_copyIN9__gnu_cxx17__normal_iteratorIPZN6Packer6nestedEdxdddE8SnapshotSt6vectorIS3_SaIS3_EEEES4_ET0_T_SA_S9_,"aG",@progbits,_ZSt16__do_uninit_copyIN9__gnu_cxx17__normal_iteratorIPZN6Packer6nestedEdxdddE8SnapshotSt6vectorIS3_SaIS3_EEEES4_ET0_T_SA_S9_,comdat
	.align 4
.LLSDA14093:
	.byte	0xff
	.byte	0x9b
	.uleb128 .LLSDATT14093-.LLSDATTD14093
.LLSDATTD14093:
	.byte	0x1
	.uleb128 .LLSDACSE14093-.LLSDACSB14093
.LLSDACSB14093:
	.uleb128 .LEHB53-.LFB14093
	.uleb128 .LEHE53-.LEHB53
	.uleb128 .L2836-.LFB14093
	.uleb128 0x1
	.uleb128 .LEHB54-.LFB14093
	.uleb128 .LEHE54-.LEHB54
	.uleb128 .L2838-.LFB14093
	.uleb128 0x3
	.uleb128 .LEHB55-.LFB14093
	.uleb128 .LEHE55-.LEHB55
	.uleb128 .L2839-.LFB14093
	.uleb128 0x3
	.uleb128 .LEHB56-.LFB14093
	.uleb128 .LEHE56-.LEHB56
	.uleb128 .L2840-.LFB14093
	.uleb128 0x3
	.uleb128 .LEHB57-.LFB14093
	.uleb128 .LEHE57-.LEHB57
	.uleb128 .L2836-.LFB14093
	.uleb128 0x1
	.uleb128 .LEHB58-.LFB14093
	.uleb128 .LEHE58-.LEHB58
	.uleb128 .L2838-.LFB14093
	.uleb128 0x3
	.uleb128 .LEHB59-.LFB14093
	.uleb128 .LEHE59-.LEHB59
	.uleb128 .L2839-.LFB14093
	.uleb128 0x3
	.uleb128 .LEHB60-.LFB14093
	.uleb128 .LEHE60-.LEHB60
	.uleb128 .L2840-.LFB14093
	.uleb128 0x3
	.uleb128 .LEHB61-.LFB14093
	.uleb128 .LEHE61-.LEHB61
	.uleb128 .L2836-.LFB14093
	.uleb128 0x1
	.uleb128 .LEHB62-.LFB14093
	.uleb128 .LEHE62-.LEHB62
	.uleb128 .L2838-.LFB14093
	.uleb128 0x3
	.uleb128 .LEHB63-.LFB14093
	.uleb128 .LEHE63-.LEHB63
	.uleb128 .L2839-.LFB14093
	.uleb128 0x3
	.uleb128 .LEHB64-.LFB14093
	.uleb128 .LEHE64-.LEHB64
	.uleb128 .L2840-.LFB14093
	.uleb128 0x3
	.uleb128 .LEHB65-.LFB14093
	.uleb128 .LEHE65-.LEHB65
	.uleb128 .L2837-.LFB14093
	.uleb128 0
	.uleb128 .LEHB66-.LFB14093
	.uleb128 .LEHE66-.LEHB66
	.uleb128 0
	.uleb128 0
.LLSDACSE14093:
	.byte	0x1
	.byte	0
	.byte	0
	.byte	0x7d
	.align 4
	.long	0

.LLSDATT14093:
	.section	.text._ZSt16__do_uninit_copyIN9__gnu_cxx17__normal_iteratorIPZN6Packer6nestedEdxdddE8SnapshotSt6vectorIS3_SaIS3_EEEES4_ET0_T_SA_S9_,"axG",@progbits,_ZSt16__do_uninit_copyIN9__gnu_cxx17__normal_iteratorIPZN6Packer6nestedEdxdddE8SnapshotSt6vectorIS3_SaIS3_EEEES4_ET0_T_SA_S9_,comdat
	.size	_ZSt16__do_uninit_copyIN9__gnu_cxx17__normal_iteratorIPZN6Packer6nestedEdxdddE8SnapshotSt6vectorIS3_SaIS3_EEEES4_ET0_T_SA_S9_, .-_ZSt16__do_uninit_copyIN9__gnu_cxx17__normal_iteratorIPZN6Packer6nestedEdxdddE8SnapshotSt6vectorIS3_SaIS3_EEEES4_ET0_T_SA_S9_
	.section	.text._ZN6Packer6nestedEdxddd,"axG",@progbits,_ZN6Packer6nestedEdxddd,comdat
	.align 2
	.p2align 4
	.weak	_ZN6Packer6nestedEdxddd
	.type	_ZN6Packer6nestedEdxddd, @function
_ZN6Packer6nestedEdxddd:
.LFB10099:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA10099
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	unpcklpd	%xmm3, %xmm2
	xorl	%ecx, %ecx
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	movq	%rsi, %r14
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movl	$8, %ebp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$328, %rsp
	.cfi_def_cfa_offset 384
	movl	112(%rsi), %r12d
	movq	%rdi, 8(%rsp)
	leaq	160(%rsp), %r13
	movq	%rdx, 24(%rsp)
	leal	0(,%r12,8), %ebx
	movsd	%xmm0, 32(%rsp)
	pxor	%xmm0, %xmm0
	movsd	%xmm1, 40(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 312(%rsp)
	xorl	%eax, %eax
	movq	%rsi, 88(%rsp)
	movups	%xmm2, 184(%rsi)
	xorl	%esi, %esi
	movq	$0, 112(%rsp)
	movaps	%xmm0, 96(%rsp)
	jmp	.L2853
	.p2align 4,,10
	.p2align 3
.L3069:
	movl	(%rdx), %eax
	addq	$4, %rsi
	subl	%r12d, %ebx
	movl	%eax, -4(%rsi)
	movq	%rsi, 104(%rsp)
	subl	$1, %ebp
	je	.L2852
.L3070:
	movq	112(%rsp), %rcx
.L2853:
	testl	%ebx, %ebx
	leal	7(%rbx), %eax
	leaq	192(%rsp), %rdx
	movl	$1, 160(%rsp)
	cmovns	%ebx, %eax
	sarl	$3, %eax
	cmpl	$15, %ebx
	movl	%eax, 192(%rsp)
	cmovle	%r13, %rdx
	cmpq	%rcx, %rsi
	jne	.L3069
	leaq	96(%rsp), %r15
	movq	%r15, %rdi
.LEHB67:
	call	_ZNSt6vectorIiSaIiEE17_M_realloc_insertIJRKiEEEvN9__gnu_cxx17__normal_iteratorIPiS1_EEDpOT_
.LEHE67:
	movq	104(%rsp), %rsi
	subl	%r12d, %ebx
	subl	$1, %ebp
	jne	.L3070
	.p2align 4,,10
	.p2align 3
.L2852:
	movq	96(%rsp), %r15
	movq	%r15, %rdx
	cmpq	%rsi, %r15
	jne	.L2854
	jmp	.L2855
	.p2align 4,,10
	.p2align 3
.L2858:
	movl	-4(%rdx), %edi
	cmpl	4(%rax), %edi
	je	.L3071
.L2854:
	movq	%rdx, %rax
	leaq	4(%rdx), %rdx
	cmpq	%rsi, %rdx
	jne	.L2858
.L2855:
	movq	$0, 144(%rsp)
	pxor	%xmm0, %xmm0
	movabsq	$-1229782938247303441, %rbp
	movaps	%xmm0, 128(%rsp)
	jmp	.L2863
	.p2align 4,,10
	.p2align 3
.L2864:
	xorl	%esi, %esi
	movq	%r14, %rdi
.LEHB68:
	call	_ZN6Packer4stepEi
.L2863:
	movl	112(%r14), %ecx
	testl	%ecx, %ecx
	je	.L3072
	movq	136(%rsp), %rbx
	movq	104(%rsp), %rdx
	movq	%rbx, %rax
	subq	128(%rsp), %rax
	subq	%r15, %rdx
	sarq	$3, %rax
	sarq	$2, %rdx
	imulq	%rbp, %rax
	cmpq	%rdx, %rax
	jnb	.L2864
	cmpl	%ecx, (%r15,%rax,4)
	jne	.L2864
	leaq	192(%rsp), %r12
	leaq	88(%rsp), %rsi
	movq	%r12, %rdi
	call	_ZZN6Packer6nestedEdxdddENKUlvE_clEv
	cmpq	144(%rsp), %rbx
	je	.L2865
	movq	256(%rsp), %rax
	addq	$120, %rbx
	movdqa	192(%rsp), %xmm6
	movdqa	208(%rsp), %xmm7
	movdqa	272(%rsp), %xmm3
	movq	%rax, -56(%rbx)
	movq	264(%rsp), %rax
	movups	%xmm6, -120(%rbx)
	movdqa	224(%rsp), %xmm6
	movq	%rax, -48(%rbx)
	movq	288(%rsp), %rax
	movups	%xmm7, -104(%rbx)
	movdqa	240(%rsp), %xmm7
	movq	%rax, -24(%rbx)
	movq	296(%rsp), %rax
	movups	%xmm6, -88(%rbx)
	movq	%rax, -16(%rbx)
	movl	304(%rsp), %eax
	movups	%xmm7, -72(%rbx)
	movups	%xmm3, -40(%rbx)
	movl	%eax, -8(%rbx)
	movq	%rbx, 136(%rsp)
	jmp	.L2864
	.p2align 4,,10
	.p2align 3
.L3072:
	movq	216(%r14), %rax
	movq	8(%rsp), %rcx
	pxor	%xmm0, %xmm0
	movq	232(%r14), %rbx
	subq	224(%r14), %rbx
	movq	%rax, (%rcx)
	movq	$0, 24(%rcx)
	movups	%xmm0, 8(%rcx)
	je	.L2971
	movabsq	$9223372036854775800, %rax
	cmpq	%rbx, %rax
	jb	.L3073
	movq	%rbx, %rdi
	call	_Znwm@PLT
.LEHE68:
	movq	%rax, %rcx
.L2872:
	movq	8(%rsp), %rax
	movq	%rcx, %xmm0
	addq	%rcx, %rbx
	punpcklqdq	%xmm0, %xmm0
	movq	%rbx, 24(%rax)
	movups	%xmm0, 8(%rax)
	movq	224(%r14), %rsi
	movq	232(%r14), %rbx
	subq	%rsi, %rbx
	cmpq	$24, %rbx
	jle	.L2875
	movq	%rcx, %rdi
	movq	%rbx, %rdx
	call	memmove@PLT
	movq	%rax, %rcx
.L2876:
	addq	%rbx, %rcx
	pxor	%xmm0, %xmm0
	movq	8(%rsp), %rbx
	pxor	%xmm1, %xmm1
	cvtsi2sdq	24(%rsp), %xmm0
	mulsd	.LC27(%rip), %xmm0
	movq	128(%rsp), %rbp
	movslq	(%rbx), %rax
	movslq	4(%rbx), %rdx
	movq	%rcx, 16(%rbx)
	movq	%rbp, 16(%rsp)
	imulq	%rdx, %rax
	cvtsi2sdq	%rax, %xmm1
	comisd	%xmm0, %xmm1
	ja	.L2879
	call	clock@PLT
	pxor	%xmm0, %xmm0
	movabsq	$-1229782938247303441, %rcx
	movl	$0, 24(%rsp)
	cvtsi2sdq	%rax, %xmm0
	leaq	8(%rbx), %rax
	divsd	.LC20(%rip), %xmm0
	movl	$0, 60(%rsp)
	movq	%rax, 72(%rsp)
	leaq	224(%r14), %rax
	addsd	40(%rsp), %xmm0
	movq	%rax, 48(%rsp)
	movq	136(%rsp), %rax
	minsd	32(%rsp), %xmm0
	subq	%rbp, %rax
	sarq	$3, %rax
	imulq	%rcx, %rax
	movsd	%xmm0, 32(%rsp)
	leal	-1(%rax), %r13d
	.p2align 4,,10
	.p2align 3
.L2882:
	call	clock@PLT
	movsd	32(%rsp), %xmm4
	pxor	%xmm0, %xmm0
	cvtsi2sdq	%rax, %xmm0
	divsd	.LC20(%rip), %xmm0
	comisd	%xmm0, %xmm4
	jbe	.L2879
	movq	8(%rsp), %rcx
	movq	(%r14), %rdx
	movl	4(%rcx), %eax
	movl	%eax, 40(%rsp)
	subl	$1, %eax
	imull	(%rcx), %eax
	cmpl	72(%rdx), %eax
	jl	.L2879
	testl	%r13d, %r13d
	jns	.L2952
	movq	16(%rsp), %rcx
	movq	136(%rsp), %rax
	subq	%rcx, %rax
	movabsq	$-1229782938247303441, %rcx
	sarq	$3, %rax
	imulq	%rcx, %rax
	leal	-1(%rax), %r13d
.L2952:
	movslq	%r13d, %rdx
	movq	16(%rsp), %rcx
	leaq	24(%r14), %rdi
	movq	%rdx, %rax
	salq	$4, %rax
	subq	%rdx, %rax
	salq	$3, %rax
	leaq	(%rcx,%rax), %rbx
	movq	%rax, 40(%rsp)
	movq	%rbx, %rsi
.LEHB69:
	call	_ZNSt6vectorIiSaIiEEaSERKS1_.isra.0
	leaq	24(%rbx), %rsi
	leaq	48(%r14), %rdi
	call	_ZNSt6vectorIiSaIiEEaSERKS1_.isra.0
	leaq	48(%rbx), %rdx
	leaq	128(%r14), %rax
	cmpq	%rax, %rdx
	je	.L2883
	movq	56(%rbx), %rcx
	movq	48(%rbx), %r12
	movq	128(%r14), %rdi
	movq	144(%r14), %rax
	movq	%rcx, %rbp
	subq	%r12, %rbp
	subq	%rdi, %rax
	cmpq	%rbp, %rax
	jb	.L3074
	movq	136(%r14), %rax
	movq	%rax, %rdx
	subq	%rdi, %rdx
	cmpq	%rbp, %rdx
	jb	.L2893
	cmpq	$8, %rbp
	jle	.L2894
	movq	%rbp, %rdx
	movq	%r12, %rsi
	call	memmove@PLT
	addq	128(%r14), %rbp
.L2892:
	movq	%rbp, 136(%r14)
.L2883:
	movq	72(%rbx), %rax
	movq	48(%rsp), %rdi
	leaq	80(%rbx), %rsi
	movq	%rax, 216(%r14)
	call	_ZNSt6vectorI9PlacementSaIS0_EEaSERKS2_.isra.0
.LEHE69:
	movl	108(%rbx), %eax
	movd	104(%rbx), %xmm1
	movq	24(%r14), %rcx
	movd	112(%rbx), %xmm0
	movl	%eax, 120(%r14)
	movq	32(%r14), %rax
	punpckldq	%xmm1, %xmm0
	subq	%rcx, %rax
	movq	%xmm0, 112(%r14)
	sarq	$2, %rax
	testl	%eax, %eax
	jle	.L2907
	movq	72(%r14), %rdi
	leal	-1(%rax), %esi
	xorl	%eax, %eax
	.p2align 4,,10
	.p2align 3
.L2906:
	movslq	(%rcx,%rax,4), %rdx
	movl	%eax, (%rdi,%rdx,4)
	movq	%rax, %rdx
	addq	$1, %rax
	cmpq	%rdx, %rsi
	jne	.L2906
.L2907:
	movq	_ZL12random_state(%rip), %rax
	movabsq	$-3689348814741910323, %rcx
	movq	%rax, %rdx
	salq	$7, %rdx
	xorq	%rax, %rdx
	movq	%rdx, %rax
	shrq	$9, %rax
	xorq	%rdx, %rax
	movq	%rax, _ZL12random_state(%rip)
	imulq	%rcx, %rax
	movabsq	$3689348814741910323, %rcx
	cmpq	%rax, %rcx
	movq	8(%rsp), %rax
	movl	4(%rax), %eax
	sbbl	$0, %eax
	movl	%eax, 108(%r14)
	cmpl	220(%r14), %eax
	jge	.L3075
	subl	$1, %r13d
	jmp	.L2882
.L3071:
	cmpq	%rsi, %rax
	je	.L2855
	leaq	8(%rax), %rcx
	cmpq	%rcx, %rsi
	je	.L2859
	movq	%rcx, %rdx
	jmp	.L2862
	.p2align 4,,10
	.p2align 3
.L2861:
	movl	(%rax), %edi
.L2862:
	movl	(%rdx), %ecx
	cmpl	%edi, %ecx
	je	.L2860
	movl	%ecx, 4(%rax)
	addq	$4, %rax
.L2860:
	addq	$4, %rdx
	cmpq	%rsi, %rdx
	jne	.L2861
	leaq	4(%rax), %rdx
.L2859:
	cmpq	%rsi, %rdx
	je	.L2855
	movq	%rdx, 104(%rsp)
	jmp	.L2855
	.p2align 4,,10
	.p2align 3
.L3075:
	movq	40(%rsp), %rbp
	pxor	%xmm0, %xmm0
	movq	16(%rsp), %rax
	movq	$0, 176(%rsp)
	movaps	%xmm0, 160(%rsp)
	addq	$120, %rbp
	leaq	(%rax,%rbp), %rbx
	movabsq	$9223372036854775800, %rax
	cmpq	%rbp, %rax
	jb	.L3076
	testq	%rbp, %rbp
	je	.L2972
	movq	%rbp, %rdi
.LEHB70:
	call	_Znwm@PLT
	movq	%rax, %rdx
.L2911:
	movq	16(%rsp), %rdi
	leaq	(%rdx,%rbp), %rax
	movq	%rbx, %rsi
	movq	%rdx, 160(%rsp)
	movq	%rax, 176(%rsp)
	call	_ZSt16__do_uninit_copyIN9__gnu_cxx17__normal_iteratorIPZN6Packer6nestedEdxdddE8SnapshotSt6vectorIS3_SaIS3_EEEES4_ET0_T_SA_S9_
.LEHE70:
	addl	$1, 24(%rsp)
	movq	%rax, 168(%rsp)
.L2912:
	movl	112(%r14), %eax
	testl	%eax, %eax
	je	.L2925
.L2923:
	movl	24(%rsp), %esi
	movq	%r14, %rdi
.LEHB71:
	call	_ZN6Packer4stepEi
	movl	112(%r14), %ecx
	testb	%al, %al
	je	.L2926
	movq	168(%rsp), %rbx
	movq	104(%rsp), %rdx
	movabsq	$-1229782938247303441, %rsi
	movq	%rbx, %rax
	subq	160(%rsp), %rax
	subq	%r15, %rdx
	sarq	$3, %rax
	sarq	$2, %rdx
	imulq	%rsi, %rax
	cmpq	%rdx, %rax
	jnb	.L2916
	cmpl	%ecx, (%r15,%rax,4)
	je	.L3077
.L2916:
	andl	$15, %ecx
	jne	.L2923
	call	clock@PLT
	pxor	%xmm0, %xmm0
	cvtsi2sdq	%rax, %xmm0
	divsd	.LC20(%rip), %xmm0
	comisd	32(%rsp), %xmm0
	jb	.L2912
	leaq	160(%rsp), %rdi
	call	_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EED1Ev
	.p2align 4,,10
	.p2align 3
.L2879:
	movq	16(%rsp), %rax
	movq	136(%rsp), %rbp
	movq	%rax, %rbx
	cmpq	%rax, %rbp
	je	.L2960
	.p2align 4,,10
	.p2align 3
.L2953:
	movq	80(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L2956
	movq	96(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L2956:
	movq	48(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L2957
	movq	64(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L2957:
	movq	24(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L2958
	movq	40(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L2958:
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L2959
	movq	16(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L2959:
	addq	$120, %rbx
	cmpq	%rbx, %rbp
	jne	.L2953
.L2960:
	cmpq	$0, 16(%rsp)
	je	.L2955
	movq	144(%rsp), %rsi
	movq	16(%rsp), %rdi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L2955:
	testq	%r15, %r15
	je	.L2848
	movq	112(%rsp), %rsi
	movq	%r15, %rdi
	subq	%r15, %rsi
	call	_ZdlPvm@PLT
.L2848:
	movq	312(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3068
	movq	8(%rsp), %rax
	addq	$328, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2893:
	.cfi_restore_state
	cmpq	$8, %rdx
	jle	.L2896
	movq	%r12, %rsi
	call	memmove@PLT
	movq	136(%r14), %rax
	movq	128(%r14), %rdi
	movq	56(%rbx), %rcx
	movq	48(%rbx), %r12
	movq	%rax, %rdx
	subq	%rdi, %rdx
.L2897:
	leaq	(%r12,%rdx), %rsi
	subq	%rsi, %rcx
	movq	%rcx, %rdx
	cmpq	$8, %rcx
	jle	.L2900
	movq	%rax, %rdi
	call	memmove@PLT
	addq	128(%r14), %rbp
	jmp	.L2892
	.p2align 4,,10
	.p2align 3
.L3077:
	leaq	192(%rsp), %r12
	leaq	88(%rsp), %rsi
	movq	%r12, %rdi
	call	_ZZN6Packer6nestedEdxdddENKUlvE_clEv
.LEHE71:
	cmpq	176(%rsp), %rbx
	je	.L2917
	movq	256(%rsp), %rax
	addq	$120, %rbx
	movdqa	192(%rsp), %xmm6
	movdqa	208(%rsp), %xmm7
	movdqa	272(%rsp), %xmm3
	movq	%rax, -56(%rbx)
	movq	264(%rsp), %rax
	movups	%xmm6, -120(%rbx)
	movdqa	224(%rsp), %xmm6
	movq	%rax, -48(%rbx)
	movq	288(%rsp), %rax
	movups	%xmm7, -104(%rbx)
	movdqa	240(%rsp), %xmm7
	movq	%rax, -24(%rbx)
	movq	296(%rsp), %rax
	movups	%xmm6, -88(%rbx)
	movq	%rax, -16(%rbx)
	movl	304(%rsp), %eax
	movups	%xmm7, -72(%rbx)
	movups	%xmm3, -40(%rbx)
	movl	%eax, -8(%rbx)
	movq	%rbx, 168(%rsp)
.L2918:
	movl	112(%r14), %ecx
	jmp	.L2916
.L2926:
	testl	%ecx, %ecx
	je	.L2925
.L2928:
	addl	$1, 60(%rsp)
	movl	60(%rsp), %eax
	cmpl	$31, %eax
	jle	.L2939
	movl	$0, 60(%rsp)
	subl	$1, %r13d
.L2939:
	movq	160(%rsp), %rbp
	movq	168(%rsp), %r12
	movq	%rbp, %rbx
	cmpq	%rbp, %r12
	je	.L2947
	.p2align 4,,10
	.p2align 3
.L2940:
	movq	80(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L2943
	movq	96(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L2943:
	movq	48(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L2944
	movq	64(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L2944:
	movq	24(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L2945
	movq	40(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L2945:
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L2946
	movq	16(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L2946:
	addq	$120, %rbx
	cmpq	%rbx, %r12
	jne	.L2940
.L2947:
	testq	%rbp, %rbp
	je	.L2882
	movq	176(%rsp), %rsi
	movq	%rbp, %rdi
	subq	%rbp, %rsi
	call	_ZdlPvm@PLT
	jmp	.L2882
	.p2align 4,,10
	.p2align 3
.L3074:
	movabsq	$9223372036854775800, %rax
	cmpq	%rbp, %rax
	jb	.L3078
	movq	%rbp, %rdi
.LEHB72:
	call	_Znwm@PLT
.LEHE72:
	movq	%rax, %rcx
	cmpq	$8, %rbp
	jle	.L2889
	movq	%rbp, %rdx
	movq	%r12, %rsi
	movq	%rax, %rdi
	call	memmove@PLT
	movq	%rax, %rcx
.L2890:
	movq	128(%r14), %rdi
	testq	%rdi, %rdi
	je	.L2891
	movq	144(%r14), %rsi
	movq	%rcx, 64(%rsp)
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	movq	64(%rsp), %rcx
.L2891:
	addq	%rcx, %rbp
	movq	%rcx, 128(%r14)
	movq	%rbp, 144(%r14)
	jmp	.L2892
	.p2align 4,,10
	.p2align 3
.L2925:
	movq	8(%rsp), %rax
	movl	4(%rax), %eax
	cmpl	%eax, 220(%r14)
	jl	.L2929
	movq	_ZL12random_state(%rip), %rax
	movq	%rax, %rdx
	salq	$7, %rdx
	xorq	%rax, %rdx
	movq	%rdx, %rax
	shrq	$9, %rax
	xorq	%rdx, %rax
	movabsq	$-6148914691236517205, %rdx
	movq	%rax, _ZL12random_state(%rip)
	imulq	%rdx, %rax
	movabsq	$6148914691236517205, %rdx
	cmpq	%rax, %rdx
	jb	.L2928
.L2930:
	movq	144(%rsp), %rax
	movq	136(%rsp), %r13
	pxor	%xmm0, %xmm0
	movq	168(%rsp), %rbx
	movq	160(%rsp), %rbp
	movdqa	160(%rsp), %xmm7
	movq	%rax, 40(%rsp)
	movq	176(%rsp), %rax
	movaps	%xmm0, 160(%rsp)
	movq	$0, 176(%rsp)
	movq	%rax, 144(%rsp)
	movq	16(%rsp), %rax
	movaps	%xmm7, 128(%rsp)
	movq	%rax, %r12
	cmpq	%rax, %r13
	je	.L2938
	.p2align 4,,10
	.p2align 3
.L2931:
	movq	80(%r12), %rdi
	testq	%rdi, %rdi
	je	.L2934
	movq	96(%r12), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L2934:
	movq	48(%r12), %rdi
	testq	%rdi, %rdi
	je	.L2935
	movq	64(%r12), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L2935:
	movq	24(%r12), %rdi
	testq	%rdi, %rdi
	je	.L2936
	movq	40(%r12), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L2936:
	movq	(%r12), %rdi
	testq	%rdi, %rdi
	je	.L2937
	movq	16(%r12), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L2937:
	addq	$120, %r12
	cmpq	%r12, %r13
	jne	.L2931
.L2938:
	cmpq	$0, 16(%rsp)
	je	.L2933
	movq	40(%rsp), %rsi
	movq	16(%rsp), %rdi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L2933:
	subq	%rbp, %rbx
	movq	%rbp, 16(%rsp)
	sarq	$3, %rbx
	movl	$0, 60(%rsp)
	imull	$-286331153, %ebx, %eax
	leal	-1(%rax), %r13d
	jmp	.L2882
	.p2align 4,,10
	.p2align 3
.L2972:
	xorl	%edx, %edx
	jmp	.L2911
	.p2align 4,,10
	.p2align 3
.L2971:
	xorl	%ecx, %ecx
	jmp	.L2872
.L2865:
	leaq	128(%rsp), %r13
	movq	%r12, %rdx
	movq	%rbx, %rsi
	movq	%r13, %rdi
.LEHB73:
	call	_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
.LEHE73:
	movq	272(%rsp), %rdi
	movq	288(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L3065
	call	_ZdlPvm@PLT
.L3065:
	movq	192(%rsp), %r13
	movq	208(%rsp), %rax
	movq	240(%rsp), %rdi
	movq	256(%rsp), %rsi
	movq	216(%rsp), %rbx
	movq	232(%rsp), %r12
	subq	%r13, %rax
	movq	%rax, 16(%rsp)
	subq	%rdi, %rsi
	subq	%rbx, %r12
	testq	%rdi, %rdi
	je	.L2869
	call	_ZdlPvm@PLT
.L2869:
	testq	%rbx, %rbx
	je	.L2870
	movq	%r12, %rsi
	movq	%rbx, %rdi
	call	_ZdlPvm@PLT
.L2870:
	testq	%r13, %r13
	je	.L2864
	movq	16(%rsp), %rsi
	movq	%r13, %rdi
	call	_ZdlPvm@PLT
	jmp	.L2864
.L2917:
	leaq	160(%rsp), %rbp
	movq	%r12, %rdx
	movq	%rbx, %rsi
	movq	%rbp, %rdi
.LEHB74:
	call	_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
.LEHE74:
	movq	272(%rsp), %rdi
	movq	288(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L3066
	call	_ZdlPvm@PLT
.L3066:
	movq	192(%rsp), %rbx
	movq	208(%rsp), %rax
	movq	240(%rsp), %rdi
	movq	256(%rsp), %rsi
	movq	216(%rsp), %rbp
	movq	232(%rsp), %r12
	subq	%rbx, %rax
	movq	%rax, 40(%rsp)
	subq	%rdi, %rsi
	subq	%rbp, %r12
	testq	%rdi, %rdi
	je	.L2921
	call	_ZdlPvm@PLT
.L2921:
	testq	%rbp, %rbp
	je	.L2922
	movq	%r12, %rsi
	movq	%rbp, %rdi
	call	_ZdlPvm@PLT
.L2922:
	testq	%rbx, %rbx
	je	.L2918
	movq	40(%rsp), %rsi
	movq	%rbx, %rdi
	call	_ZdlPvm@PLT
	jmp	.L2918
.L2929:
	movq	216(%r14), %rax
	movq	8(%rsp), %rcx
	movq	48(%rsp), %rsi
	movq	72(%rsp), %rdi
	movq	%rax, (%rcx)
.LEHB75:
	call	_ZNSt6vectorI9PlacementSaIS0_EEaSERKS2_.isra.0
.LEHE75:
	jmp	.L2930
.L2894:
	jne	.L2895
	movq	(%r12), %rax
	movq	%rax, (%rdi)
.L2895:
	addq	%rdi, %rbp
	jmp	.L2892
.L2900:
	jne	.L2895
	movq	(%rsi), %rdx
	movq	%rdx, (%rax)
	jmp	.L2895
.L2896:
	jne	.L2897
	movq	(%r12), %rsi
	movq	%rsi, (%rdi)
	jmp	.L2897
.L2875:
	jne	.L2876
	movdqu	(%rsi), %xmm3
	movups	%xmm3, (%rcx)
	movq	16(%rsi), %rax
	movq	%rax, 16(%rcx)
	jmp	.L2876
.L3078:
	testq	%rbp, %rbp
	jns	.L2886
	movq	312(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3068
.LEHB76:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE76:
.L3073:
	movq	312(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3068
.LEHB77:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE77:
.L2886:
	movq	312(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3068
.LEHB78:
	call	_ZSt17__throw_bad_allocv@PLT
.LEHE78:
.L2889:
	movq	(%r12), %rax
	movq	%rax, (%rcx)
	jmp	.L2890
.L3076:
	movq	312(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3068
	leaq	.LC1(%rip), %rdi
.LEHB79:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE79:
.L2962:
	movq	%r12, %rdi
	call	_ZZN6Packer6nestedEdxdddEN8SnapshotD1Ev
.L2963:
	movq	%r13, %rdi
	leaq	96(%rsp), %r15
	call	_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EED1Ev
.L2966:
	movq	%r15, %rdi
	call	_ZNSt6vectorIiSaIiEED1Ev
	movq	312(%rsp), %rax
	subq	%fs:40, %rax
	je	.L2967
.L3068:
	call	__stack_chk_fail@PLT
.L2977:
	endbr64
	movq	%rax, %rbx
	jmp	.L2962
.L2980:
	endbr64
	movq	%rax, %rbx
	jmp	.L2964
.L2978:
	endbr64
	movq	%rax, %rbx
	leaq	128(%rsp), %r13
	jmp	.L2963
.L2964:
	movq	%r12, %rdi
	call	_ZZN6Packer6nestedEdxdddEN8SnapshotD1Ev
.L2965:
	movq	%rbp, %rdi
	call	_ZNSt6vectorIZN6Packer6nestedEdxdddE8SnapshotSaIS1_EED1Ev
.L2915:
	movq	72(%rsp), %rdi
	leaq	128(%rsp), %r13
	call	_ZNSt6vectorI9PlacementSaIS0_EED1Ev
	jmp	.L2963
.L2976:
	endbr64
	movq	%rax, %rbx
	jmp	.L2966
.L2979:
	endbr64
	movq	%rax, %rbx
	jmp	.L2915
.L2982:
	endbr64
	movq	%rax, %rbx
	jmp	.L2913
.L2981:
	endbr64
	movq	%rax, %rbx
	leaq	160(%rsp), %rbp
	jmp	.L2965
.L2967:
	movq	%rbx, %rdi
.LEHB80:
	call	_Unwind_Resume@PLT
.LEHE80:
.L2913:
	movq	160(%rsp), %rdi
	movq	176(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L2915
	call	_ZdlPvm@PLT
	jmp	.L2915
	.cfi_endproc
.LFE10099:
	.section	.gcc_except_table._ZN6Packer6nestedEdxddd,"aG",@progbits,_ZN6Packer6nestedEdxddd,comdat
.LLSDA10099:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE10099-.LLSDACSB10099
.LLSDACSB10099:
	.uleb128 .LEHB67-.LFB10099
	.uleb128 .LEHE67-.LEHB67
	.uleb128 .L2976-.LFB10099
	.uleb128 0
	.uleb128 .LEHB68-.LFB10099
	.uleb128 .LEHE68-.LEHB68
	.uleb128 .L2978-.LFB10099
	.uleb128 0
	.uleb128 .LEHB69-.LFB10099
	.uleb128 .LEHE69-.LEHB69
	.uleb128 .L2979-.LFB10099
	.uleb128 0
	.uleb128 .LEHB70-.LFB10099
	.uleb128 .LEHE70-.LEHB70
	.uleb128 .L2982-.LFB10099
	.uleb128 0
	.uleb128 .LEHB71-.LFB10099
	.uleb128 .LEHE71-.LEHB71
	.uleb128 .L2981-.LFB10099
	.uleb128 0
	.uleb128 .LEHB72-.LFB10099
	.uleb128 .LEHE72-.LEHB72
	.uleb128 .L2979-.LFB10099
	.uleb128 0
	.uleb128 .LEHB73-.LFB10099
	.uleb128 .LEHE73-.LEHB73
	.uleb128 .L2977-.LFB10099
	.uleb128 0
	.uleb128 .LEHB74-.LFB10099
	.uleb128 .LEHE74-.LEHB74
	.uleb128 .L2980-.LFB10099
	.uleb128 0
	.uleb128 .LEHB75-.LFB10099
	.uleb128 .LEHE75-.LEHB75
	.uleb128 .L2981-.LFB10099
	.uleb128 0
	.uleb128 .LEHB76-.LFB10099
	.uleb128 .LEHE76-.LEHB76
	.uleb128 .L2979-.LFB10099
	.uleb128 0
	.uleb128 .LEHB77-.LFB10099
	.uleb128 .LEHE77-.LEHB77
	.uleb128 .L2978-.LFB10099
	.uleb128 0
	.uleb128 .LEHB78-.LFB10099
	.uleb128 .LEHE78-.LEHB78
	.uleb128 .L2979-.LFB10099
	.uleb128 0
	.uleb128 .LEHB79-.LFB10099
	.uleb128 .LEHE79-.LEHB79
	.uleb128 .L2982-.LFB10099
	.uleb128 0
	.uleb128 .LEHB80-.LFB10099
	.uleb128 .LEHE80-.LEHB80
	.uleb128 0
	.uleb128 0
.LLSDACSE10099:
	.section	.text._ZN6Packer6nestedEdxddd,"axG",@progbits,_ZN6Packer6nestedEdxddd,comdat
	.size	_ZN6Packer6nestedEdxddd, .-_ZN6Packer6nestedEdxddd
	.section	.text._ZSt4swapIN10BeamPacker5StateEENSt9enable_ifIXsrSt6__and_IJSt6__not_ISt15__is_tuple_likeIT_EESt21is_move_constructibleIS6_ESt18is_move_assignableIS6_EEE5valueEvE4typeERS6_SG_,"axG",@progbits,_ZSt4swapIN10BeamPacker5StateEENSt9enable_ifIXsrSt6__and_IJSt6__not_ISt15__is_tuple_likeIT_EESt21is_move_constructibleIS6_ESt18is_move_assignableIS6_EEE5valueEvE4typeERS6_SG_,comdat
	.p2align 4
	.weak	_ZSt4swapIN10BeamPacker5StateEENSt9enable_ifIXsrSt6__and_IJSt6__not_ISt15__is_tuple_likeIT_EESt21is_move_constructibleIS6_ESt18is_move_assignableIS6_EEE5valueEvE4typeERS6_SG_
	.type	_ZSt4swapIN10BeamPacker5StateEENSt9enable_ifIXsrSt6__and_IJSt6__not_ISt15__is_tuple_likeIT_EESt21is_move_constructibleIS6_ESt18is_move_assignableIS6_EEE5valueEvE4typeERS6_SG_, @function
_ZSt4swapIN10BeamPacker5StateEENSt9enable_ifIXsrSt6__and_IJSt6__not_ISt15__is_tuple_likeIT_EESt21is_move_constructibleIS6_ESt18is_move_assignableIS6_EEE5valueEvE4typeERS6_SG_:
.LFB14298:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	pxor	%xmm0, %xmm0
	movq	%rsi, %rbx
	subq	$144, %rsp
	.cfi_def_cfa_offset 160
	movdqu	(%rdi), %xmm1
	movdqu	16(%rdi), %xmm2
	movq	%fs:40, %rax
	movq	%rax, 136(%rsp)
	xorl	%eax, %eax
	movq	64(%rdi), %rax
	movdqu	32(%rdi), %xmm3
	movq	$0, 64(%rdi)
	movdqu	48(%rdi), %xmm4
	movdqu	72(%rdi), %xmm5
	movups	%xmm0, (%rdi)
	movdqu	88(%rdi), %xmm6
	movdqu	112(%rdi), %xmm7
	movups	%xmm0, 16(%rdi)
	movups	%xmm0, 32(%rdi)
	movups	%xmm0, 48(%rdi)
	movsd	104(%rdi), %xmm0
	movq	%rax, 64(%rsp)
	movaps	%xmm1, (%rsp)
	movaps	%xmm2, 16(%rsp)
	movaps	%xmm3, 32(%rsp)
	movaps	%xmm4, 48(%rsp)
	movups	%xmm5, 72(%rsp)
	movups	%xmm6, 88(%rsp)
	movsd	%xmm0, 104(%rsp)
	movaps	%xmm7, 112(%rsp)
	call	_ZN10BeamPacker5StateaSEOS0_.isra.0
	movq	%rbx, %rdi
	movq	%rsp, %rsi
	call	_ZN10BeamPacker5StateaSEOS0_.isra.0
	movq	48(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3080
	movq	64(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3080:
	movq	24(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3081
	movq	40(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3081:
	movq	(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3079
	movq	136(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3092
	movq	16(%rsp), %rsi
	addq	$144, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	subq	%rdi, %rsi
	jmp	_ZdlPvm@PLT
	.p2align 4,,10
	.p2align 3
.L3079:
	.cfi_restore_state
	movq	136(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3092
	addq	$144, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L3092:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE14298:
	.size	_ZSt4swapIN10BeamPacker5StateEENSt9enable_ifIXsrSt6__and_IJSt6__not_ISt15__is_tuple_likeIT_EESt21is_move_constructibleIS6_ESt18is_move_assignableIS6_EEE5valueEvE4typeERS6_SG_, .-_ZSt4swapIN10BeamPacker5StateEENSt9enable_ifIXsrSt6__and_IJSt6__not_ISt15__is_tuple_likeIT_EESt21is_move_constructibleIS6_ESt18is_move_assignableIS6_EEE5valueEvE4typeERS6_SG_
	.section	.text._ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElNS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_T1_,"axG",@progbits,_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElNS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_T1_,comdat
	.p2align 4
	.weak	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElNS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_T1_
	.type	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElNS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_T1_, @function
_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElNS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_T1_:
.LFB13048:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$408, %rsp
	.cfi_def_cfa_offset 464
	movq	%rdx, 96(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 392(%rsp)
	movq	%rsi, %rax
	subq	%rdi, %rax
	cmpq	$2048, %rax
	jle	.L3093
	cmpq	$0, 96(%rsp)
	movq	%rdi, %rbp
	je	.L3181
	leaq	128(%rbp), %rdx
	movq	%rsi, %r12
	movq	%rdx, 120(%rsp)
.L3096:
	sarq	$8, %rax
	movsd	232(%rbp), %xmm1
	subq	$1, 96(%rsp)
	salq	$7, %rax
	movsd	-24(%r12), %xmm2
	leaq	0(%rbp,%rax), %rsi
	leaq	-128(%r12), %rax
	movsd	104(%rsi), %xmm0
	comisd	%xmm1, %xmm0
	jbe	.L3171
	comisd	%xmm0, %xmm2
	ja	.L3179
	comisd	%xmm1, %xmm2
	ja	.L3180
.L3173:
	movq	120(%rsp), %rsi
.L3179:
	movq	%rbp, %rdi
	call	_ZSt4swapIN10BeamPacker5StateEENSt9enable_ifIXsrSt6__and_IJSt6__not_ISt15__is_tuple_likeIT_EESt21is_move_constructibleIS6_ESt18is_move_assignableIS6_EEE5valueEvE4typeERS6_SG_
	pxor	%xmm3, %xmm3
.L3112:
	movq	120(%rsp), %r14
	movq	%r12, %rbx
	.p2align 4,,10
	.p2align 3
.L3115:
	movsd	104(%r14), %xmm1
	movsd	104(%rbp), %xmm0
	leaq	128(%r14), %rax
	comisd	%xmm1, %xmm0
	jbe	.L3120
	.p2align 4,,10
	.p2align 3
.L3122:
	movq	%rax, %rsi
	movsd	104(%rax), %xmm1
	subq	$-128, %rax
	comisd	%xmm1, %xmm0
	ja	.L3122
	movq	%rsi, %r14
.L3120:
	movsd	-24(%rbx), %xmm2
	leaq	-256(%rbx), %rax
	comisd	%xmm0, %xmm2
	jbe	.L3176
	.p2align 4,,10
	.p2align 3
.L3125:
	movq	%rax, %rbx
	movsd	104(%rax), %xmm2
	addq	$-128, %rax
	comisd	%xmm0, %xmm2
	ja	.L3125
.L3126:
	cmpq	%rbx, %r14
	jnb	.L3182
	movdqu	(%r14), %xmm4
	movdqu	24(%r14), %xmm0
	movups	%xmm3, (%r14)
	movq	16(%r14), %rdx
	movq	40(%r14), %r13
	movups	%xmm3, 16(%r14)
	movups	%xmm3, 32(%r14)
	movdqu	48(%r14), %xmm7
	movdqu	72(%r14), %xmm6
	movups	%xmm3, 48(%r14)
	movq	(%rbx), %rcx
	movdqu	112(%r14), %xmm5
	movq	64(%r14), %r15
	movaps	%xmm7, (%rsp)
	movdqu	88(%r14), %xmm7
	movq	%rcx, (%r14)
	movq	8(%rbx), %rcx
	movq	$0, 64(%r14)
	movq	%rcx, 8(%r14)
	movq	16(%rbx), %rcx
	movaps	%xmm6, 16(%rsp)
	movq	%rcx, 16(%r14)
	movq	24(%rbx), %rcx
	movq	$0, (%rbx)
	movq	$0, 16(%rbx)
	movq	%rcx, 24(%r14)
	movq	32(%rbx), %rcx
	movaps	%xmm7, 32(%rsp)
	movq	%rcx, 32(%r14)
	movq	40(%rbx), %rcx
	movaps	%xmm5, 48(%rsp)
	movq	%rcx, 40(%r14)
	movq	$0, 24(%rbx)
	movq	48(%rbx), %rcx
	movq	$0, 32(%rbx)
	movdqu	88(%rbx), %xmm5
	movdqu	72(%rbx), %xmm6
	movdqu	112(%rbx), %xmm7
	movq	$0, 40(%rbx)
	movq	(%rbx), %rdi
	movq	16(%rbx), %rsi
	movq	%rcx, 48(%r14)
	movq	56(%rbx), %rcx
	movq	%rcx, 56(%r14)
	movq	64(%rbx), %rcx
	movq	%rcx, 64(%r14)
	movq	$0, 48(%rbx)
	movq	$0, 56(%rbx)
	movq	$0, 64(%rbx)
	movups	%xmm6, 72(%r14)
	movups	%xmm5, 88(%r14)
	movsd	%xmm2, 104(%r14)
	movups	%xmm7, 112(%r14)
	movq	%rdx, 16(%rbx)
	movups	%xmm4, (%rbx)
	testq	%rdi, %rdi
	je	.L3129
	subq	%rdi, %rsi
	movaps	%xmm0, 80(%rsp)
	movsd	%xmm1, 64(%rsp)
	call	_ZdlPvm@PLT
	movq	24(%rbx), %rdi
	movq	40(%rbx), %rsi
	pxor	%xmm3, %xmm3
	movdqa	80(%rsp), %xmm0
	movsd	64(%rsp), %xmm1
	movq	%r13, 40(%rbx)
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	movups	%xmm0, 24(%rbx)
	je	.L3183
	movsd	%xmm1, 64(%rsp)
	call	_ZdlPvm@PLT
	movq	48(%rbx), %rdi
	movq	64(%rbx), %rsi
	pxor	%xmm3, %xmm3
	movsd	64(%rsp), %xmm1
	subq	%rdi, %rsi
.L3131:
	movdqa	(%rsp), %xmm4
	movq	%r15, 64(%rbx)
	movups	%xmm4, 48(%rbx)
	testq	%rdi, %rdi
	je	.L3132
	movsd	%xmm1, (%rsp)
	call	_ZdlPvm@PLT
	movsd	(%rsp), %xmm1
	pxor	%xmm3, %xmm3
.L3132:
	movdqa	16(%rsp), %xmm4
	movdqa	32(%rsp), %xmm5
	movsd	%xmm1, 104(%rbx)
	subq	$-128, %r14
	movdqa	48(%rsp), %xmm6
	movups	%xmm4, 72(%rbx)
	movups	%xmm5, 88(%rbx)
	movups	%xmm6, 112(%rbx)
	jmp	.L3115
	.p2align 4,,10
	.p2align 3
.L3129:
	movdqa	(%rsp), %xmm4
	movq	%r13, 40(%rbx)
	movq	%r15, 64(%rbx)
	movups	%xmm0, 24(%rbx)
	movups	%xmm4, 48(%rbx)
	jmp	.L3132
	.p2align 4,,10
	.p2align 3
.L3182:
	movq	96(%rsp), %rdx
	movq	%r12, %rsi
	movq	%r14, %rdi
	call	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElNS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_T1_
	movq	%r14, %rax
	subq	%rbp, %rax
	cmpq	$2048, %rax
	jle	.L3093
	cmpq	$0, 96(%rsp)
	je	.L3133
	movq	%r14, %r12
	jmp	.L3096
	.p2align 4,,10
	.p2align 3
.L3176:
	addq	$-128, %rbx
	jmp	.L3126
.L3171:
	comisd	%xmm1, %xmm2
	ja	.L3173
	comisd	%xmm0, %xmm2
	jbe	.L3179
.L3180:
	movq	%rax, %rsi
	movq	%rbp, %rdi
	call	_ZSt4swapIN10BeamPacker5StateEENSt9enable_ifIXsrSt6__and_IJSt6__not_ISt15__is_tuple_likeIT_EESt21is_move_constructibleIS6_ESt18is_move_assignableIS6_EEE5valueEvE4typeERS6_SG_
	pxor	%xmm3, %xmm3
	jmp	.L3112
.L3181:
	movq	%rsi, %r14
.L3133:
	sarq	$7, %rax
	leaq	256(%rsp), %r13
	pxor	%xmm0, %xmm0
	movq	%rax, %rbx
	leaq	-2(%rax), %rax
	sarq	%rax
	movq	%rax, %r12
	movq	%rax, %r15
	salq	$7, %r12
	addq	%rbp, %r12
	jmp	.L3103
.L3100:
	subq	$1, %r15
.L3103:
	movq	64(%r12), %rax
	movdqu	(%r12), %xmm8
	movq	$0, 64(%r12)
	movq	%rbp, %rdi
	movdqu	16(%r12), %xmm7
	movdqu	32(%r12), %xmm6
	movups	%xmm0, (%r12)
	movq	%r13, %rcx
	movdqu	48(%r12), %xmm5
	movdqu	72(%r12), %xmm4
	movups	%xmm0, 16(%r12)
	movq	%rbx, %rdx
	movdqu	88(%r12), %xmm3
	movsd	104(%r12), %xmm2
	movq	%r15, %rsi
	movups	%xmm0, 32(%r12)
	movdqu	112(%r12), %xmm1
	movups	%xmm0, 48(%r12)
	movaps	%xmm0, 128(%rsp)
	movaps	%xmm0, 144(%rsp)
	movaps	%xmm0, 160(%rsp)
	movaps	%xmm0, 176(%rsp)
	movq	%rax, 320(%rsp)
	movq	$0, 192(%rsp)
	movups	%xmm4, 200(%rsp)
	movups	%xmm3, 216(%rsp)
	movsd	%xmm2, 232(%rsp)
	movaps	%xmm1, 240(%rsp)
	movaps	%xmm8, 256(%rsp)
	movaps	%xmm7, 272(%rsp)
	movaps	%xmm6, 288(%rsp)
	movaps	%xmm5, 304(%rsp)
	movups	%xmm4, 328(%rsp)
	movups	%xmm3, 344(%rsp)
	movsd	%xmm2, 360(%rsp)
	movaps	%xmm1, 368(%rsp)
	call	_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElS3_NS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_T0_SG_T1_T2_.isra.0
	movq	304(%rsp), %rdi
	pxor	%xmm0, %xmm0
	testq	%rdi, %rdi
	je	.L3097
	movq	320(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	pxor	%xmm0, %xmm0
.L3097:
	movq	280(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3098
	movq	296(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	pxor	%xmm0, %xmm0
.L3098:
	movq	256(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3099
	movq	272(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	pxor	%xmm0, %xmm0
.L3099:
	addq	$-128, %r12
	testq	%r15, %r15
	jne	.L3100
	leaq	128(%rsp), %rdi
	leaq	-128(%r14), %rbx
	call	_ZN10BeamPacker5StateD1Ev
	.p2align 4,,10
	.p2align 3
.L3101:
	movq	64(%rbx), %r14
	pxor	%xmm7, %xmm7
	movdqu	(%rbx), %xmm6
	movq	%rbp, %rsi
	movdqu	16(%rbx), %xmm5
	movdqu	32(%rbx), %xmm4
	movups	%xmm7, (%rbx)
	movq	%rbx, %rdi
	movdqu	48(%rbx), %xmm3
	movdqu	72(%rbx), %xmm2
	movups	%xmm7, 16(%rbx)
	movdqu	88(%rbx), %xmm1
	movq	104(%rbx), %r12
	movups	%xmm7, 32(%rbx)
	movq	$0, 64(%rbx)
	movdqu	112(%rbx), %xmm0
	movups	%xmm7, 48(%rbx)
	movaps	%xmm6, 96(%rsp)
	movaps	%xmm5, 80(%rsp)
	movaps	%xmm4, 64(%rsp)
	movaps	%xmm3, 48(%rsp)
	movaps	%xmm2, 32(%rsp)
	movaps	%xmm1, 16(%rsp)
	movaps	%xmm0, (%rsp)
	call	_ZN10BeamPacker5StateaSEOS0_.isra.0
	movdqa	96(%rsp), %xmm6
	movq	%rbp, %rdi
	xorl	%esi, %esi
	movdqa	80(%rsp), %xmm5
	movdqa	64(%rsp), %xmm4
	movq	%r13, %rcx
	movq	%r12, 360(%rsp)
	movq	%rbx, %r12
	movdqa	48(%rsp), %xmm3
	movdqa	(%rsp), %xmm0
	movq	%r14, 320(%rsp)
	subq	%rbp, %r12
	movdqa	32(%rsp), %xmm2
	movdqa	16(%rsp), %xmm1
	movaps	%xmm6, 256(%rsp)
	movq	%r12, %rdx
	movaps	%xmm5, 272(%rsp)
	sarq	$7, %rdx
	movaps	%xmm4, 288(%rsp)
	movaps	%xmm3, 304(%rsp)
	movups	%xmm2, 328(%rsp)
	movups	%xmm1, 344(%rsp)
	movaps	%xmm0, 368(%rsp)
	call	_ZSt13__adjust_heapIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElS3_NS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_T0_SG_T1_T2_.isra.0
	movq	304(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3104
	movq	320(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3104:
	movq	280(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3105
	movq	296(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3105:
	movq	256(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3106
	movq	272(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3106:
	addq	$-128, %rbx
	cmpq	$128, %r12
	jg	.L3101
.L3093:
	movq	392(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3184
	addq	$408, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L3184:
	.cfi_restore_state
	call	__stack_chk_fail@PLT
.L3183:
	movq	48(%rbx), %rdi
	movq	64(%rbx), %rsi
	subq	%rdi, %rsi
	jmp	.L3131
	.cfi_endproc
.LFE13048:
	.size	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElNS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_T1_, .-_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElNS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_T1_
	.section	.text._ZN10BeamPacker3runEdx,"axG",@progbits,_ZN10BeamPacker3runEdx,comdat
	.align 2
	.p2align 4
	.weak	_ZN10BeamPacker3runEdx
	.type	_ZN10BeamPacker3runEdx, @function
_ZN10BeamPacker3runEdx:
.LFB10150:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA10150
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$4096, %rsp
	.cfi_def_cfa_offset 4152
	orq	$0, (%rsp)
	subq	$1480, %rsp
	.cfi_def_cfa_offset 5632
	movq	%rdi, 16(%rsp)
	movq	%rsi, (%rsp)
	movq	%rdx, 56(%rsp)
	movsd	%xmm0, 112(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 5560(%rsp)
	movabsq	$9223372036854775807, %rax
	cmpq	%rax, %rdx
	je	.L3516
	movq	(%rsp), %rax
	movslq	8(%rax), %rcx
	movq	56(%rsp), %rax
	cqto
	idivq	%rcx
.L3187:
	movq	$0, 368(%rsp)
	movq	(%rsp), %rbx
	movq	$0x000000000, 408(%rsp)
	movl	%eax, 12(%rbx)
	pxor	%xmm1, %xmm1
	pxor	%xmm0, %xmm0
	movl	$12, %esi
	leaq	304(%rsp), %rax
	movups	%xmm1, 376(%rsp)
	movdqa	.LC28(%rip), %xmm1
	movq	%rax, %rdi
	movq	%rax, 120(%rsp)
	movaps	%xmm0, 304(%rsp)
	movaps	%xmm0, 320(%rsp)
	movaps	%xmm0, 336(%rsp)
	movaps	%xmm0, 352(%rsp)
	movups	%xmm1, 392(%rsp)
	movaps	%xmm0, 416(%rsp)
.LEHB81:
	call	_ZNSt6vectorImSaImEE17_M_default_appendEm
	movabsq	$-6148914691236517205, %r12
	movq	(%rbx), %rdx
	movq	(%rdx), %rcx
	movq	8(%rdx), %rax
	subq	%rcx, %rax
	sarq	$4, %rax
	imulq	%r12, %rax
	testl	%eax, %eax
	jle	.L3188
	movabsq	$-7046029254386353131, %r15
	xorl	%ebp, %ebp
	movabsq	$-4658895280553007687, %r14
	movabsq	$-7723592293110705685, %r13
	jmp	.L3191
	.p2align 4,,10
	.p2align 3
.L3517:
	movw	%bx, (%rsi)
	addq	$2, %rsi
	movq	%rsi, 360(%rsp)
.L3190:
	movq	%rbp, %rax
	movl	%ebx, %ebx
	addq	$1, %rbp
	salq	$32, %rax
	orq	%rax, %rbx
	addq	%r15, %rbx
	movq	%rbx, %rcx
	shrq	$30, %rcx
	xorq	%rbx, %rcx
	imulq	%r14, %rcx
	movq	%rcx, %rax
	shrq	$27, %rax
	xorq	%rcx, %rax
	movq	424(%rsp), %rcx
	imulq	%r13, %rax
	xorq	%rax, %rcx
	shrq	$31, %rax
	xorq	%rcx, %rax
	movq	(%rdx), %rcx
	movq	%rax, 424(%rsp)
	movq	8(%rdx), %rax
	subq	%rcx, %rax
	sarq	$4, %rax
	imulq	%r12, %rax
	cmpl	%ebp, %eax
	jle	.L3188
.L3191:
	leaq	0(%rbp,%rbp,2), %rax
	movq	360(%rsp), %rsi
	salq	$4, %rax
	addq	%rcx, %rax
	movq	8(%rax), %rbx
	subq	(%rax), %rbx
	sarq	$2, %rbx
	movw	%bx, 432(%rsp)
	cmpq	368(%rsp), %rsi
	jne	.L3517
	leaq	432(%rsp), %rdx
	leaq	352(%rsp), %rdi
	call	_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_
.LEHE81:
	movq	(%rsp), %rax
	movq	(%rax), %rdx
	jmp	.L3190
.L3188:
	movq	(%rsp), %rdi
	movq	32(%rdx), %rax
	subq	24(%rdx), %rax
	movabsq	$-8198552921648689607, %rdx
	movq	64(%rdi), %rsi
	movq	56(%rdi), %r13
	sarq	$4, %rax
	imulq	%rdx, %rax
	movq	%rsi, %r12
	subq	%r13, %r12
	movq	%r12, %rdx
	sarq	$2, %rdx
	movq	%rdx, %r14
	movq	%rdx, %rbp
	cmpq	%rax, %rdx
	jb	.L3518
	cmpq	%rdx, %rax
	jb	.L3519
.L3193:
	cmpq	%r13, %rsi
	je	.L3197
	leaq	-4(%rsi), %rcx
	xorl	%eax, %eax
	subq	%r13, %rcx
	shrq	$2, %rcx
	.p2align 4,,10
	.p2align 3
.L3196:
	movq	%rax, %rdx
	movl	%eax, 0(%r13,%rax,4)
	addq	$1, %rax
	cmpq	%rdx, %rcx
	jne	.L3196
.L3197:
	movq	_ZL12random_state(%rip), %rax
	leaq	560(%rsp), %rbx
	movq	%rax, %rdx
	salq	$7, %rdx
	xorq	%rax, %rdx
	movq	%rdx, %rax
	shrq	$9, %rax
	xorq	%rdx, %rax
	movl	$1, %edx
	movq	%rax, _ZL12random_state(%rip)
	movl	%eax, %eax
	movq	%rax, 560(%rsp)
	movq	%rax, %rcx
	.p2align 4,,10
	.p2align 3
.L3195:
	movq	%rcx, %rax
	shrq	$30, %rax
	xorq	%rcx, %rax
	imulq	$1812433253, %rax, %rax
	leal	(%rax,%rdx), %ecx
	movq	%rcx, (%rbx,%rdx,8)
	addq	$1, %rdx
	cmpq	$624, %rdx
	jne	.L3195
	movq	%rbx, %rdx
	movq	%r13, %rdi
	movq	$624, 5552(%rsp)
	call	_ZSt7shuffleIN9__gnu_cxx17__normal_iteratorIPiSt6vectorIiSaIiEEEESt23mersenne_twister_engineImLm32ELm624ELm397ELm31ELm2567483615ELm11ELm4294967295ELm7ELm2636928640ELm15ELm4022730752ELm18ELm1812433253EEEvT_S9_OT0_
	movq	(%rsp), %rax
	movq	88(%rax), %rcx
	movq	80(%rax), %rdx
	movq	%rcx, %rax
	subq	%rdx, %rax
	cmpq	%r12, %rax
	jb	.L3520
	cmpq	%rax, %r12
	jb	.L3521
.L3199:
	movl	%r14d, %edi
	testl	%r14d, %r14d
	jle	.L3206
	movq	(%rsp), %rax
	leal	-1(%r14), %ecx
	movq	80(%rax), %rsi
	xorl	%eax, %eax
	.p2align 4,,10
	.p2align 3
.L3205:
	movslq	0(%r13,%rax,4), %rdx
	movl	%eax, (%rsi,%rdx,4)
	movq	%rax, %rdx
	addq	$1, %rax
	cmpq	%rdx, %rcx
	jne	.L3205
.L3206:
	movq	328(%rsp), %r12
	movq	344(%rsp), %r13
	addq	$63, %rbp
	movl	%edi, 376(%rsp)
	shrq	$6, %rbp
	subq	%r12, %r13
	movq	%r13, %rax
	sarq	$3, %rax
	cmpq	%rbp, %rax
	jb	.L3522
	movq	336(%rsp), %r13
	movq	%r13, %rdx
	subq	%r12, %rdx
	movq	%rdx, %r15
	sarq	$3, %r15
	cmpq	%rbp, %r15
	jnb	.L3209
	cmpq	%r13, %r12
	je	.L3212
	movl	$255, %esi
	movq	%r12, %rdi
	call	memset@PLT
.L3212:
	subq	%r15, %rbp
	movl	$255, %esi
	movq	%r13, %rdi
	salq	$3, %rbp
	movq	%rbp, %rdx
	addq	%r13, %rbp
	call	memset@PLT
	movq	%rbp, 336(%rsp)
.L3208:
	andl	$63, %r14d
	je	.L3214
	movl	$1, %eax
	movl	%r14d, %ecx
	movq	336(%rsp), %rdx
	salq	%cl, %rax
	subq	$1, %rax
	movq	%rax, -8(%rdx)
.L3214:
	movq	120(%rsp), %rsi
	movq	%rbx, %rdi
	call	_ZN10BeamPacker5StateC1EOS0_
	pxor	%xmm0, %xmm0
	movl	$128, %edi
	movq	$0, 224(%rsp)
	movaps	%xmm0, 208(%rsp)
.LEHB82:
	call	_Znwm@PLT
.LEHE82:
	leaq	128(%rax), %rbp
	movq	%rax, %rdi
	movq	%rbx, %rsi
	movq	%rax, 208(%rsp)
	movq	%rbp, 224(%rsp)
.LEHB83:
	call	_ZN10BeamPacker5StateC1ERKS0_
.LEHE83:
	movq	%rbx, %rdi
	movq	%rbp, 216(%rsp)
	call	_ZN10BeamPacker5StateD1Ev
	movq	16(%rsp), %rdi
	movq	.LC21(%rip), %rax
	pxor	%xmm0, %xmm0
	movl	$0, 32(%rsp)
	movq	%rax, (%rdi)
	leaq	8(%rdi), %rsi
	movups	%xmm0, 8(%rdi)
	movq	$0, 24(%rdi)
	movq	(%rsp), %rdi
	movq	%rsi, 40(%rsp)
	movq	(%rdi), %rdx
	movl	20(%rdi), %edi
	movq	56(%rdx), %rax
	subq	48(%rdx), %rax
	movl	%edi, 36(%rsp)
	movabsq	$-6148914691236517205, %rdx
	sarq	$6, %rax
	imulq	%rdx, %rax
	movq	%rax, 24(%rsp)
	movl	%eax, 104(%rsp)
	testl	%eax, %eax
	jle	.L3216
.L3215:
	call	clock@PLT
	movsd	112(%rsp), %xmm4
	pxor	%xmm0, %xmm0
	cvtsi2sdq	%rax, %xmm0
	divsd	.LC20(%rip), %xmm0
	comisd	%xmm0, %xmm4
	jbe	.L3216
	movq	(%rsp), %rax
	movl	32(%rsp), %edi
	movl	16(%rax), %eax
	movl	%eax, 108(%rsp)
	movl	24(%rsp), %eax
	subl	%edi, %eax
	cmpl	$8, %eax
	jle	.L3523
	movl	36(%rsp), %edx
	cmpl	$20, %eax
	jg	.L3224
	sall	108(%rsp)
	movl	$5, %edx
.L3224:
	movq	(%rsp), %rax
	pxor	%xmm0, %xmm0
	movq	216(%rsp), %rsi
	movq	$0, 256(%rsp)
	movaps	%xmm0, 240(%rsp)
	movl	%edx, 20(%rax)
	movq	208(%rsp), %rax
	movq	%rsi, 96(%rsp)
	movq	%rax, 192(%rsp)
	cmpq	%rax, %rsi
	je	.L3216
	movq	%rax, %rbx
	leaq	272(%rsp), %rax
	movq	%rax, 64(%rsp)
.L3229:
	movq	(%rsp), %r15
	movq	64(%rsp), %rdi
	movq	%rbx, %rdx
	movq	%r15, %rsi
.LEHB84:
	call	_ZN10BeamPacker7optionsERNS_5StateE
.LEHE84:
	movabsq	$9223372036854775807, %rdi
	cmpq	%rdi, 56(%rsp)
	je	.L3226
	movq	(%r15), %rax
	movl	88(%rbx), %edx
	addl	72(%rax), %edx
	movl	8(%r15), %eax
	imull	12(%r15), %eax
	cmpl	%eax, %edx
	jg	.L3524
.L3226:
	movq	272(%rsp), %rax
	movq	280(%rsp), %r13
	leaq	432(%rsp), %rsi
	movq	%rsi, 8(%rsp)
	movq	%rax, 80(%rsp)
	movq	%rax, %r12
	cmpq	%rax, %r13
	je	.L3267
.L3231:
	movq	8(%rbx), %rbp
	pxor	%xmm4, %xmm4
	subq	(%rbx), %rbp
	movl	8(%r12), %r15d
	movaps	%xmm4, 432(%rsp)
	movq	$0, 448(%rsp)
	je	.L3525
	movabsq	$9223372036854775800, %rax
	cmpq	%rbp, %rax
	jb	.L3526
	movq	%rbp, %rdi
.LEHB85:
	call	_Znwm@PLT
.LEHE85:
	movq	(%rbx), %rsi
	movq	8(%rbx), %r14
	addq	%rax, %rbp
	movq	%rax, %rcx
	movq	%rax, 432(%rsp)
	subq	%rsi, %r14
	movq	%rbp, 448(%rsp)
	cmpq	$8, %r14
	jle	.L3240
	movq	%r14, %rdx
	movq	%rax, %rdi
	call	memmove@PLT
	movq	%rax, %rcx
.L3235:
	addq	%r14, %rcx
	pxor	%xmm5, %xmm5
	movq	%rcx, 440(%rsp)
	movq	32(%rbx), %rbp
	subq	24(%rbx), %rbp
	movups	%xmm5, 456(%rsp)
	movq	$0, 472(%rsp)
	je	.L3527
	movabsq	$9223372036854775800, %rax
	cmpq	%rbp, %rax
	jb	.L3528
	movq	%rbp, %rdi
.LEHB86:
	call	_Znwm@PLT
.LEHE86:
	movq	24(%rbx), %rsi
	movq	32(%rbx), %r14
	addq	%rax, %rbp
	movq	%rax, %rcx
	movq	%rax, 456(%rsp)
	subq	%rsi, %r14
	movq	%rbp, 472(%rsp)
	cmpq	$8, %r14
	jle	.L3248
	movq	%r14, %rdx
	movq	%rax, %rdi
	call	memmove@PLT
	movq	%rax, %rcx
.L3243:
	movq	56(%rbx), %rbp
	addq	%r14, %rcx
	pxor	%xmm6, %xmm6
	subq	48(%rbx), %rbp
	movq	%rcx, 464(%rsp)
	movq	$0, 496(%rsp)
	movaps	%xmm6, 480(%rsp)
	je	.L3529
	movabsq	$9223372036854775806, %rax
	cmpq	%rbp, %rax
	jb	.L3530
	movq	%rbp, %rdi
.LEHB87:
	call	_Znwm@PLT
.LEHE87:
	movq	48(%rbx), %rsi
	movq	56(%rbx), %rdx
	addq	%rax, %rbp
	movq	%rax, %rcx
	movq	%rax, 480(%rsp)
	subq	%rsi, %rdx
	movq	%rbp, 496(%rsp)
	cmpq	$2, %rdx
	jle	.L3256
	movq	%rax, %rdi
	movq	%rdx, 48(%rsp)
	call	memmove@PLT
	movq	48(%rsp), %rdx
	movq	%rax, %rcx
.L3251:
	movdqu	88(%rbx), %xmm0
	movdqu	72(%rbx), %xmm7
	addq	%rdx, %rcx
	movl	%r15d, %edx
	movdqu	112(%rbx), %xmm2
	movq	8(%rsp), %rsi
	movq	%rcx, 488(%rsp)
	leaq	240(%rsp), %rbp
	movups	%xmm0, 520(%rsp)
	movq	(%rsp), %rdi
	movsd	104(%rbx), %xmm0
	movups	%xmm7, 504(%rsp)
	movsd	%xmm0, 536(%rsp)
	movaps	%xmm2, 544(%rsp)
.LEHB88:
	call	_ZN10BeamPacker5placeERNS_5StateEi
	movq	8(%rsp), %rsi
	movq	(%rsp), %rdi
	leaq	240(%rsp), %rbp
	call	_ZNK10BeamPacker8evaluateERNS_5StateE
.LEHE88:
	movq	248(%rsp), %rsi
	cmpq	256(%rsp), %rsi
	je	.L3262
	movdqa	480(%rsp), %xmm0
	subq	$-128, %rsi
	movdqa	448(%rsp), %xmm2
	movdqa	464(%rsp), %xmm1
	movdqa	432(%rsp), %xmm7
	movups	%xmm2, -112(%rsi)
	movups	%xmm7, -128(%rsi)
	movups	%xmm1, -96(%rsi)
	movups	%xmm0, -80(%rsi)
	movq	496(%rsp), %rax
	movdqu	520(%rsp), %xmm0
	movdqu	504(%rsp), %xmm6
	movdqa	544(%rsp), %xmm5
	movups	%xmm0, -40(%rsi)
	movsd	536(%rsp), %xmm0
	movq	%rax, -64(%rsi)
	movups	%xmm6, -56(%rsi)
	movsd	%xmm0, -24(%rsi)
	movups	%xmm5, -16(%rsi)
	movq	%rsi, 248(%rsp)
.L3263:
	addq	$16, %r12
	cmpq	%r12, %r13
	jne	.L3231
.L3267:
	cmpq	$0, 80(%rsp)
	movq	288(%rsp), %rsi
	je	.L3228
	movq	80(%rsp), %rdi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3228:
	subq	$-128, %rbx
	cmpq	%rbx, 96(%rsp)
	jne	.L3229
	movq	248(%rsp), %rax
	movq	240(%rsp), %rdi
	movq	%rax, 48(%rsp)
	movq	%rdi, 200(%rsp)
	cmpq	%rdi, %rax
	je	.L3268
	movq	%rax, %rbx
	movq	$-2, %rdx
	subq	%rdi, %rbx
	movq	%rbx, %rax
	sarq	$7, %rax
	je	.L3269
	bsrq	%rax, %rax
	cltq
	leaq	(%rax,%rax), %rdx
.L3269:
	movq	48(%rsp), %rbp
	movq	200(%rsp), %r15
	movq	%rbp, %rsi
	movq	%r15, %rdi
	call	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEElNS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_T1_
	cmpq	$2048, %rbx
	jle	.L3270
	leaq	2048(%r15), %r14
	movq	%r15, %rdi
	movq	%r14, %rsi
	call	_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEENS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_.isra.0
	pxor	%xmm0, %xmm0
	cmpq	%r14, %rbp
	je	.L3272
.L3285:
	movsd	104(%r14), %xmm4
	movsd	-24(%r14), %xmm1
	movq	%r14, %rbp
	leaq	-128(%r14), %rbx
	movdqu	24(%r14), %xmm3
	movdqu	48(%r14), %xmm7
	movups	%xmm0, 48(%r14)
	comisd	%xmm4, %xmm1
	movdqu	88(%r14), %xmm6
	movdqu	112(%r14), %xmm5
	movsd	%xmm4, 8(%rsp)
	movaps	%xmm3, 160(%rsp)
	movdqu	72(%r14), %xmm3
	movdqu	(%r14), %xmm2
	movq	16(%r14), %r15
	movq	40(%r14), %r12
	movups	%xmm0, (%r14)
	movq	64(%r14), %r13
	movaps	%xmm7, 144(%rsp)
	movq	$0, 64(%r14)
	movups	%xmm0, 16(%r14)
	movups	%xmm0, 32(%r14)
	movaps	%xmm3, 128(%rsp)
	movaps	%xmm6, 80(%rsp)
	movaps	%xmm5, 64(%rsp)
	jbe	.L3501
	movaps	%xmm2, 176(%rsp)
	.p2align 4,,10
	.p2align 3
.L3278:
	movdqu	(%rbx), %xmm3
	movq	16(%rbx), %rax
	movq	%rbx, %rbp
	movups	%xmm0, (%rbx)
	movq	128(%rbx), %rdi
	movq	144(%rbx), %rsi
	movq	$0, 16(%rbx)
	movq	%rax, 144(%rbx)
	movups	%xmm3, 128(%rbx)
	testq	%rdi, %rdi
	je	.L3275
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	pxor	%xmm0, %xmm0
.L3275:
	movdqu	24(%rbx), %xmm4
	movq	40(%rbx), %rax
	movups	%xmm0, 24(%rbx)
	movq	152(%rbx), %rdi
	movq	168(%rbx), %rsi
	movq	$0, 40(%rbx)
	movq	%rax, 168(%rbx)
	movups	%xmm4, 152(%rbx)
	testq	%rdi, %rdi
	je	.L3276
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	pxor	%xmm0, %xmm0
.L3276:
	movdqu	48(%rbx), %xmm5
	movq	64(%rbx), %rax
	movups	%xmm0, 48(%rbx)
	movq	176(%rbx), %rdi
	movq	192(%rbx), %rsi
	movq	$0, 64(%rbx)
	movq	%rax, 192(%rbx)
	movups	%xmm5, 176(%rbx)
	testq	%rdi, %rdi
	je	.L3277
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	pxor	%xmm0, %xmm0
.L3277:
	movsd	104(%rbx), %xmm1
	movdqu	72(%rbx), %xmm6
	addq	$-128, %rbx
	movdqu	216(%rbx), %xmm7
	movdqu	240(%rbx), %xmm2
	movsd	%xmm1, 360(%rbx)
	movq	128(%rbx), %rdi
	movsd	-24(%rbp), %xmm1
	movups	%xmm6, 328(%rbx)
	movups	%xmm7, 344(%rbx)
	movups	%xmm2, 368(%rbx)
	comisd	8(%rsp), %xmm1
	movq	144(%rbx), %rsi
	ja	.L3278
	movdqa	176(%rsp), %xmm2
	movq	%r15, 16(%rbp)
	movups	%xmm2, 0(%rbp)
	testq	%rdi, %rdi
	je	.L3531
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	movq	24(%rbp), %rdi
	movq	40(%rbp), %rsi
	pxor	%xmm0, %xmm0
	subq	%rdi, %rsi
.L3280:
	movdqa	160(%rsp), %xmm2
	movq	%r12, 40(%rbp)
	movups	%xmm2, 24(%rbp)
	testq	%rdi, %rdi
	je	.L3282
	call	_ZdlPvm@PLT
	pxor	%xmm0, %xmm0
.L3282:
	movq	48(%rbp), %rdi
	movq	64(%rbp), %rsi
	movq	%r13, 64(%rbp)
	movdqa	144(%rsp), %xmm7
	movups	%xmm7, 48(%rbp)
	testq	%rdi, %rdi
	je	.L3284
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	pxor	%xmm0, %xmm0
.L3284:
	movdqa	80(%rsp), %xmm6
	movsd	8(%rsp), %xmm4
	subq	$-128, %r14
	movdqa	128(%rsp), %xmm3
	movdqa	64(%rsp), %xmm5
	movups	%xmm6, 88(%rbp)
	movups	%xmm3, 72(%rbp)
	movsd	%xmm4, 104(%rbp)
	movups	%xmm5, 112(%rbp)
	cmpq	%r14, 48(%rsp)
	jne	.L3285
.L3272:
	movq	192(%rsp), %rbx
	movq	96(%rsp), %rbp
.L3290:
	movq	48(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L3287
	movq	64(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3287:
	movq	24(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L3288
	movq	40(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3288:
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L3289
	movq	16(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3289:
	subq	$-128, %rbx
	cmpq	%rbx, %rbp
	jne	.L3290
	movq	192(%rsp), %rax
	movq	200(%rsp), %rbp
	leaq	208(%rsp), %rsi
	movq	$1, 440(%rsp)
	movq	$0, 456(%rsp)
	movq	%rax, 216(%rsp)
	leaq	480(%rsp), %rax
	movq	%rax, 64(%rsp)
	movq	%rax, 432(%rsp)
	xorl	%eax, %eax
	movq	$0, 472(%rsp)
	movq	112(%rbp), %rbx
	movq	$0, 448(%rsp)
	movl	$0x3f800000, 464(%rsp)
	movq	$0, 480(%rsp)
	movq	%rsi, 8(%rsp)
	testq	%rax, %rax
	je	.L3291
.L3533:
	movq	440(%rsp), %r9
	movq	%rbx, %rax
	xorl	%edx, %edx
	divq	%r9
	movq	432(%rsp), %rax
	movq	(%rax,%rdx,8), %rdi
	movq	%rdx, %r8
	movq	%rdx, %r13
	testq	%rdi, %rdi
	je	.L3292
	movq	(%rdi), %rax
	movq	8(%rax), %rcx
	cmpq	%rcx, %rbx
	je	.L3299
.L3532:
	movq	(%rax), %rsi
	testq	%rsi, %rsi
	je	.L3292
	movq	8(%rsi), %rcx
	movq	%rax, %rdi
	xorl	%edx, %edx
	movq	%rcx, %rax
	divq	%r9
	cmpq	%r8, %rdx
	jne	.L3292
	movq	%rsi, %rax
	cmpq	%rcx, %rbx
	jne	.L3532
.L3299:
	cmpq	$0, (%rdi)
	je	.L3292
.L3327:
	subq	$-128, %rbp
	cmpq	%rbp, 48(%rsp)
	je	.L3297
	movq	456(%rsp), %rax
	movq	112(%rbp), %rbx
	testq	%rax, %rax
	jne	.L3533
.L3291:
	movq	448(%rsp), %rax
	testq	%rax, %rax
	je	.L3294
	.p2align 4,,10
	.p2align 3
.L3298:
	cmpq	8(%rax), %rbx
	je	.L3327
	movq	(%rax), %rax
	testq	%rax, %rax
	jne	.L3298
.L3294:
	movq	%rbx, %rax
	xorl	%edx, %edx
	divq	440(%rsp)
	movq	%rdx, %r13
.L3292:
	movl	$16, %edi
	movq	8(%rsp), %r12
.LEHB89:
	call	_Znwm@PLT
.LEHE89:
	movq	$0, (%rax)
	movq	%rax, %r12
	movq	112(%rbp), %rax
	leaq	464(%rsp), %rdi
	movq	456(%rsp), %rdx
	movq	440(%rsp), %rsi
	movl	$1, %ecx
	movq	%rax, 8(%r12)
	movq	472(%rsp), %r15
.LEHB90:
	call	_ZNKSt8__detail20_Prime_rehash_policy14_M_need_rehashEmmm@PLT
.LEHE90:
	movq	432(%rsp), %r8
	movq	%rdx, %r14
	testb	%al, %al
	jne	.L3534
	leaq	(%r8,%r13,8), %rcx
	movq	(%rcx), %rax
	testq	%rax, %rax
	je	.L3320
.L3543:
	movq	(%rax), %rax
	movq	%rax, (%r12)
	movq	(%rcx), %rax
	movq	%r12, (%rax)
.L3321:
	addq	$1, 456(%rsp)
	movq	216(%rsp), %rsi
	cmpq	224(%rsp), %rsi
	je	.L3535
	movq	0(%rbp), %rax
	movdqu	72(%rbp), %xmm7
	subq	$-128, %rsi
	movq	$0, 0(%rbp)
	movdqu	88(%rbp), %xmm3
	movsd	104(%rbp), %xmm0
	movq	%rax, -128(%rsi)
	movq	8(%rbp), %rax
	movq	$0, 8(%rbp)
	movq	%rax, -120(%rsi)
	movq	16(%rbp), %rax
	movq	$0, 16(%rbp)
	movq	%rax, -112(%rsi)
	movq	24(%rbp), %rax
	movq	$0, 24(%rbp)
	movq	%rax, -104(%rsi)
	movq	32(%rbp), %rax
	movq	$0, 32(%rbp)
	movq	%rax, -96(%rsi)
	movq	40(%rbp), %rax
	movq	$0, 40(%rbp)
	movq	%rax, -88(%rsi)
	movq	48(%rbp), %rax
	movq	$0, 48(%rbp)
	movq	%rax, -80(%rsi)
	movq	56(%rbp), %rax
	movq	$0, 56(%rbp)
	movq	%rax, -72(%rsi)
	movq	64(%rbp), %rax
	movq	$0, 64(%rbp)
	movq	%rax, -64(%rsi)
	movups	%xmm7, -56(%rsi)
	movups	%xmm3, -40(%rsi)
	movsd	%xmm0, -24(%rsi)
	movdqu	112(%rbp), %xmm6
	movups	%xmm6, -16(%rsi)
	movq	%rsi, 216(%rsp)
.L3326:
	subq	208(%rsp), %rsi
	sarq	$7, %rsi
	cmpl	%esi, 108(%rsp)
	jne	.L3327
.L3297:
	leaq	432(%rsp), %rdi
	call	_ZNSt10_HashtableImmSaImENSt8__detail9_IdentityESt8equal_toImESt4hashImENS1_18_Mod_range_hashingENS1_20_Default_ranged_hashENS1_20_Prime_rehash_policyENS1_17_Hashtable_traitsILb0ELb1ELb1EEEED1Ev
	movq	200(%rsp), %rbx
	movq	48(%rsp), %rbp
	.p2align 4,,10
	.p2align 3
.L3332:
	movq	48(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L3329
	movq	64(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3329:
	movq	24(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L3330
	movq	40(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3330:
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.L3331
	movq	16(%rbx), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3331:
	subq	$-128, %rbx
	cmpq	%rbx, %rbp
	jne	.L3332
	movq	200(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3333
	movq	256(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3333:
	addl	$1, 32(%rsp)
	movl	32(%rsp), %eax
	cmpl	%eax, 104(%rsp)
	jne	.L3215
.L3334:
	movq	208(%rsp), %rbx
	movq	216(%rsp), %r12
	cmpq	%rbx, %r12
	je	.L3340
	movabsq	$-6148914691236517205, %r14
	movslq	24(%rsp), %rbp
	leaq	0(%rbp,%rbp,2), %r13
	salq	$3, %r13
	jmp	.L3342
.L3347:
	subq	$-128, %rbx
	cmpq	%rbx, %r12
	je	.L3536
.L3342:
	movq	16(%rsp), %rdx
	movq	(%rsp), %rsi
	movl	84(%rbx), %edi
	movslq	(%rdx), %rax
	movl	8(%rsi), %esi
	testl	%eax, %eax
	je	.L3341
	movslq	4(%rdx), %rdx
	movl	%esi, %ecx
	imull	%edi, %ecx
	imulq	%rdx, %rax
	movslq	%ecx, %rcx
	cmpq	%rax, %rcx
	jge	.L3347
.L3341:
	movq	16(%rsp), %rax
	movd	%esi, %xmm0
	movd	%edi, %xmm7
	punpckldq	%xmm7, %xmm0
	movq	16(%rax), %rcx
	movq	8(%rax), %rdx
	movq	%xmm0, (%rax)
	movq	%rcx, %rax
	subq	%rdx, %rax
	sarq	$3, %rax
	imulq	%r14, %rax
	cmpq	%rbp, %rax
	jb	.L3537
	cmpq	%rax, %rbp
	jnb	.L3345
	leaq	(%rdx,%r13), %rax
	cmpq	%rax, %rcx
	je	.L3345
	movq	16(%rsp), %rdi
	movq	%rax, 16(%rdi)
.L3345:
	movslq	100(%rbx), %rax
	testl	%eax, %eax
	js	.L3347
	movq	(%rsp), %rdi
	movq	16(%rsp), %rsi
	movq	32(%rdi), %rdi
	movq	8(%rsi), %rsi
	.p2align 4,,10
	.p2align 3
.L3348:
	salq	$5, %rax
	addq	%rdi, %rax
	movslq	4(%rax), %rdx
	movdqu	8(%rax), %xmm3
	leaq	(%rdx,%rdx,2), %rdx
	leaq	(%rsi,%rdx,8), %rdx
	movups	%xmm3, (%rdx)
	movq	24(%rax), %rcx
	movslq	(%rax), %rax
	movq	%rcx, 16(%rdx)
	testl	%eax, %eax
	jns	.L3348
	jmp	.L3347
.L3209:
	testq	%rbp, %rbp
	je	.L3213
	leaq	0(,%rbp,8), %rdx
	movq	%r12, %rdi
	movl	$255, %esi
	leaq	(%r12,%rdx), %rbp
	call	memset@PLT
	movq	%rbp, %r12
.L3213:
	cmpq	%r12, %r13
	je	.L3208
	movq	%r12, 336(%rsp)
	jmp	.L3208
.L3519:
	salq	$2, %rax
	leaq	0(%r13,%rax), %rdx
	cmpq	%rdx, %rsi
	je	.L3193
	movq	(%rsp), %rdi
	movq	%rax, %r14
	movq	%rax, %r12
	movq	%rdx, %rsi
	sarq	$2, %r14
	movq	%rdx, 64(%rdi)
	movq	%r14, %rbp
	jmp	.L3193
.L3521:
	addq	%r12, %rdx
	cmpq	%rdx, %rcx
	je	.L3199
	movq	(%rsp), %rax
	movq	%rdx, 88(%rax)
	jmp	.L3199
	.p2align 4,,10
	.p2align 3
.L3525:
	movq	$0, 432(%rsp)
	xorl	%r14d, %r14d
	xorl	%ecx, %ecx
	movq	$0, 448(%rsp)
	jmp	.L3235
	.p2align 4,,10
	.p2align 3
.L3527:
	movq	$0, 456(%rsp)
	xorl	%r14d, %r14d
	xorl	%ecx, %ecx
	movq	$0, 472(%rsp)
	jmp	.L3243
	.p2align 4,,10
	.p2align 3
.L3529:
	movq	$0, 480(%rsp)
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	movq	$0, 496(%rsp)
	jmp	.L3251
	.p2align 4,,10
	.p2align 3
.L3262:
	leaq	240(%rsp), %rbp
	movq	8(%rsp), %rdx
	movq	%rbp, %rdi
.LEHB91:
	call	_ZNSt6vectorIN10BeamPacker5StateESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
.LEHE91:
	movq	480(%rsp), %rdi
	movq	496(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L3511
	call	_ZdlPvm@PLT
.L3511:
	movq	456(%rsp), %rdi
	movq	472(%rsp), %rsi
	movq	432(%rsp), %r14
	movq	448(%rsp), %rbp
	subq	%rdi, %rsi
	subq	%r14, %rbp
	testq	%rdi, %rdi
	je	.L3266
	call	_ZdlPvm@PLT
.L3266:
	testq	%r14, %r14
	je	.L3263
	movq	%rbp, %rsi
	movq	%r14, %rdi
	call	_ZdlPvm@PLT
	jmp	.L3263
.L3524:
	movq	272(%rsp), %rdi
	movq	288(%rsp), %rsi
	testq	%rdi, %rdi
	je	.L3228
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	jmp	.L3228
.L3523:
	sall	$2, 108(%rsp)
	movl	$8, %edx
	jmp	.L3224
.L3516:
	movq	(%rsi), %rax
	movl	72(%rax), %eax
	addl	$12, %eax
	jmp	.L3187
.L3520:
	movq	(%rsp), %r15
	sarq	$2, %rax
	movq	%rbp, %rsi
	subq	%rax, %rsi
	leaq	80(%r15), %rdi
.LEHB92:
	call	_ZNSt6vectorIiSaIiEE17_M_default_appendEm
	movq	64(%r15), %rax
	movq	56(%r15), %r13
	movq	%rax, %r14
	movq	%rax, 8(%rsp)
	subq	%r13, %r14
	sarq	$2, %r14
	movq	%r14, %rbp
	jmp	.L3199
.L3518:
	subq	%rdx, %rax
	movq	%rdi, %rbx
	leaq	56(%rdi), %rdi
	movq	%rax, %rsi
	call	_ZNSt6vectorIiSaIiEE17_M_default_appendEm
	movq	64(%rbx), %rsi
	movq	56(%rbx), %r13
	movq	%rsi, %r12
	subq	%r13, %r12
	movq	%r12, %r14
	sarq	$2, %r14
	movq	%r14, %rbp
	jmp	.L3193
.L3522:
	salq	$3, %rbp
	movq	%rbp, %rdi
	call	_Znwm@PLT
.LEHE92:
	movq	%rbp, %rdx
	movl	$255, %esi
	leaq	(%rax,%rbp), %r14
	movq	%rax, %rdi
	call	memset@PLT
	movq	%r14, 336(%rsp)
	movq	%rax, 328(%rsp)
	movq	%r14, 344(%rsp)
	testq	%r12, %r12
	je	.L3207
	movq	%r13, %rsi
	movq	%r12, %rdi
	call	_ZdlPvm@PLT
.L3207:
	movq	(%rsp), %rax
	movq	64(%rax), %r14
	subq	56(%rax), %r14
	sarq	$2, %r14
	jmp	.L3208
.L3526:
	testq	%rbp, %rbp
	jns	.L3237
	movq	5560(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3515
.LEHB93:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE93:
.L3528:
	testq	%rbp, %rbp
	jns	.L3245
	movq	5560(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3515
.LEHB94:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE94:
.L3530:
	testq	%rbp, %rbp
	js	.L3538
	movq	5560(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3515
.LEHB95:
	call	_ZSt17__throw_bad_allocv@PLT
.LEHE95:
.L3237:
	movq	5560(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3515
.LEHB96:
	call	_ZSt17__throw_bad_allocv@PLT
.LEHE96:
.L3245:
	movq	5560(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3515
.LEHB97:
	call	_ZSt17__throw_bad_allocv@PLT
.LEHE97:
.L3538:
	movq	5560(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3515
.LEHB98:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.LEHE98:
.L3534:
	cmpq	$1, %rdx
	je	.L3539
	movq	%rdx, %rax
	shrq	$60, %rax
	jne	.L3540
	leaq	0(,%rdx,8), %r13
	movq	%r13, %rdi
.LEHB99:
	call	_Znwm@PLT
.LEHE99:
	movq	%r13, %rdx
	xorl	%esi, %esi
	movq	%rax, %rdi
	call	memset@PLT
	movq	%rax, %r8
.L3303:
	movq	448(%rsp), %rsi
	xorl	%edi, %edi
	movq	$0, 448(%rsp)
	leaq	448(%rsp), %r9
.L3513:
	testq	%rsi, %rsi
	je	.L3541
.L3308:
	movq	%rsi, %rcx
	xorl	%edx, %edx
	movq	(%rsi), %rsi
	movq	8(%rcx), %rax
	divq	%r14
	leaq	(%r8,%rdx,8), %rax
	movq	(%rax), %r10
	testq	%r10, %r10
	je	.L3542
	movq	(%r10), %rdx
	movq	%rdx, (%rcx)
	movq	(%rax), %rax
	movq	%rcx, (%rax)
	testq	%rsi, %rsi
	jne	.L3308
.L3541:
	movq	432(%rsp), %rdi
	movq	64(%rsp), %rax
	movq	440(%rsp), %rsi
	cmpq	%rax, %rdi
	je	.L3309
	salq	$3, %rsi
	movq	%r8, 96(%rsp)
	call	_ZdlPvm@PLT
	movq	96(%rsp), %r8
.L3309:
	movq	%rbx, %rax
	xorl	%edx, %edx
	movq	%r14, 440(%rsp)
	divq	%r14
	movq	%r8, 432(%rsp)
	movq	%rdx, %r13
	leaq	(%r8,%r13,8), %rcx
	movq	(%rcx), %rax
	testq	%rax, %rax
	jne	.L3543
.L3320:
	movq	448(%rsp), %rax
	movq	%r12, 448(%rsp)
	movq	%rax, (%r12)
	testq	%rax, %rax
	je	.L3322
	movq	8(%rax), %rax
	xorl	%edx, %edx
	divq	440(%rsp)
	movq	%r12, (%r8,%rdx,8)
.L3322:
	leaq	448(%rsp), %rax
	movq	%rax, (%rcx)
	jmp	.L3321
.L3542:
	movq	448(%rsp), %r10
	movq	%r10, (%rcx)
	movq	%rcx, 448(%rsp)
	movq	%r9, (%rax)
	cmpq	$0, (%rcx)
	je	.L3312
	movq	%rcx, (%r8,%rdi,8)
.L3312:
	movq	%rdx, %rdi
	jmp	.L3513
.L3531:
	movq	24(%rbp), %rdi
	movq	40(%rbp), %rsi
	subq	%rdi, %rsi
	jmp	.L3280
.L3535:
	leaq	208(%rsp), %r12
	movq	%rbp, %rdx
	movq	%r12, %rdi
.LEHB100:
	call	_ZNSt6vectorIN10BeamPacker5StateESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_
.LEHE100:
	movq	216(%rsp), %rsi
	jmp	.L3326
.L3240:
	jne	.L3235
	movq	(%rsi), %rax
	movq	%rax, (%rcx)
	jmp	.L3235
.L3248:
	jne	.L3243
	movq	(%rsi), %rax
	movq	%rax, (%rcx)
	jmp	.L3243
.L3256:
	jne	.L3251
	movzwl	(%rsi), %eax
	movw	%ax, (%rcx)
	jmp	.L3251
.L3268:
	movq	48(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3216
	movq	256(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3216:
	movl	32(%rsp), %eax
	cmpl	%eax, 24(%rsp)
	je	.L3334
	movq	208(%rsp), %rbx
	movq	216(%rsp), %r12
	movq	%rbx, %rbp
	cmpq	%rbx, %r12
	je	.L3340
.L3352:
	movq	48(%rbp), %rdi
	testq	%rdi, %rdi
	je	.L3349
	movq	64(%rbp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3349:
	movq	24(%rbp), %rdi
	testq	%rdi, %rdi
	je	.L3350
	movq	40(%rbp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3350:
	movq	0(%rbp), %rdi
	testq	%rdi, %rdi
	je	.L3351
	movq	16(%rbp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3351:
	subq	$-128, %rbp
	cmpq	%r12, %rbp
	jne	.L3352
.L3340:
	testq	%rbx, %rbx
	je	.L3353
	movq	224(%rsp), %rsi
	movq	%rbx, %rdi
	subq	%rbx, %rsi
	call	_ZdlPvm@PLT
.L3353:
	movq	352(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3354
	movq	368(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3354:
	movq	328(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3355
	movq	344(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3355:
	movq	304(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3185
	movq	320(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3185:
	movq	5560(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3515
	movq	16(%rsp), %rax
	addq	$5576, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L3270:
	.cfi_restore_state
	movq	48(%rsp), %rsi
	movq	200(%rsp), %rdi
	call	_ZSt16__insertion_sortIN9__gnu_cxx17__normal_iteratorIPN10BeamPacker5StateESt6vectorIS3_SaIS3_EEEENS0_5__ops15_Iter_comp_iterIZNS2_3runEdxEUlRKS3_SC_E_EEEvT_SF_T0_.isra.0
	jmp	.L3272
.L3501:
	movups	%xmm2, (%r14)
	movdqa	160(%rsp), %xmm2
	movq	%r15, 16(%r14)
	movq	%r12, 40(%r14)
	movups	%xmm2, 24(%r14)
	jmp	.L3282
.L3537:
	movq	%rbp, %rsi
	movq	40(%rsp), %rdi
	subq	%rax, %rsi
.LEHB101:
	call	_ZNSt6vectorI9PlacementSaIS0_EE17_M_default_appendEm
.LEHE101:
	jmp	.L3345
.L3536:
	movq	208(%rsp), %rbx
	movq	216(%rsp), %r12
	movq	%rbx, %rbp
	jmp	.L3352
.L3539:
	movq	$0, 480(%rsp)
	movq	64(%rsp), %r8
	jmp	.L3303
.L3540:
	shrq	$61, %r14
	je	.L3305
	movq	5560(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3515
.LEHB102:
	call	_ZSt28__throw_bad_array_new_lengthv@PLT
.L3305:
	movq	5560(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3515
	call	_ZSt17__throw_bad_allocv@PLT
.LEHE102:
.L3259:
	leaq	456(%rsp), %rdi
	call	_ZNSt6vectorImSaImEED1Ev
.L3260:
	leaq	432(%rsp), %rdi
	leaq	240(%rsp), %rbp
	call	_ZNSt6vectorImSaImEED1Ev
.L3261:
	movq	64(%rsp), %rdi
	leaq	208(%rsp), %r12
	call	_ZNSt6vectorISt4pairIdiESaIS1_EED1Ev
.L3358:
	movq	%rbp, %rdi
	call	_ZNSt6vectorIN10BeamPacker5StateESaIS1_EED1Ev
.L3359:
	movq	40(%rsp), %rdi
	call	_ZNSt6vectorI9PlacementSaIS0_EED1Ev
	movq	%r12, %rdi
	call	_ZNSt6vectorIN10BeamPacker5StateESaIS1_EED1Ev
.L3223:
	movq	120(%rsp), %rdi
	call	_ZN10BeamPacker5StateD1Ev
	movq	5560(%rsp), %rax
	subq	%fs:40, %rax
	je	.L3360
.L3515:
	call	__stack_chk_fail@PLT
.L3382:
	endbr64
	movq	%rax, %rdi
	jmp	.L3316
.L3370:
	endbr64
	movq	%rax, %rbx
	jmp	.L3223
.L3316:
	call	__cxa_begin_catch@PLT
	movq	%r15, 472(%rsp)
	movq	5560(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3515
.LEHB103:
	call	__cxa_rethrow@PLT
.LEHE103:
.L3360:
	movq	%rbx, %rdi
.LEHB104:
	call	_Unwind_Resume@PLT
.LEHE104:
.L3381:
	endbr64
	movq	%rax, %rbx
	jmp	.L3318
.L3380:
	endbr64
	movq	%rax, %rbx
	jmp	.L3319
.L3374:
	endbr64
	movq	%rax, %rbx
	jmp	.L3325
.L3318:
	call	__cxa_end_catch@PLT
.L3319:
	movq	%r12, %rdi
	movl	$16, %esi
	leaq	208(%rsp), %r12
	call	_ZdlPvm@PLT
.L3325:
	leaq	432(%rsp), %rdi
	leaq	240(%rsp), %rbp
	call	_ZNSt10_HashtableImmSaImENSt8__detail9_IdentityESt8equal_toImESt4hashImENS1_18_Mod_range_hashingENS1_20_Default_ranged_hashENS1_20_Prime_rehash_policyENS1_17_Hashtable_traitsILb0ELb1ELb1EEEED1Ev
	jmp	.L3358
.L3372:
	endbr64
	movq	%rax, %rbx
	jmp	.L3357
.L3378:
	endbr64
	movq	%rax, %rbx
	jmp	.L3260
.L3377:
	endbr64
	movq	%rax, %rdi
	jmp	.L3217
.L3371:
	endbr64
	movq	%rax, %rbx
	leaq	240(%rsp), %rbp
	jmp	.L3261
.L3383:
	endbr64
	movq	%rax, %rbp
	jmp	.L3221
.L3373:
	endbr64
	movq	%rax, %rbx
	leaq	240(%rsp), %rbp
	leaq	208(%rsp), %r12
	jmp	.L3358
.L3379:
	endbr64
	movq	%rax, %rbx
	jmp	.L3259
.L3375:
	endbr64
	movq	%rax, %rbx
	leaq	208(%rsp), %r12
	jmp	.L3359
.L3217:
	call	__cxa_begin_catch@PLT
	movq	5560(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3515
.LEHB105:
	call	__cxa_rethrow@PLT
.LEHE105:
.L3357:
	movq	8(%rsp), %rdi
	call	_ZN10BeamPacker5StateD1Ev
	jmp	.L3261
.L3221:
	movq	208(%rsp), %rdi
	movq	224(%rsp), %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L3222
.L3220:
	call	_ZdlPvm@PLT
.L3222:
	movq	%rbx, %rdi
	movq	%rbp, %rbx
	call	_ZN10BeamPacker5StateD1Ev
	jmp	.L3223
.L3376:
	endbr64
	movq	%rax, %rbp
.L3219:
	call	__cxa_end_catch@PLT
	movq	208(%rsp), %rdi
	movq	224(%rsp), %rsi
	subq	%rdi, %rsi
	jmp	.L3220
	.cfi_endproc
.LFE10150:
	.section	.gcc_except_table._ZN10BeamPacker3runEdx,"aG",@progbits,_ZN10BeamPacker3runEdx,comdat
	.align 4
.LLSDA10150:
	.byte	0xff
	.byte	0x9b
	.uleb128 .LLSDATT10150-.LLSDATTD10150
.LLSDATTD10150:
	.byte	0x1
	.uleb128 .LLSDACSE10150-.LLSDACSB10150
.LLSDACSB10150:
	.uleb128 .LEHB81-.LFB10150
	.uleb128 .LEHE81-.LEHB81
	.uleb128 .L3370-.LFB10150
	.uleb128 0
	.uleb128 .LEHB82-.LFB10150
	.uleb128 .LEHE82-.LEHB82
	.uleb128 .L3383-.LFB10150
	.uleb128 0
	.uleb128 .LEHB83-.LFB10150
	.uleb128 .LEHE83-.LEHB83
	.uleb128 .L3377-.LFB10150
	.uleb128 0x1
	.uleb128 .LEHB84-.LFB10150
	.uleb128 .LEHE84-.LEHB84
	.uleb128 .L3373-.LFB10150
	.uleb128 0
	.uleb128 .LEHB85-.LFB10150
	.uleb128 .LEHE85-.LEHB85
	.uleb128 .L3371-.LFB10150
	.uleb128 0
	.uleb128 .LEHB86-.LFB10150
	.uleb128 .LEHE86-.LEHB86
	.uleb128 .L3378-.LFB10150
	.uleb128 0
	.uleb128 .LEHB87-.LFB10150
	.uleb128 .LEHE87-.LEHB87
	.uleb128 .L3379-.LFB10150
	.uleb128 0
	.uleb128 .LEHB88-.LFB10150
	.uleb128 .LEHE88-.LEHB88
	.uleb128 .L3372-.LFB10150
	.uleb128 0
	.uleb128 .LEHB89-.LFB10150
	.uleb128 .LEHE89-.LEHB89
	.uleb128 .L3374-.LFB10150
	.uleb128 0
	.uleb128 .LEHB90-.LFB10150
	.uleb128 .LEHE90-.LEHB90
	.uleb128 .L3380-.LFB10150
	.uleb128 0
	.uleb128 .LEHB91-.LFB10150
	.uleb128 .LEHE91-.LEHB91
	.uleb128 .L3372-.LFB10150
	.uleb128 0
	.uleb128 .LEHB92-.LFB10150
	.uleb128 .LEHE92-.LEHB92
	.uleb128 .L3370-.LFB10150
	.uleb128 0
	.uleb128 .LEHB93-.LFB10150
	.uleb128 .LEHE93-.LEHB93
	.uleb128 .L3371-.LFB10150
	.uleb128 0
	.uleb128 .LEHB94-.LFB10150
	.uleb128 .LEHE94-.LEHB94
	.uleb128 .L3378-.LFB10150
	.uleb128 0
	.uleb128 .LEHB95-.LFB10150
	.uleb128 .LEHE95-.LEHB95
	.uleb128 .L3379-.LFB10150
	.uleb128 0
	.uleb128 .LEHB96-.LFB10150
	.uleb128 .LEHE96-.LEHB96
	.uleb128 .L3371-.LFB10150
	.uleb128 0
	.uleb128 .LEHB97-.LFB10150
	.uleb128 .LEHE97-.LEHB97
	.uleb128 .L3378-.LFB10150
	.uleb128 0
	.uleb128 .LEHB98-.LFB10150
	.uleb128 .LEHE98-.LEHB98
	.uleb128 .L3379-.LFB10150
	.uleb128 0
	.uleb128 .LEHB99-.LFB10150
	.uleb128 .LEHE99-.LEHB99
	.uleb128 .L3382-.LFB10150
	.uleb128 0x1
	.uleb128 .LEHB100-.LFB10150
	.uleb128 .LEHE100-.LEHB100
	.uleb128 .L3374-.LFB10150
	.uleb128 0
	.uleb128 .LEHB101-.LFB10150
	.uleb128 .LEHE101-.LEHB101
	.uleb128 .L3375-.LFB10150
	.uleb128 0
	.uleb128 .LEHB102-.LFB10150
	.uleb128 .LEHE102-.LEHB102
	.uleb128 .L3382-.LFB10150
	.uleb128 0x1
	.uleb128 .LEHB103-.LFB10150
	.uleb128 .LEHE103-.LEHB103
	.uleb128 .L3381-.LFB10150
	.uleb128 0
	.uleb128 .LEHB104-.LFB10150
	.uleb128 .LEHE104-.LEHB104
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB105-.LFB10150
	.uleb128 .LEHE105-.LEHB105
	.uleb128 .L3376-.LFB10150
	.uleb128 0
.LLSDACSE10150:
	.byte	0x1
	.byte	0
	.align 4
	.long	0

.LLSDATT10150:
	.section	.text._ZN10BeamPacker3runEdx,"axG",@progbits,_ZN10BeamPacker3runEdx,comdat
	.size	_ZN10BeamPacker3runEdx, .-_ZN10BeamPacker3runEdx
	.section	.text.unlikely,"ax",@progbits
.LCOLDB42:
	.section	.text.startup,"ax",@progbits
.LHOTB42:
	.p2align 4
	.globl	main
	.type	main, @function
main:
.LFB10237:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA10237
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	leaq	_ZSt3cin(%rip), %r13
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$744, %rsp
	.cfi_def_cfa_offset 800
	movl	%edi, 88(%rsp)
	xorl	%edi, %edi
	movq	%rsi, 24(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 728(%rsp)
	xorl	%eax, %eax
.LEHB106:
	call	_ZNSt8ios_base15sync_with_stdioEb@PLT
	leaq	108(%rsp), %rsi
	movq	%r13, %rdi
	movq	$0, 232+_ZSt3cin(%rip)
	call	_ZNSirsERi@PLT
	movq	(%rax), %rdx
	movq	-24(%rdx), %rdx
	testb	$5, 32(%rax,%rdx)
	je	.L3846
.L3684:
	movq	728(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3841
	addq	$744, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L3846:
	.cfi_restore_state
	movabsq	$384307168202282325, %rdx
	movslq	108(%rsp), %rax
	cmpq	%rax, %rdx
	jb	.L3847
	imulq	$24, %rax, %r15
	testq	%rax, %rax
	je	.L3548
	movq	%r15, %rdi
	call	_Znwm@PLT
.LEHE106:
	pxor	%xmm0, %xmm0
	movq	%rax, %r14
	movq	%rax, 112(%rsp)
	leaq	(%rax,%r15), %rax
	movq	%rax, 32(%rsp)
	movq	%r14, %rdx
	movq	%rax, 128(%rsp)
	.p2align 4,,10
	.p2align 3
.L3549:
	movq	$0, 16(%rdx)
	addq	$24, %rdx
	movups	%xmm0, -24(%rdx)
	cmpq	%rax, %rdx
	jne	.L3549
	movq	32(%rsp), %rax
	movq	%rax, 120(%rsp)
	cmpq	%r14, %rax
	je	.L3550
	xorl	%r9d, %r9d
	movq	%r14, 8(%rsp)
	leaq	112(%rsp), %rbp
	leaq	464(%rsp), %r15
	movl	%r9d, 16(%rsp)
	.p2align 4,,10
	.p2align 3
.L3556:
	movq	%r15, %rsi
	movq	%r13, %rdi
	movq	%rbp, %r14
.LEHB107:
	call	_ZNSirsERi@PLT
	movq	8(%rsp), %rax
	movslq	464(%rsp), %rsi
	movq	8(%rax), %r12
	movq	(%rax), %rbx
	movq	%rsi, %rdx
	movq	%r12, %rax
	subq	%rbx, %rax
	sarq	$4, %rax
	cmpq	%rsi, %rax
	jb	.L3848
	cmpq	%rax, %rsi
	jnb	.L3552
	salq	$4, %rsi
	addq	%rbx, %rsi
	cmpq	%rsi, %r12
	je	.L3554
	movq	8(%rsp), %rax
	movq	%rsi, 8(%rax)
.L3554:
	movq	%rsi, %r12
	.p2align 4,,10
	.p2align 3
.L3552:
	addl	%edx, 16(%rsp)
	cmpq	%rbx, %r12
	je	.L3559
	.p2align 4,,10
	.p2align 3
.L3558:
	movq	%rbx, %rsi
	movq	%r13, %rdi
	movq	%rbp, %r14
	call	_ZNSi10_M_extractIxEERSiRT_@PLT
	movq	%rax, %rdi
	leaq	8(%rbx), %rsi
	call	_ZNSi10_M_extractIxEERSiRT_@PLT
	addq	$16, %rbx
	cmpq	%rbx, %r12
	jne	.L3558
.L3559:
	addq	$24, 8(%rsp)
	movq	8(%rsp), %rax
	cmpq	%rax, 32(%rsp)
	jne	.L3556
	pxor	%xmm1, %xmm1
	cvtsi2sdl	16(%rsp), %xmm1
	movapd	%xmm1, %xmm0
	movsd	%xmm1, 8(%rsp)
	call	sqrt@PLT
	cvttsd2sil	%xmm0, %edx
	cmpl	$39, %edx
	jle	.L3704
	leaq	240(%rsp), %rax
	movq	%rax, 40(%rsp)
.L3560:
	movl	%edx, 320(%rsp)
	movl	$40, 240(%rsp)
	cmpl	$10, (%rax)
	movl	$10, 464(%rsp)
	jg	.L3561
	leaq	464(%rsp), %rax
.L3561:
	leaq	112(%rsp), %r14
	movq	40(%rsp), %rdi
	movl	(%rax), %ebx
	movq	%r14, %rsi
	call	_ZN9CatalogueC1ERKSt6vectorI5PieceSaIS1_EE
.LEHE107:
	cmpl	$10, 88(%rsp)
	jg	.L3849
	cmpl	$500, 108(%rsp)
	jle	.L3850
.L3564:
	leal	(%rbx,%rbx,4), %esi
	movl	$4, %edi
	leal	(%rbx,%rbx,2), %ecx
	movl	%esi, %eax
	cltd
	idivl	%edi
	cmpl	$43, %ecx
	jg	.L3607
	movl	$10, %edx
	cmpl	$44, %esi
	cmovl	%edx, %eax
.L3608:
	movd	%ebx, %xmm0
	movd	%edx, %xmm2
	movl	%eax, 720(%rsp)
	movl	$3, %edx
	leaq	144(%rsp), %rax
	leaq	712(%rsp), %rbx
	punpckldq	%xmm2, %xmm0
	leaq	464(%rsp), %r15
	movq	%rbx, %rsi
	movq	%rax, %rdi
	movq	%rax, 16(%rsp)
	movq	%xmm0, 712(%rsp)
	movq	%r15, %rcx
.LEHB108:
	call	_ZNSt6vectorIiSaIiEEC1ESt16initializer_listIiERKS0_
.LEHE108:
	movl	$10000, %ebp
	xorl	%r12d, %r12d
	jmp	.L3614
	.p2align 4,,10
	.p2align 3
.L3612:
	subl	$9, %ecx
	movslq	%ecx, %rcx
.L3613:
	movq	_ZL12random_state(%rip), %rax
	movq	16(%rsp), %rdi
	movq	%r15, %rsi
	movq	%rax, %rdx
	salq	$7, %rdx
	xorq	%rax, %rdx
	movq	%rdx, %rax
	shrq	$9, %rax
	xorq	%rdx, %rax
	xorl	%edx, %edx
	movq	%rax, _ZL12random_state(%rip)
	divq	%rcx
	addl	$10, %edx
	movl	%edx, 464(%rsp)
.LEHB109:
	call	_ZNSt6vectorIiSaIiEE12emplace_backIJiEEERiDpOT_.isra.0
.LEHE109:
	subl	$1, %ebp
	je	.L3851
.L3614:
	movsd	8(%rsp), %xmm4
	movq	%r12, %xmm5
	ucomisd	%xmm4, %xmm5
	ja	.L3838
	sqrtsd	%xmm4, %xmm4
	movapd	%xmm4, %xmm0
.L3611:
	cvttsd2sil	%xmm0, %eax
	movl	$75, %ecx
	leal	(%rax,%rax,2), %eax
	cmpl	$149, %eax
	jg	.L3612
	movl	$2, %ecx
	cmpl	$23, %eax
	jle	.L3613
	movl	%eax, %ecx
	shrl	$31, %ecx
	addl	%eax, %ecx
	sarl	%ecx
	jmp	.L3612
	.p2align 4,,10
	.p2align 3
.L3848:
	movq	8(%rsp), %rbx
	subq	%rax, %rsi
	movq	%rbx, %rdi
.LEHB110:
	call	_ZNSt6vectorI5PointSaIS0_EE17_M_default_appendEm
.LEHE110:
	movq	%rbx, %rax
	movl	464(%rsp), %edx
	movq	(%rbx), %rbx
	movq	8(%rax), %r12
	jmp	.L3552
.L3851:
	cmpl	$1, 88(%rsp)
	movq	144(%rsp), %rbp
	jg	.L3852
.L3615:
	movsd	.LC31(%rip), %xmm3
	movsd	%xmm3, 64(%rsp)
.L3621:
	movl	108(%rsp), %ecx
	movl	$4, %esi
	movl	$50, 208(%rsp)
	movl	%ecx, %eax
	cltd
	idivl	%esi
	movl	%eax, 320(%rsp)
	cmpl	$199, %ecx
	jle	.L3716
	leaq	208(%rsp), %rax
.L3623:
	movl	$12, 464(%rsp)
	cmpl	$12, (%rax)
	jg	.L3624
	movq	%r15, %rax
.L3624:
	movl	(%rax), %eax
	movl	%eax, 92(%rsp)
.L3622:
	movq	.LC21(%rip), %rax
	pxor	%xmm0, %xmm0
	xorl	%ecx, %ecx
	movups	%xmm0, 184(%rsp)
	movq	%rax, 176(%rsp)
	movq	%rcx, 200(%rsp)
	call	clock@PLT
	pxor	%xmm0, %xmm0
	movsd	.LC20(%rip), %xmm1
	movq	144(%rsp), %r13
	cvtsi2sdq	%rax, %xmm0
	movq	152(%rsp), %rax
	movsd	%xmm1, 32(%rsp)
	subq	%r13, %rax
	sarq	$2, %rax
	divsd	%xmm1, %xmm0
	movsd	%xmm0, 72(%rsp)
	testl	%eax, %eax
	jle	.L3626
	movq	$0x000000000, 80(%rsp)
	xorl	%ebx, %ebx
	xorl	%ebp, %ebp
	jmp	.L3625
	.p2align 4,,10
	.p2align 3
.L3860:
	cmpl	$4, 88(%rsp)
	movq	$0x000000000, 664(%rsp)
	jg	.L3644
	movl	$2863311531, %edx
	movl	%r12d, %eax
	movsd	.LC17(%rip), %xmm2
	imulq	%rdx, %rax
	shrq	$33, %rax
	leal	(%rax,%rax,2), %edx
	movl	%r12d, %eax
	subl	%edx, %eax
	je	.L3648
	movsd	.LC16(%rip), %xmm2
	cmpl	$1, %eax
	jne	.L3648
	movsd	.LC32(%rip), %xmm2
	.p2align 4,,10
	.p2align 3
.L3648:
	movq	.LC21(%rip), %rax
	pxor	%xmm0, %xmm0
	cmpl	$1, 88(%rsp)
	movq	$0, 232(%rsp)
	movups	%xmm0, 216(%rsp)
	pxor	%xmm3, %xmm3
	movq	%rax, 208(%rsp)
	jg	.L3659
.L3660:
	movsd	.LC35(%rip), %xmm1
.L3666:
	movabsq	$9223372036854775807, %rcx
	testl	%ebx, %ebx
	je	.L3667
	movslq	180(%rsp), %rcx
	movslq	%ebx, %rax
	imulq	%rax, %rcx
.L3667:
	movsd	72(%rsp), %xmm0
	addsd	64(%rsp), %xmm0
	leaq	320(%rsp), %rdi
	movq	%r15, %rsi
	movl	92(%rsp), %edx
.LEHB111:
	call	_ZN6Packer3runEdixddd
.LEHE111:
	movl	320(%rsp), %r12d
	movl	324(%rsp), %edi
	movq	344(%rsp), %r13
	movdqu	328(%rsp), %xmm3
	movl	%r12d, 208(%rsp)
	movl	%edi, 212(%rsp)
	movq	%r13, 232(%rsp)
	movups	%xmm3, 216(%rsp)
.L3665:
	movl	%edi, 56(%rsp)
	call	clock@PLT
	pxor	%xmm0, %xmm0
	movl	56(%rsp), %edi
	cvtsi2sdq	%rax, %xmm0
	divsd	32(%rsp), %xmm0
	subsd	48(%rsp), %xmm0
	movsd	%xmm0, 80(%rsp)
	cmpl	%r12d, %edi
	jg	.L3853
.L3668:
	testl	%ebx, %ebx
	je	.L3671
	movslq	%edi, %rdx
	movslq	180(%rsp), %r8
	movslq	%r12d, %rax
	imulq	%rdx, %rax
	movslq	%ebx, %rdx
	imulq	%r8, %rdx
	cmpq	%rax, %rdx
	jg	.L3671
	je	.L3854
.L3672:
	movq	216(%rsp), %rdi
	movq	%r13, %rsi
	subq	%rdi, %rsi
	testq	%rdi, %rdi
	je	.L3845
	call	_ZdlPvm@PLT
.L3845:
	movl	176(%rsp), %ebx
.L3675:
	movq	688(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3676
	movq	704(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3676:
	movq	616(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3677
	movq	632(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3677:
	movq	592(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3678
	movq	608(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3678:
	movq	536(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3679
	movq	552(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3679:
	movq	512(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3680
	movq	528(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3680:
	movq	488(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3681
	movq	504(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3681:
	movq	144(%rsp), %r13
	movq	152(%rsp), %rax
	addq	$1, %rbp
	subq	%r13, %rax
	sarq	$2, %rax
	cmpl	%ebp, %eax
	jle	.L3626
.L3625:
	call	clock@PLT
	pxor	%xmm0, %xmm0
	movl	%ebp, %r12d
	cvtsi2sdq	%rax, %xmm0
	movapd	%xmm0, %xmm7
	divsd	32(%rsp), %xmm7
	movsd	%xmm7, 48(%rsp)
	testl	%ebx, %ebx
	je	.L3627
	movsd	.LC38(%rip), %xmm0
	mulsd	80(%rsp), %xmm0
	movsd	72(%rsp), %xmm1
	addsd	64(%rsp), %xmm1
	addsd	%xmm7, %xmm0
	comisd	%xmm1, %xmm0
	ja	.L3626
.L3627:
	cmpl	$6, 88(%rsp)
	movl	0(%r13,%rbp,4), %ecx
	jg	.L3855
	cmpq	$2, %rbp
	jbe	.L3856
.L3701:
	movsd	8(%rsp), %xmm2
	pxor	%xmm0, %xmm0
	ucomisd	%xmm2, %xmm0
	ja	.L3839
	sqrtsd	%xmm2, %xmm2
	movapd	%xmm2, %xmm0
.L3633:
	mulsd	.LC39(%rip), %xmm0
	cvttsd2sil	%xmm0, %eax
	cmpl	$74, %eax
	jle	.L3857
	movl	$75, %eax
.L3634:
	leal	-9(%rax), %esi
.L3635:
	leal	-10(%rcx), %eax
	cltd
	idivl	%esi
	leal	10(%rdx), %ecx
.L3636:
	movq	40(%rsp), %rsi
	movl	%ecx, %edx
	movq	%r15, %rdi
.LEHB112:
	call	_ZN6PackerC1ERK9Cataloguei
.LEHE112:
	cmpl	$9, 88(%rsp)
	jg	.L3858
	je	.L3859
.L3641:
	cmpl	$8, 88(%rsp)
	movq	$256, 672(%rsp)
	je	.L3642
	cmpl	$500, 108(%rsp)
	jg	.L3860
	movl	$2863311531, %edx
	movl	%r12d, %eax
	imulq	%rdx, %rax
	shrq	$33, %rax
	leal	(%rax,%rax,2), %edx
	movl	%r12d, %eax
	subl	%edx, %eax
	jne	.L3649
	movq	.LC41(%rip), %rax
	cmpl	$4, 88(%rsp)
	movq	%rax, 664(%rsp)
	jg	.L3644
	movsd	.LC17(%rip), %xmm2
.L3650:
	movq	.LC21(%rip), %rax
	pxor	%xmm0, %xmm0
	andl	$1, %r12d
	movq	$0, 232(%rsp)
	movsd	.LC33(%rip), %xmm3
	movups	%xmm0, 216(%rsp)
	movq	%rax, 208(%rsp)
	jne	.L3662
	pxor	%xmm3, %xmm3
.L3662:
	cmpl	$1, 88(%rsp)
	movsd	.LC34(%rip), %xmm1
	jg	.L3658
.L3663:
	movabsq	$9223372036854775807, %rdx
	testl	%ebx, %ebx
	je	.L3664
	movslq	180(%rsp), %rdx
	movslq	%ebx, %rax
	imulq	%rax, %rdx
.L3664:
	movsd	72(%rsp), %xmm0
	addsd	64(%rsp), %xmm0
	leaq	320(%rsp), %rdi
	movq	%r15, %rsi
.LEHB113:
	call	_ZN6Packer6nestedEdxddd
.LEHE113:
	movl	320(%rsp), %r12d
	movl	324(%rsp), %edi
	movdqu	328(%rsp), %xmm1
	movq	344(%rsp), %r13
	movl	%r12d, 208(%rsp)
	movl	%edi, 212(%rsp)
	movq	%r13, 232(%rsp)
	movups	%xmm1, 216(%rsp)
	jmp	.L3665
.L3852:
	movq	24(%rsp), %r13
	xorl	%esi, %esi
	movl	$10, %edx
	movq	8(%r13), %rdi
	call	__isoc23_strtol@PLT
	testl	%eax, %eax
	jg	.L3861
.L3616:
	movl	88(%rsp), %ebx
	cmpl	$2, %ebx
	je	.L3615
	movq	24(%rsp), %rbp
	xorl	%esi, %esi
	movq	16(%rbp), %rdi
	call	strtod@PLT
	movsd	%xmm0, 64(%rsp)
	cmpl	$3, %ebx
	je	.L3621
	movq	24(%rbp), %rdi
	movl	$10, %edx
	xorl	%esi, %esi
	call	__isoc23_strtol@PLT
	movl	%eax, 92(%rsp)
	jmp	.L3622
.L3716:
	leaq	320(%rsp), %rax
	jmp	.L3623
.L3854:
	cmpl	%r8d, %edi
	jl	.L3671
	cmpl	%ebx, %r12d
	jge	.L3672
	cmpl	%r8d, %edi
	jne	.L3672
	.p2align 4,,10
	.p2align 3
.L3671:
	movq	208(%rsp), %rax
	movq	184(%rsp), %rdi
	movdqu	216(%rsp), %xmm6
	movq	200(%rsp), %rsi
	movq	%rax, 176(%rsp)
	movq	232(%rsp), %rax
	movl	208(%rsp), %ebx
	movups	%xmm6, 184(%rsp)
	movq	%rax, 200(%rsp)
	testq	%rdi, %rdi
	je	.L3675
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
	jmp	.L3675
	.p2align 4,,10
	.p2align 3
.L3858:
	movq	24(%rsp), %rax
	movl	$10, %edx
	xorl	%esi, %esi
	movq	72(%rax), %rdi
	call	__isoc23_strtol@PLT
	movl	%eax, %r13d
.L3640:
	movq	24(%rsp), %rax
	movl	$10, %edx
	xorl	%esi, %esi
	movq	64(%rax), %rdi
	call	__isoc23_strtol@PLT
	movl	%r13d, 676(%rsp)
	movl	%eax, 672(%rsp)
.L3642:
	movq	24(%rsp), %rax
	xorl	%esi, %esi
	movq	56(%rax), %rdi
	call	strtod@PLT
	movsd	%xmm0, 664(%rsp)
.L3644:
	movq	24(%rsp), %r13
	xorl	%esi, %esi
	movq	32(%r13), %rdi
	call	strtod@PLT
	movapd	%xmm0, %xmm1
	pxor	%xmm0, %xmm0
	comisd	%xmm0, %xmm1
	jnb	.L3862
	movl	$2863311531, %edx
	movl	%r12d, %eax
	movsd	.LC17(%rip), %xmm2
	imulq	%rdx, %rax
	shrq	$33, %rax
	leal	(%rax,%rax,2), %edx
	movl	%r12d, %eax
	subl	%edx, %eax
	je	.L3654
	subl	$1, %eax
	movsd	.LC16(%rip), %xmm2
	jne	.L3654
	movsd	.LC32(%rip), %xmm2
	.p2align 4,,10
	.p2align 3
.L3654:
	cmpl	$5, 88(%rsp)
	jle	.L3844
	movq	24(%rsp), %rax
	xorl	%esi, %esi
	movsd	%xmm2, 56(%rsp)
	movq	40(%rax), %rdi
	call	strtod@PLT
	movsd	56(%rsp), %xmm2
	movapd	%xmm0, %xmm1
	pxor	%xmm0, %xmm0
	comisd	%xmm0, %xmm1
	jnb	.L3657
.L3844:
	movl	108(%rsp), %eax
	cmpl	$500, %eax
	jg	.L3648
	jmp	.L3650
	.p2align 4,,10
	.p2align 3
.L3855:
	movq	24(%rsp), %rax
	cmpl	$2, %ebp
	movl	$10, %edx
	movl	%ecx, 56(%rsp)
	setg	%r13b
	xorl	%esi, %esi
	movq	48(%rax), %rdi
	call	__isoc23_strtol@PLT
	movl	56(%rsp), %ecx
	cmpl	$1, %eax
	jne	.L3630
	testb	%r13b, %r13b
	jne	.L3701
.L3630:
	cmpl	$2, %eax
	jne	.L3636
	testb	%r13b, %r13b
	je	.L3636
	imull	$-1431655765, %r12d, %eax
	cmpl	$1431655765, %eax
	jbe	.L3636
	testl	%ebx, %ebx
	je	.L3636
	movl	180(%rsp), %eax
	movl	$11, %edi
	movl	$75, 208(%rsp)
	cmpl	%eax, %ebx
	cmovle	%ebx, %eax
	movl	%eax, %esi
	movl	%ecx, %eax
	cltd
	idivl	%edi
	leal	-5(%rsi,%rdx), %eax
	movl	%eax, 320(%rsp)
	cmpl	$74, %eax
	jle	.L3720
	leaq	208(%rsp), %rax
.L3637:
	movl	$10, 464(%rsp)
	cmpl	$10, (%rax)
	jg	.L3638
	movq	%r15, %rax
.L3638:
	movl	(%rax), %ecx
	jmp	.L3636
	.p2align 4,,10
	.p2align 3
.L3853:
	movq	216(%rsp), %rdx
	movq	224(%rsp), %r9
	movl	%edi, 208(%rsp)
	movl	%r12d, 212(%rsp)
	cmpq	%rdx, %r9
	je	.L3669
	leal	-1(%r12), %r8d
	movslq	%r8d, %r8
	.p2align 4,,10
	.p2align 3
.L3670:
	movq	%r8, %rax
	subq	(%rdx), %rax
	movq	8(%rdx), %xmm0
	addq	$24, %rdx
	movq	%rax, %xmm6
	movl	-8(%rdx), %eax
	punpcklqdq	%xmm6, %xmm0
	addl	$1, %eax
	movups	%xmm0, -24(%rdx)
	movl	%eax, %ecx
	sarl	$31, %ecx
	shrl	$30, %ecx
	addl	%ecx, %eax
	andl	$3, %eax
	subl	%ecx, %eax
	movl	%eax, -8(%rdx)
	cmpq	%rdx, %r9
	jne	.L3670
.L3669:
	movl	%r12d, %eax
	movl	%edi, %r12d
	movl	%eax, %edi
	jmp	.L3668
.L3657:
	movq	24(%rsp), %rax
	xorl	%esi, %esi
	movsd	%xmm2, 56(%rsp)
	movq	40(%rax), %rdi
	call	strtod@PLT
	movq	.LC21(%rip), %rax
	xorl	%edx, %edx
	cmpl	$500, 108(%rsp)
	movapd	%xmm0, %xmm3
	pxor	%xmm0, %xmm0
	movq	%rdx, 232(%rsp)
	movsd	56(%rsp), %xmm2
	movq	%rax, 208(%rsp)
	movups	%xmm0, 216(%rsp)
	jle	.L3658
.L3659:
	movq	24(%rsp), %rax
	xorl	%esi, %esi
	movl	$10, %edx
	movsd	%xmm3, 80(%rsp)
	movsd	%xmm2, 56(%rsp)
	movq	8(%rax), %rdi
	call	__isoc23_strtol@PLT
	movsd	56(%rsp), %xmm2
	movsd	80(%rsp), %xmm3
	testl	%eax, %eax
	jle	.L3660
	movsd	64(%rsp), %xmm1
	jmp	.L3666
	.p2align 4,,10
	.p2align 3
.L3658:
	movq	24(%rsp), %rax
	xorl	%esi, %esi
	movl	$10, %edx
	movsd	%xmm3, 80(%rsp)
	movsd	%xmm2, 56(%rsp)
	movq	8(%rax), %rdi
	call	__isoc23_strtol@PLT
	movsd	.LC34(%rip), %xmm1
	movsd	56(%rsp), %xmm2
	testl	%eax, %eax
	movsd	80(%rsp), %xmm3
	jle	.L3663
	movsd	64(%rsp), %xmm1
	jmp	.L3663
.L3649:
	cmpl	$4, 88(%rsp)
	movq	$0x000000000, 664(%rsp)
	jg	.L3644
	movsd	.LC16(%rip), %xmm2
	cmpl	$1, %eax
	jne	.L3650
	movsd	.LC32(%rip), %xmm2
	jmp	.L3650
.L3862:
	movq	32(%r13), %rdi
	xorl	%esi, %esi
	call	strtod@PLT
	movapd	%xmm0, %xmm2
	jmp	.L3654
.L3857:
	movl	$3, %esi
	cmpl	$12, %eax
	jle	.L3635
	jmp	.L3634
.L3626:
	leaq	_ZSt4cout(%rip), %r12
	movl	176(%rsp), %esi
	movq	%r12, %rdi
.LEHB114:
	call	_ZNSolsEi@PLT
	movq	%rax, %rdi
	movl	$32, %esi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_c@PLT
	movl	180(%rsp), %esi
	movq	%rax, %rdi
	call	_ZNSolsEi@PLT
	movq	%rax, %rdi
	movl	$10, %esi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_c@PLT
	movq	192(%rsp), %r13
	movq	184(%rsp), %rbp
	leaq	107(%rsp), %rax
	movq	%rax, 8(%rsp)
	cmpq	%rbp, %r13
	jne	.L3693
	jmp	.L3694
	.p2align 4,,10
	.p2align 3
.L3863:
	movq	8(%rsp), %rsi
	movl	$1, %edx
	movq	%rbx, %rdi
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@PLT
	movq	%rax, %rbx
.L3686:
	movq	8(%rbp), %rsi
	movq	%rbx, %rdi
	call	_ZNSo9_M_insertIxEERSoT_@PLT
	movb	$32, 208(%rsp)
	movq	%rax, %rbx
	movq	(%rax), %rax
	movq	-24(%rax), %rax
	cmpq	$0, 16(%rbx,%rax)
	je	.L3687
	leaq	208(%rsp), %rsi
	movl	$1, %edx
	movq	%rbx, %rdi
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@PLT
	movq	%rax, %rbx
.L3688:
	movl	16(%rbp), %esi
	movq	%rbx, %rdi
	call	_ZNSolsEi@PLT
	movb	$32, 320(%rsp)
	movq	%rax, %rbx
	movq	(%rax), %rax
	movq	-24(%rax), %rax
	cmpq	$0, 16(%rbx,%rax)
	je	.L3689
	leaq	320(%rsp), %rsi
	movl	$1, %edx
	movq	%rbx, %rdi
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@PLT
	movq	%rax, %rbx
.L3690:
	movl	20(%rbp), %esi
	movq	%rbx, %rdi
	call	_ZNSolsEi@PLT
	movb	$10, 464(%rsp)
	movq	%rax, %rdi
	movq	(%rax), %rax
	movq	-24(%rax), %rax
	cmpq	$0, 16(%rdi,%rax)
	je	.L3691
	movl	$1, %edx
	movq	%r15, %rsi
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@PLT
	addq	$24, %rbp
	cmpq	%rbp, %r13
	je	.L3694
.L3693:
	movq	0(%rbp), %rsi
	movq	%r12, %rdi
	call	_ZNSo9_M_insertIxEERSoT_@PLT
	movq	%rax, %rbx
	movq	(%rax), %rax
	movb	$32, 107(%rsp)
	movq	-24(%rax), %rax
	cmpq	$0, 16(%rbx,%rax)
	jne	.L3863
	movl	$32, %esi
	movq	%rbx, %rdi
	call	_ZNSo3putEc@PLT
	jmp	.L3686
	.p2align 4,,10
	.p2align 3
.L3691:
	movl	$10, %esi
	call	_ZNSo3putEc@PLT
	addq	$24, %rbp
	cmpq	%rbp, %r13
	jne	.L3693
.L3694:
	leaq	184(%rsp), %rdi
	call	_ZNSt6vectorI9PlacementSaIS0_EED1Ev
	movq	16(%rsp), %rdi
	call	_ZNSt6vectorIiSaIiEED1Ev
	movq	40(%rsp), %rdi
	call	_ZN9CatalogueD1Ev
	movq	%r14, %rdi
	call	_ZNSt6vectorI5PieceSaIS0_EED1Ev
	jmp	.L3684
	.p2align 4,,10
	.p2align 3
.L3689:
	movl	$32, %esi
	movq	%rbx, %rdi
	call	_ZNSo3putEc@PLT
	jmp	.L3690
	.p2align 4,,10
	.p2align 3
.L3687:
	movl	$32, %esi
	movq	%rbx, %rdi
	call	_ZNSo3putEc@PLT
.LEHE114:
	jmp	.L3688
.L3859:
	xorl	%r13d, %r13d
	jmp	.L3640
.L3849:
	movq	24(%rsp), %rax
	xorl	%esi, %esi
	movl	$10, %edx
	movq	80(%rax), %rdi
	call	__isoc23_strtol@PLT
	cmpl	%eax, 108(%rsp)
	jg	.L3564
	movl	312(%rsp), %eax
	movl	%eax, 80(%rsp)
.L3702:
	movq	24(%rsp), %rax
	xorl	%esi, %esi
	movl	$10, %edx
	movq	8(%rax), %rdi
	call	__isoc23_strtol@PLT
	testl	%eax, %eax
	jne	.L3864
.L3565:
	pxor	%xmm0, %xmm0
	cvtsi2sdl	80(%rsp), %xmm0
	call	sqrt@PLT
	movl	$40, 320(%rsp)
	cvttsd2sil	%xmm0, %eax
	movl	%eax, 464(%rsp)
	cmpl	$39, %eax
	jle	.L3705
	leaq	320(%rsp), %rax
	leaq	464(%rsp), %r15
.L3567:
	movl	$10, 208(%rsp)
	cmpl	$10, (%rax)
	jg	.L3568
	leaq	208(%rsp), %rax
.L3568:
	movl	(%rax), %eax
	movl	%eax, 72(%rsp)
.L3566:
	call	clock@PLT
	pxor	%xmm0, %xmm0
	cmpl	$2, 88(%rsp)
	movsd	.LC20(%rip), %xmm6
	cvtsi2sdq	%rax, %xmm0
	movsd	.LC31(%rip), %xmm2
	movsd	%xmm6, 32(%rsp)
	movsd	%xmm2, 8(%rsp)
	divsd	%xmm6, %xmm0
	movsd	%xmm0, 16(%rsp)
	jg	.L3865
.L3569:
	movl	72(%rsp), %ebx
	movq	40(%rsp), %rsi
	movq	%r15, %rdi
	movl	%ebx, %edx
.LEHB115:
	call	_ZN6PackerC1ERK9Cataloguei
.LEHE115:
	movsd	16(%rsp), %xmm7
	addsd	8(%rsp), %xmm7
	leaq	176(%rsp), %rdi
	pxor	%xmm3, %xmm3
	movsd	.LC32(%rip), %xmm2
	movsd	.LC37(%rip), %xmm1
	movl	$12, %edx
	movq	%r15, %rsi
	movabsq	$9223372036854775807, %rcx
	movq	$64, 672(%rsp)
	movapd	%xmm7, %xmm0
	movsd	%xmm7, 8(%rsp)
.LEHB116:
	call	_ZN6Packer3runEdixddd
.LEHE116:
	leal	(%rbx,%rbx,4), %esi
	movl	$4, %edi
	leal	(%rbx,%rbx,2), %ecx
	movl	%esi, %eax
	cltd
	idivl	%edi
	cmpl	$43, %ecx
	jg	.L3570
	movl	$10, %edx
	cmpl	$44, %esi
	cmovl	%edx, %eax
.L3571:
	movl	%eax, 720(%rsp)
	movl	72(%rsp), %ebx
	leaq	144(%rsp), %rax
	leaq	320(%rsp), %r12
	movl	%edx, 716(%rsp)
	movq	%r12, %rcx
	movl	$3, %edx
	movq	%rax, %rdi
	leaq	712(%rsp), %rsi
	movl	%ebx, 712(%rsp)
	movq	%rax, 16(%rsp)
.LEHB117:
	call	_ZNSt6vectorIiSaIiEEC1ESt16initializer_listIiERKS0_
.LEHE117:
	xorl	%ebx, %ebx
	xorl	%r13d, %r13d
	jmp	.L3594
	.p2align 4,,10
	.p2align 3
.L3579:
	andl	$1, %ebp
	movsd	.LC32(%rip), %xmm1
	je	.L3581
	movsd	.LC17(%rip), %xmm1
.L3581:
	movq	40(%rsp), %rax
	movl	%r13d, %ecx
	pxor	%xmm0, %xmm0
	movl	%r13d, 328(%rsp)
	movl	%r8d, 336(%rsp)
	movq	%rax, 320(%rsp)
	movabsq	$412316860419, %rax
	movq	%rax, 340(%rsp)
	movq	.LC34(%rip), %rax
	movq	$0, 416(%rsp)
	movq	%rax, 448(%rsp)
	movl	$1, %eax
	salq	%cl, %rax
	movaps	%xmm0, 352(%rsp)
	subq	$1, %rax
	cmpl	$12, 88(%rsp)
	movaps	%xmm0, 368(%rsp)
	movq	%rax, 424(%rsp)
	movaps	%xmm0, 384(%rsp)
	movaps	%xmm0, 400(%rsp)
	movsd	%xmm1, 432(%rsp)
	movsd	%xmm2, 440(%rsp)
	jg	.L3866
.L3582:
	movslq	176(%rsp), %rbp
	movslq	180(%rsp), %rax
	movq	%r12, %rsi
	leaq	208(%rsp), %rdi
	movsd	8(%rsp), %xmm0
	imulq	%rax, %rbp
	movq	%rbp, %rdx
.LEHB118:
	call	_ZN10BeamPacker3runEdx
.LEHE118:
	call	clock@PLT
	pxor	%xmm0, %xmm0
	cvtsi2sdq	%rax, %xmm0
	divsd	32(%rsp), %xmm0
	subsd	48(%rsp), %xmm0
	movslq	208(%rsp), %rax
	movq	%xmm0, %r13
	testl	%eax, %eax
	je	.L3583
	movslq	212(%rsp), %rdx
	movq	208(%rsp), %rcx
	imulq	%rdx, %rax
	cmpq	%rax, %rbp
	jg	.L3867
.L3583:
	cmpl	$1, 88(%rsp)
	jle	.L3589
.L3585:
	movq	24(%rsp), %rax
	xorl	%esi, %esi
	movl	$10, %edx
	movq	8(%rax), %rdi
	call	__isoc23_strtol@PLT
	testl	%eax, %eax
	jne	.L3868
.L3589:
	movq	216(%rsp), %rdi
	movq	232(%rsp), %rsi
	testq	%rdi, %rdi
	je	.L3590
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3590:
	movq	400(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3591
	movq	416(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3591:
	movq	376(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3592
	movq	392(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3592:
	movq	352(%rsp), %rdi
	testq	%rdi, %rdi
	je	.L3593
	movq	368(%rsp), %rsi
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3593:
	addq	$1, %rbx
	cmpq	$1000, %rbx
	je	.L3595
.L3594:
	call	clock@PLT
	pxor	%xmm0, %xmm0
	movq	%r13, %xmm1
	movl	%ebx, %ebp
	cvtsi2sdq	%rax, %xmm0
	movapd	%xmm0, %xmm3
	movsd	.LC38(%rip), %xmm0
	divsd	32(%rsp), %xmm3
	movsd	%xmm3, 48(%rsp)
	mulsd	%xmm1, %xmm0
	addsd	%xmm3, %xmm0
	comisd	8(%rsp), %xmm0
	jnb	.L3595
	movq	144(%rsp), %rdx
	movq	152(%rsp), %rax
	subq	%rdx, %rax
	sarq	$2, %rax
	cmpl	%eax, %ebx
	jge	.L3573
	movl	(%rdx,%rbx,4), %r13d
	movsd	.LC39(%rip), %xmm2
.L3574:
	cmpl	$1, 88(%rsp)
	movl	$32, %r8d
	jle	.L3579
	movq	24(%rsp), %rcx
	xorl	%esi, %esi
	movl	$10, %edx
	movl	%r8d, 56(%rsp)
	movsd	%xmm2, 64(%rsp)
	movq	8(%rcx), %rdi
	call	__isoc23_strtol@PLT
	movl	56(%rsp), %r8d
	movsd	64(%rsp), %xmm2
	testl	%eax, %eax
	cmovne	72(%rsp), %r13d
	cmpl	$11, 88(%rsp)
	jle	.L3579
	movq	24(%rsp), %rax
	movl	$10, %edx
	xorl	%esi, %esi
	movsd	%xmm2, 56(%rsp)
	movq	88(%rax), %rdi
	call	__isoc23_strtol@PLT
	movsd	56(%rsp), %xmm2
	movl	%eax, %r8d
	jmp	.L3579
	.p2align 4,,10
	.p2align 3
.L3573:
	movq	_ZL12random_state(%rip), %rax
	pxor	%xmm0, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdl	80(%rsp), %xmm0
	movq	%rax, %rdx
	salq	$7, %rdx
	xorq	%rax, %rdx
	movq	%rdx, %rax
	shrq	$9, %rax
	xorq	%rdx, %rax
	ucomisd	%xmm0, %xmm1
	movq	%rax, _ZL12random_state(%rip)
	ja	.L3836
	sqrtsd	%xmm0, %xmm0
.L3577:
	movsd	.LC39(%rip), %xmm2
	movl	$51, %edx
	mulsd	%xmm2, %xmm0
	cvttsd2sil	%xmm0, %ecx
	cmpl	$59, %ecx
	jg	.L3578
	leal	-9(%rcx), %edx
	movl	$2, %ecx
	cmpl	%ecx, %edx
	cmovl	%ecx, %edx
.L3578:
	movslq	%edx, %rsi
	xorl	%edx, %edx
	divq	%rsi
	leal	10(%rdx), %r13d
	jmp	.L3574
	.p2align 4,,10
	.p2align 3
.L3866:
	movq	24(%rsp), %rax
	movl	$10, %edx
	xorl	%esi, %esi
	movq	96(%rax), %rdi
	call	__isoc23_strtol@PLT
	movl	%eax, 344(%rsp)
	jmp	.L3582
.L3867:
	movdqu	216(%rsp), %xmm6
	movq	232(%rsp), %rax
	pxor	%xmm0, %xmm0
	xorl	%r8d, %r8d
	movq	184(%rsp), %rdi
	movq	200(%rsp), %rsi
	movq	%rcx, 176(%rsp)
	movq	%rax, 200(%rsp)
	movq	%r8, 232(%rsp)
	movups	%xmm6, 184(%rsp)
	movups	%xmm0, 216(%rsp)
	testq	%rdi, %rdi
	je	.L3584
	subq	%rdi, %rsi
	call	_ZdlPvm@PLT
.L3584:
	cmpl	$1, 88(%rsp)
	jg	.L3585
	jmp	.L3590
.L3868:
	leaq	216(%rsp), %rdi
	call	_ZNSt6vectorI9PlacementSaIS0_EED1Ev
	movq	%r12, %rdi
	call	_ZN10BeamPackerD1Ev
.L3595:
	movq	176(%rsp), %xmm0
	pshufd	$0xe5, %xmm0, %xmm7
	movd	%xmm0, %eax
	movd	%xmm7, %edx
	cmpl	%edx, %eax
	jge	.L3598
	movq	184(%rsp), %rcx
	movq	192(%rsp), %r8
	pshufd	$225, %xmm0, %xmm0
	movq	%xmm0, 176(%rsp)
	cmpq	%r8, %rcx
	je	.L3598
	leal	-1(%rax), %edi
	movl	$4, %esi
	movslq	%edi, %rdi
.L3599:
	movq	%rdi, %rax
	subq	(%rcx), %rax
	movq	8(%rcx), %xmm0
	addq	$24, %rcx
	movq	%rax, %xmm2
	movl	-8(%rcx), %eax
	punpcklqdq	%xmm2, %xmm0
	addl	$1, %eax
	movups	%xmm0, -24(%rcx)
	cltd
	idivl	%esi
	movl	%edx, -8(%rcx)
	cmpq	%rcx, %r8
	jne	.L3599
.L3598:
	movq	16(%rsp), %rdi
	leaq	_ZSt4cout(%rip), %r12
	call	_ZNSt6vectorIiSaIiEED1Ev
	movq	%r15, %rdi
	call	_ZN6PackerD1Ev
	movl	176(%rsp), %esi
	movq	%r12, %rdi
.LEHB119:
	call	_ZNSolsEi@PLT
	movq	%rax, %rdi
	movl	$32, %esi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_c@PLT
	movl	180(%rsp), %esi
	movq	%rax, %rdi
	call	_ZNSolsEi@PLT
	movq	%rax, %rdi
	movl	$10, %esi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_c@PLT
	movq	192(%rsp), %rbp
	movq	184(%rsp), %rbx
	cmpq	%rbx, %rbp
	je	.L3606
	.p2align 4,,10
	.p2align 3
.L3605:
	movq	(%rbx), %rsi
	movq	%r12, %rdi
	call	_ZNSo9_M_insertIxEERSoT_@PLT
	movq	%rax, %rdi
	movl	$32, %esi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_c@PLT
	movq	8(%rbx), %rsi
	movq	%rax, %rdi
	call	_ZNSo9_M_insertIxEERSoT_@PLT
	movq	%rax, %rdi
	movl	$32, %esi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_c@PLT
	movl	16(%rbx), %esi
	movq	%rax, %rdi
	call	_ZNSolsEi@PLT
	movq	%rax, %rdi
	movl	$32, %esi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_c@PLT
	movl	20(%rbx), %esi
	movq	%rax, %rdi
	call	_ZNSolsEi@PLT
	movq	%rax, %rdi
	movl	$10, %esi
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_c@PLT
.LEHE119:
	addq	$24, %rbx
	cmpq	%rbx, %rbp
	jne	.L3605
.L3606:
	leaq	184(%rsp), %rdi
	call	_ZNSt6vectorI9PlacementSaIS0_EED1Ev
	movq	40(%rsp), %rdi
	call	_ZN9CatalogueD1Ev
	movq	%r14, %rdi
	call	_ZNSt6vectorI5PieceSaIS0_EED1Ev
	jmp	.L3684
.L3720:
	leaq	320(%rsp), %rax
	jmp	.L3637
.L3607:
	sarl	$2, %ecx
	movl	%ecx, %edx
	jmp	.L3608
.L3704:
	leaq	240(%rsp), %rbx
	leaq	320(%rsp), %rax
	movq	%rbx, 40(%rsp)
	jmp	.L3560
.L3850:
	movl	312(%rsp), %eax
	cmpl	$1, 88(%rsp)
	movl	%eax, 80(%rsp)
	jle	.L3565
	jmp	.L3702
.L3861:
	movq	8(%r13), %rdi
	movl	$10, %edx
	xorl	%esi, %esi
	call	__isoc23_strtol@PLT
	movq	160(%rsp), %r13
	movl	%eax, 712(%rsp)
	subq	%rbp, %r13
	cmpq	$3, %r13
	ja	.L3617
	movl	$4, %edi
.LEHB120:
	call	_Znwm@PLT
.LEHE120:
	leaq	716(%rsp), %rsi
	movq	%rax, %rdx
	movq	%rbx, %rdi
	movq	%rax, %r12
	call	_ZNSt11__copy_moveILb0ELb1ESt26random_access_iterator_tagE8__copy_mIKiiEEPT0_PT_S7_S5_
	testq	%rbp, %rbp
	je	.L3618
	movq	%r13, %rsi
	movq	%rbp, %rdi
	call	_ZdlPvm@PLT
.L3618:
	movq	%r12, 144(%rsp)
	addq	$4, %r12
	movq	%r12, 152(%rsp)
	movq	%r12, 160(%rsp)
	jmp	.L3616
.L3865:
	movq	24(%rsp), %rax
	xorl	%esi, %esi
	movq	16(%rax), %rdi
	call	strtod@PLT
	movsd	%xmm0, 8(%rsp)
	jmp	.L3569
.L3570:
	sarl	$2, %ecx
	movl	%ecx, %edx
	jmp	.L3571
.L3548:
	xorl	%eax, %eax
	pxor	%xmm0, %xmm0
	movq	%rax, 128(%rsp)
	movaps	%xmm0, 112(%rsp)
.L3550:
	leaq	240(%rsp), %rbx
	xorl	%edx, %edx
	movq	$0x000000000, 8(%rsp)
	leaq	320(%rsp), %rax
	movq	%rbx, 40(%rsp)
	jmp	.L3560
.L3617:
	movq	152(%rsp), %r12
	movq	%r12, %r13
	subq	%rbp, %r13
	cmpq	$3, %r13
	jbe	.L3620
	leaq	716(%rsp), %rsi
	movq	%rbp, %rdx
	movq	%rbx, %rdi
	call	_ZNSt11__copy_moveILb0ELb1ESt26random_access_iterator_tagE8__copy_mIKiiEEPT0_PT_S7_S5_
	cmpq	%rax, %r12
	je	.L3616
.L3843:
	movq	%rax, 152(%rsp)
	jmp	.L3616
.L3705:
	leaq	464(%rsp), %r15
	movq	%r15, %rax
	jmp	.L3567
.L3864:
	movq	24(%rsp), %rax
	movl	$10, %edx
	xorl	%esi, %esi
	leaq	464(%rsp), %r15
	movq	8(%rax), %rdi
	call	__isoc23_strtol@PLT
	movl	%eax, 72(%rsp)
	jmp	.L3566
.L3838:
	movsd	8(%rsp), %xmm0
	call	sqrt@PLT
	jmp	.L3611
.L3620:
	addq	%rbx, %r13
	movq	%rbp, %rdx
	movq	%rbx, %rdi
	movq	%r13, %rsi
	call	_ZNSt11__copy_moveILb0ELb1ESt26random_access_iterator_tagE8__copy_mIKiiEEPT0_PT_S7_S5_
	leaq	716(%rsp), %rsi
	movq	%r12, %rdx
	movq	%r13, %rdi
	call	_ZNSt11__copy_moveILb0ELb1ESt26random_access_iterator_tagE8__copy_mIKiiEEPT0_PT_S7_S5_
	jmp	.L3843
.L3841:
	call	__stack_chk_fail@PLT
.L3839:
	movsd	8(%rsp), %xmm0
	movl	%ecx, 56(%rsp)
	call	sqrt@PLT
	movl	56(%rsp), %ecx
	jmp	.L3633
.L3856:
	movq	40(%rsp), %rsi
	movl	%ecx, %edx
	movq	%r15, %rdi
.LEHB121:
	call	_ZN6PackerC1ERK9Cataloguei
.LEHE121:
	jmp	.L3641
.L3847:
	movq	728(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3841
	leaq	.LC1(%rip), %rdi
.LEHB122:
	call	_ZSt20__throw_length_errorPKc@PLT
.LEHE122:
.L3836:
	movq	%rax, 56(%rsp)
	call	sqrt@PLT
	movq	56(%rsp), %rax
	jmp	.L3577
.L3731:
	endbr64
	movq	%rax, %rbx
	jmp	.L3695
.L3730:
	endbr64
	movq	%rax, %rbx
	jmp	.L3699
.L3733:
	endbr64
	movq	%rax, %rbx
	jmp	.L3698
.L3734:
	endbr64
	movq	%rax, %rbx
	jmp	.L3696
.L3737:
	endbr64
	movq	%rax, %rbx
	jmp	.L3601
.L3732:
	endbr64
	movq	%rax, %rbx
	jmp	.L3603
.L3738:
	endbr64
	movq	%rax, %rbx
	jmp	.L3600
.L3735:
	endbr64
	movq	%rax, %rbx
	jmp	.L3697
.L3736:
	endbr64
	movq	%rax, %rbx
	jmp	.L3602
	.section	.gcc_except_table,"a",@progbits
.LLSDA10237:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE10237-.LLSDACSB10237
.LLSDACSB10237:
	.uleb128 .LEHB106-.LFB10237
	.uleb128 .LEHE106-.LEHB106
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB107-.LFB10237
	.uleb128 .LEHE107-.LEHB107
	.uleb128 .L3730-.LFB10237
	.uleb128 0
	.uleb128 .LEHB108-.LFB10237
	.uleb128 .LEHE108-.LEHB108
	.uleb128 .L3732-.LFB10237
	.uleb128 0
	.uleb128 .LEHB109-.LFB10237
	.uleb128 .LEHE109-.LEHB109
	.uleb128 .L3733-.LFB10237
	.uleb128 0
	.uleb128 .LEHB110-.LFB10237
	.uleb128 .LEHE110-.LEHB110
	.uleb128 .L3730-.LFB10237
	.uleb128 0
	.uleb128 .LEHB111-.LFB10237
	.uleb128 .LEHE111-.LEHB111
	.uleb128 .L3734-.LFB10237
	.uleb128 0
	.uleb128 .LEHB112-.LFB10237
	.uleb128 .LEHE112-.LEHB112
	.uleb128 .L3735-.LFB10237
	.uleb128 0
	.uleb128 .LEHB113-.LFB10237
	.uleb128 .LEHE113-.LEHB113
	.uleb128 .L3734-.LFB10237
	.uleb128 0
	.uleb128 .LEHB114-.LFB10237
	.uleb128 .LEHE114-.LEHB114
	.uleb128 .L3735-.LFB10237
	.uleb128 0
	.uleb128 .LEHB115-.LFB10237
	.uleb128 .LEHE115-.LEHB115
	.uleb128 .L3732-.LFB10237
	.uleb128 0
	.uleb128 .LEHB116-.LFB10237
	.uleb128 .LEHE116-.LEHB116
	.uleb128 .L3736-.LFB10237
	.uleb128 0
	.uleb128 .LEHB117-.LFB10237
	.uleb128 .LEHE117-.LEHB117
	.uleb128 .L3737-.LFB10237
	.uleb128 0
	.uleb128 .LEHB118-.LFB10237
	.uleb128 .LEHE118-.LEHB118
	.uleb128 .L3738-.LFB10237
	.uleb128 0
	.uleb128 .LEHB119-.LFB10237
	.uleb128 .LEHE119-.LEHB119
	.uleb128 .L3731-.LFB10237
	.uleb128 0
	.uleb128 .LEHB120-.LFB10237
	.uleb128 .LEHE120-.LEHB120
	.uleb128 .L3733-.LFB10237
	.uleb128 0
	.uleb128 .LEHB121-.LFB10237
	.uleb128 .LEHE121-.LEHB121
	.uleb128 .L3735-.LFB10237
	.uleb128 0
	.uleb128 .LEHB122-.LFB10237
	.uleb128 .LEHE122-.LEHB122
	.uleb128 0
	.uleb128 0
.LLSDACSE10237:
	.section	.text.startup
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDAC10237
	.type	main.cold, @function
main.cold:
.LFSB10237:
.L3695:
	.cfi_def_cfa_offset 800
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	leaq	184(%rsp), %rdi
	call	_ZNSt6vectorI9PlacementSaIS0_EED1Ev
.L3603:
	movq	40(%rsp), %rdi
	call	_ZN9CatalogueD1Ev
.L3699:
	movq	%r14, %rdi
	call	_ZNSt6vectorI5PieceSaIS0_EED1Ev
	movq	728(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3869
	movq	%rbx, %rdi
.LEHB123:
	call	_Unwind_Resume@PLT
.LEHE123:
.L3696:
	leaq	216(%rsp), %rdi
	call	_ZNSt6vectorI9PlacementSaIS0_EED1Ev
	movq	%r15, %rdi
	call	_ZN6PackerD1Ev
.L3697:
	leaq	184(%rsp), %rdi
	call	_ZNSt6vectorI9PlacementSaIS0_EED1Ev
.L3698:
	movq	16(%rsp), %rdi
	call	_ZNSt6vectorIiSaIiEED1Ev
	jmp	.L3603
.L3600:
	movq	%r12, %rdi
	call	_ZN10BeamPackerD1Ev
	movq	16(%rsp), %rdi
	call	_ZNSt6vectorIiSaIiEED1Ev
.L3601:
	leaq	184(%rsp), %rdi
	call	_ZNSt6vectorI9PlacementSaIS0_EED1Ev
.L3602:
	movq	%r15, %rdi
	call	_ZN6PackerD1Ev
	jmp	.L3603
.L3869:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE10237:
	.section	.gcc_except_table
.LLSDAC10237:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSEC10237-.LLSDACSBC10237
.LLSDACSBC10237:
	.uleb128 .LEHB123-.LCOLDB42
	.uleb128 .LEHE123-.LEHB123
	.uleb128 0
	.uleb128 0
.LLSDACSEC10237:
	.section	.text.unlikely
	.section	.text.startup
	.size	main, .-main
	.section	.text.unlikely
	.size	main.cold, .-main.cold
.LCOLDE42:
	.section	.text.startup
.LHOTE42:
	.data
	.align 8
	.type	_ZL12random_state, @object
	.size	_ZL12random_state, 8
_ZL12random_state:
	.quad	123456789
	.section	.rodata.cst16,"aM",@progbits,16
	.align 16
.LC4:
	.long	64
	.long	0
	.long	0
	.long	2147483647
	.section	.rodata.cst8,"aM",@progbits,8
	.align 8
.LC7:
	.long	0
	.long	1075838976
	.align 8
.LC8:
	.long	515396076
	.long	1068624773
	.align 8
.LC9:
	.long	-1717986918
	.long	1069128089
	.align 8
.LC11:
	.long	630506365
	.long	-726513235
	.align 8
.LC12:
	.long	0
	.long	-1067909120
	.align 8
.LC13:
	.long	0
	.long	-1066860544
	.align 8
.LC14:
	.long	0
	.long	1078362112
	.align 8
.LC15:
	.long	0
	.long	1074790400
	.align 8
.LC16:
	.long	0
	.long	1076363264
	.align 8
.LC17:
	.long	0
	.long	1075314688
	.align 8
.LC18:
	.long	-755914244
	.long	1065378381
	.align 8
.LC19:
	.long	0
	.long	-1064353792
	.align 8
.LC20:
	.long	0
	.long	1093567616
	.set	.LC21,.LC4+8
	.align 8
.LC22:
	.long	652835029
	.long	1072695345
	.section	.rodata.cst16
	.align 16
.LC23:
	.quad	-2147483648
	.quad	-2147483648
	.align 16
.LC24:
	.quad	2147483647
	.quad	2147483647
	.align 16
.LC25:
	.quad	1
	.quad	1
	.align 16
.LC26:
	.quad	2567483615
	.quad	2567483615
	.section	.rodata.cst8
	.align 8
.LC27:
	.long	-1546188227
	.long	1072708976
	.section	.rodata.cst16
	.align 16
.LC28:
	.long	0
	.long	0
	.long	0
	.long	-1
	.section	.rodata.cst8
	.align 8
.LC31:
	.long	0
	.long	1073217536
	.align 8
.LC32:
	.long	0
	.long	1076101120
	.align 8
.LC33:
	.long	0
	.long	1077805056
	.align 8
.LC34:
	.long	-1717986918
	.long	1067030937
	.align 8
.LC35:
	.long	-1133871366
	.long	1065915252
	.align 8
.LC37:
	.long	-755914244
	.long	1062232653
	.align 8
.LC38:
	.long	-858993459
	.long	1073007820
	.align 8
.LC39:
	.long	0
	.long	1072168960
	.align 8
.LC41:
	.long	1717986918
	.long	1072064102
	.hidden	DW.ref.__gxx_personality_v0
	.weak	DW.ref.__gxx_personality_v0
	.section	.<gateway>.DW.ref.__gxx_personality_v0,"awG",@progbits,DW.ref.__gxx_personality_v0,comdat
	.align 8
	.type	DW.ref.__gxx_personality_v0, @object
	.size	DW.ref.__gxx_personality_v0, 8
DW.ref.__gxx_personality_v0:
	.quad	__gxx_personality_v0
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
